@echo off
chcp 65001 >nul
rem RMD AudioLab - libera as portas do AudioLab so para a rede local (celulares da sala, inclusive o Wi-Fi do proprio computador)
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
set LOG=%~dp0liberar-rede-log.txt
echo LIBERAR AUDIOLAB %date% %time% > "%LOG%"
netsh advfirewall firewall delete rule name="RMD AudioLab 49326-49327" >> "%LOG%" 2>&1
netsh advfirewall firewall add rule name="RMD AudioLab 49326-49327" dir=in action=allow protocol=TCP localport=49326-49327 profile=any remoteip=LocalSubnet,192.168.0.0/16,10.0.0.0/8,172.16.0.0/12 >> "%LOG%" 2>&1
echo FIM >> "%LOG%"
echo  Pronto. As portas do AudioLab foram liberadas so para a rede local.
timeout /t 6 >nul
