"""RMD AudioLab — servidor da sala de aula de áudio (rede local).

O computador do professor roda este servidor. Os alunos entram pelo celular, na mesma rede Wi-Fi,
lendo o QR Code da aula. Só biblioteca padrão do Python.

- Professor: entra com senha (padrão inicial 1234, troca em Configurações). Só ele cria a sessão,
  escolhe Operador/Observador, inicia/pausa/finaliza exercícios e vê as notas.
- Aluno: entra com o nome + código da sessão e recebe um crachá (token) só dele. Só mexe na mesa
  quando é Operador e o exercício está ativo. Vê só a própria nota.
- Projeção (telão): mostra o exercício e o tempo; nunca mostra nomes nem notas.
- Histórico de resultados fica guardado em dados/audiolab.json.
"""
from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import unicodedata
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import urllib.error
import urllib.request

RAIZ = Path(__file__).resolve().parent
ESTATICO = RAIZ / "static"
PASTA_DADOS = Path(os.getenv("AUDIOLAB_DADOS") or (RAIZ / "dados"))
PORTA = int(os.getenv("AUDIOLAB_PORTA", "49326"))
CURSO_PADRAO = "Conhecendo o Som"
NOTA_MINIMA = 80      # 80% ou mais: aprovado na matéria
NOTA_CERTIFICADO = 50  # 50% a 79%: na média (estudar mais); abaixo de 50%: refazer.
# O certificado sai quando todas as matérias foram avaliadas e nenhuma ficou abaixo de 50%. A nota não aparece no certificado.
# Cursos básicos avaliados pelo professor (canto e regência): 5 matérias, cada uma com 5 critérios de 20% (rubrica).
# A Operação de Som não está aqui: a nota dela vem dos exercícios da mesa (trilha).
CURSOS_AVALIADOS = {
    "louvor": {"nome": "Ministério de Louvor (Levitas)", "materias": [
        {"id": "respiracao", "nome": "Respiração e apoio", "criterios": [
            "Inspira sem subir os ombros", "Usa o apoio (barriga e costelas) na frase", "Sustenta o \"sssss\" constante por 20 s ou mais",
            "Não falta ar no fim das frases", "Mantém a postura alinhada ao cantar"]},
        {"id": "saude", "nome": "Aquecimento e saúde vocal", "criterios": [
            "Faz o aquecimento (brrr, trrr, canudo) do jeito certo", "Conhece os cuidados com a voz (água, descanso, não gritar)",
            "Canta sem forçar a garganta", "Sabe parar quando a voz cansa", "Faz o desaquecimento depois de cantar"]},
        {"id": "afinacao", "nome": "Afinação e percepção", "criterios": [
            "Repete a nota do eco", "Canta a escala de 5 notas afinada", "Mantém o tom da música sem sair",
            "Percebe quando desafinou e corrige", "Canta afinado junto com o grupo ou o backing"]},
        {"id": "diccao", "nome": "Dicção, vogais e projeção", "criterios": [
            "Vogais puras e iguais às do grupo", "Consoantes claras (trava-línguas)", "Projeta a voz sem gritar",
            "S, R e T finais juntos no corte", "A letra é entendida por quem ouve"]},
        {"id": "interpretacao", "nome": "Interpretação e ministração", "criterios": [
            "Frase com começo, ápice e fim", "Forte e suave no lugar certo", "Expressão e postura de acordo com a letra",
            "Segue o regente ou o ministro", "Atitude de ministro (preparo, pontualidade, equipe)"]},
    ]},
    "regencia": {"nome": "Regência", "materias": [
        {"id": "postura", "nome": "Postura e ictus", "criterios": [
            "Postura firme e relaxada", "Gesto na altura certa (plano de regência)", "Ictus claro: o ponto do tempo aparece",
            "Mão direita e mão esquerda com funções diferentes", "Olhar no grupo, não só na partitura"]},
        {"id": "padroes", "nome": "Padrões de compasso", "criterios": [
            "Rege 2/4 corretamente", "Rege 3/4 corretamente", "Rege 4/4 corretamente",
            "Rege 6/8 em 2 e em 6", "Mantém o andamento junto com o metrônomo"]},
        {"id": "entradas", "nome": "Entradas, cortes e anacruse", "criterios": [
            "Dá a preparação um tempo antes", "Faz a entrada em anacruse", "Corte claro e todos juntos",
            "Fermata: segura e solta no lugar certo", "Muda o andamento sem perder o grupo"]},
        {"id": "expressao", "nome": "Dinâmica e caráter", "criterios": [
            "Gesto pequeno para suave e grande para forte", "Mostra legato, staccato, marcato e acento",
            "Mão esquerda pede mais e menos volume", "Rosto e energia de acordo com a música", "Crescendo e diminuendo claros"]},
        {"id": "ensaio", "nome": "Comunicação e ensaio", "criterios": [
            "Usa os sinais combinados (repetir, refrão, final, volume)", "Planeja o ensaio antes", "Fala pouco e mostra muito",
            "Organiza naipes e posições", "Conduz o grupo com respeito e liderança"]},
    ]},
    # 20/11/2026 (pedido do Rinaldo): curso de Bateria — o professor avalia; os exercícios com nota da aba Bateria
    # (tocar no tempo, rudimentos, segure o tempo) servem de treino e de recuperação.
    "bateria": {"nome": "Bateria", "materias": [
        {"id": "tempo", "nome": "Pulso e tempo", "criterios": [
            "Toca junto com o metrônomo sem correr nem atrasar", "Mantém o andamento quando o clique some",
            "Conta os tempos e entra no 1", "Toca colcheias iguais", "Não acelera nas partes fortes da música"]},
        {"id": "rudimentos", "nome": "Rudimentos e técnica", "criterios": [
            "Toque simples (D E D E) regular", "Toque duplo (D D E E) regular", "Paradiddle (D E D D E D E E) no tempo",
            "Pegada e postura relaxadas", "Batidas com o mesmo volume nas duas mãos"]},
        {"id": "ritmos", "nome": "Ritmos de louvor", "criterios": [
            "Balada (louvor lento)", "Pop / louvor animado", "6/8 de adoração",
            "Shuffle ou ritmo brasileiro (baião)", "Troca de ritmo sem parar a música"]},
        {"id": "viradas", "nome": "Viradas e dinâmica", "criterios": [
            "Virada de 1 compasso voltando no tempo 1", "Prato no começo da parte nova", "Toca suave nas partes calmas",
            "Cresce junto com a música", "Termina junto com a banda"]},
        {"id": "banda", "nome": "Tocar com a banda", "criterios": [
            "Escuta o cantor e a banda enquanto toca", "Segue o ministro ou o regente", "Entra e para nos sinais combinados",
            "Volume certo para o tamanho da igreja", "Atitude de ministro (preparo, pontualidade, equipe)"]},
    ]},
    # 21/11/2026 (pedido do Rinaldo): curso de Músicos (violão, teclado, contrabaixo) — o professor avalia;
    # a Percepção da aba Músicos (Que nota é essa? / Maior ou menor?) serve de treino e de recuperação.
    "musico": {"nome": "Músicos (violão, teclado, baixo)", "materias": [
        {"id": "tecnica", "nome": "Postura e técnica", "criterios": [
            "Postura e posição das mãos relaxadas", "Afina o próprio instrumento com o afinador", "Troca de acordes sem parar o ritmo",
            "Toca limpo (sem notas abafadas ou trastejando)", "Cuida do instrumento (cordas, cabos, guardar)"]},
        {"id": "harmonia", "nome": "Acordes e cifras", "criterios": [
            "Toca os acordes maiores e menores", "Conhece o campo harmônico do tom (I, IV, V e vi)", "Lê e toca pela cifra",
            "Usa acorde com baixo invertido (ex.: C/E)", "Muda a música de tom (transposição)"]},
        {"id": "percepcao", "nome": "Percepção e ouvido", "criterios": [
            "Reconhece a nota tocada", "Diferencia acorde maior de menor", "Acha o tom da música de ouvido",
            "Percebe quando o instrumento está desafinado", "Tira uma música simples de ouvido"]},
        {"id": "ritmo", "nome": "Ritmo e levadas", "criterios": [
            "Toca junto com o metrônomo", "Levada de balada (louvor lento)", "Levada animada (pop)",
            "6/8 de adoração", "Troca de levada e de intensidade sem parar"]},
        {"id": "banda", "nome": "Tocar com a banda", "criterios": [
            "Acompanha o cantor no tom dele", "Respeita o espaço dos outros instrumentos (não embola)", "Segue o ministro ou o regente e os sinais",
            "Volume e timbre certos", "Atitude de ministro (preparo, pontualidade, equipe)"]},
    ]},
}
VERSAO = "4.0"  # 22/11/2026: gestão de professores
TURMAS = ("som", "voz", "regencia", "bateria", "musico")  # também é o TIPO de acesso do treino em casa (20/11/2026)  # aula com turmas: o professor manda um exercício para cada turma pelo app
# Recuperação (16/11/2026, regras do Rinaldo): matéria abaixo de 50% fica "em recuperação". O aluno recupera com
# 3 treinos de 80% ou mais, em dias diferentes, no treino ligado àquela matéria (em casa ou na aula). Aí aparece
# para o professor APROVAR; a matéria fica com a média dos treinos daquele assunto (mínimo 50%, máximo 79%).
DIAS_RECUPERACAO = 3
NOTA_TREINO_BOM = 80
RECUPERACAO = {
    ("louvor", "respiracao"): (["respiracao"], "Respiração (sssss)"),
    ("louvor", "saude"): (["aquecimento"], "Aquecimento (brrr, trrr, canudo, sirene, escala ou hum)"),
    ("louvor", "afinacao"): (["afinacao", "segunda"], "Afinação ou Segunda voz"),
    ("louvor", "diccao"): (["vogais"], "Vogais e projeção (nota longa)"),
    ("regencia", "postura"): (["regencia"], "Regência com câmera"),
    ("regencia", "padroes"): (["regencia"], "Regência com câmera"),
    ("som", "*"): (["ouvido"], "Treino de ouvido"),
    ("bateria", "tempo"): (["bateria"], "Bateria · Exercícios com nota (tocar no tempo ou segure o tempo)"),
    ("bateria", "rudimentos"): (["bateria"], "Bateria · Exercícios com nota (rudimentos)"),
    ("musico", "percepcao"): (["musico"], "Músicos · Percepção (Que nota é essa? ou Maior ou menor?)"),
    ("musico", "harmonia"): (["musico"], "Músicos · Percepção (Maior ou menor?)"),
}
FAMILIAS_POR_NOME = (("Afinação", "afinacao"), ("Segunda voz", "segunda"), ("Aquecimento", "aquecimento"), ("Vogais", "vogais"), ("Respiração", "respiracao"))


def familia_de(t: dict) -> str:
    """De que treino é (pelo tipo e pelo começo do nome): afinacao, segunda, aquecimento, vogais, respiracao, ouvido, regencia."""
    if t.get("area") in ("ouvido", "regencia", "bateria", "musico"):
        return t["area"]
    nome = str(t.get("treino") or "")
    return next((f for pre, f in FAMILIAS_POR_NOME if nome.startswith(pre)), "")


def dia_de(texto) -> str:
    """'16/11/2026 10:23' ou '16/11/2026' -> '2026-11-16' (para comparar datas)."""
    try:
        return datetime.strptime(str(texto)[:10], "%d/%m/%Y").strftime("%Y-%m-%d")
    except ValueError:
        return ""
# Treino em casa (16/11/2026): o aluno treina pelo site no celular e a nota chega aqui pela nuvem.
# A chave do professor fica FORA da pasta do projeto (não vai para o git): %LOCALAPPDATA%\RMD_AudioLab\nuvem.json
ARQ_NUVEM = Path(os.getenv("AUDIOLAB_NUVEM") or (Path(os.getenv("LOCALAPPDATA") or Path.home()) / "RMD_AudioLab" / "nuvem.json"))
ALFABETO_CODIGO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def nuvem_config(arq: Path | None = None) -> dict | None:
    try:
        d = json.loads((arq or ARQ_NUVEM).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and d.get("url") and len(str(d.get("chave") or "")) >= 30 else None


# endereços da nuvem e do app dos alunos (não são segredo: estão no próprio app do aluno). Usados para ativar um AudioLab novo.
URL_NUVEM_PADRAO = "https://cxzzutbijljjteapowuv.supabase.co/functions/v1/audiolab"
SITE_PADRAO = "https://rmd-audiolab.github.io/"
# atualização automática (22/11/2026): só no AudioLab instalado no computador de um professor (tem este arquivo-marca).
# O AudioLab do Rinaldo (pasta do projeto) não tem a marca e nunca se atualiza sozinho.
MARCA_PROFESSOR = RAIZ / "instalacao_professor.txt"
URL_ATUALIZACAO = os.getenv("AUDIOLAB_URL_ATUALIZACAO") or (SITE_PADRAO + "professor/versao.json")


def _versao_num(v) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "0"))[:4]) or (0,)


def chamar_nuvem(corpo: dict, timeout: int = 20) -> dict:
    """Chama a função 'audiolab' da nuvem com a chave do professor. Erros viram mensagens simples."""
    cfg = nuvem_config()
    if not cfg:
        raise ValueError("O treino em casa não está configurado neste computador.")
    return _postar_nuvem(cfg["url"], {**corpo, "chave": cfg["chave"]}, timeout)


def chamar_nuvem_sem_chave(corpo: dict, timeout: int = 20) -> dict:
    """Só para a ativação: o computador novo ainda não tem a chave do professor."""
    return _postar_nuvem(URL_NUVEM_PADRAO, corpo, timeout)


def _postar_nuvem(url: str, corpo: dict, timeout: int = 20) -> dict:
    dados = json.dumps(corpo).encode("utf-8")
    req = urllib.request.Request(url, data=dados, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read() or b"{}").get("erro")
        except ValueError:
            msg = None
        raise ValueError(msg or f"A nuvem respondeu com erro {e.code}.") from None
    except (urllib.error.URLError, OSError, TimeoutError):
        raise ValueError("Sem internet agora. O treino em casa precisa de internet neste computador.") from None
# treinos com nota guardada na pasta do aluno (fora da trilha da mesa e da avaliação do professor)
AREAS_TREINO = {"voz": "Laboratório da voz", "ouvido": "Treino de ouvido", "regencia": "Regência com câmera", "bateria": "Bateria", "musico": "Músicos (percepção)"}
MODOS_AUDIO = ("original", "junto", "voz", "instrumental")  # como tocar um louvor já separado
SENHA_PADRAO = "1234"
ITERACOES = 200_000
COOKIE = "al_prof"

# ---------------------------------------------------------------------------- mesa do aluno
# nome -> (mínimo, máximo, valor normal)
CONTROLES = {
    "voz_ganho": (-20, 40, 10), "voz_fader": (-60, 10, 0), "voz_pan": (-100, 100, 0),
    "voz_grave": (-12, 12, 0), "voz_mgrave": (-12, 12, 0), "voz_medio": (-12, 12, 0),
    "voz_magudo": (-12, 12, 0), "voz_agudo": (-12, 12, 0),
    "voz_hpf": (0, 1, 0), "voz_comp": (0, 1, 0), "voz_fx": (0, 1, 0), "voz_atraso": (0, 500, 0),
    "mus_ganho": (-20, 40, 0), "mus_fader": (-60, 10, -4), "mus_pan": (-100, 100, 0),
    "mus_grave": (-12, 12, 0), "mus_mgrave": (-12, 12, 0), "mus_medio": (-12, 12, 0),
    "mus_magudo": (-12, 12, 0), "mus_agudo": (-12, 12, 0), "mus_hpf": (0, 1, 0),
    "master": (-60, 6, 0),
}


def controles_normais() -> dict:
    return {k: v[2] for k, v in CONTROLES.items()}


BANDAS = {"medio": ("MÉDIO", 1000, "1 kHz"), "magudo": ("MÉDIO-AGUDO", 2500, "2,5 kHz"), "agudo": ("AGUDO", 8000, "8 kHz")}
BANDAS_VOZ = ("voz_grave", "voz_mgrave", "voz_medio", "voz_magudo", "voz_agudo")


def laco_microfonia(c: dict, banda: str = "magudo") -> float:
    """Quanto o sistema passa do ponto de realimentação na frequência do apito (acima de 0 = microfonia)."""
    return (c["voz_ganho"] - 16) + c["voz_fader"] + c["voz_" + banda] + max(c["master"], 0)


def _entre(v, a, b):
    return a <= v <= b


def _microfonia(var: dict):
    b = var.get("banda", "magudo")
    nome, _f, txt = BANDAS[b]
    return [
        ("Acabou com a microfonia", lambda c: laco_microfonia(c, b) <= 0,
         f"O apito continua: reduza o {nome} ({txt}) e depois o GANHO."),
        (f"Cortou a frequência do apito no EQ ({nome})", lambda c: c["voz_" + b] <= -3,
         f"Use o EQ no {nome} ({txt}) em vez de só abaixar o volume de tudo."),
        ("A voz continua audível", lambda c: c["voz_fader"] >= -15 and c["voz_ganho"] >= 0 and c["master"] >= -20,
         "A voz quase sumiu: o objetivo é tirar o apito, não calar o pregador."),
        ("Não exagerou nas outras faixas", lambda c: all(abs(c[k]) <= 6 for k in BANDAS_VOZ if k != "voz_" + b),
         "Mexeu demais em faixas que não tinham o problema."),
    ]


# Cada exercício: problema inicial, critérios (o que deveria fazer, teste, dica), teoria (aula guiada) e dica do nível fácil.
EXERCICIOS = {
    "microfonia": {
        "nome": "Microfonia (realimentação)", "duracao": 180, "ordem": 3,
        "publico": "Um apito está saindo nas caixas. Controle a microfonia sem perder a voz.",
        "instrucao": "Tem um apito (realimentação). Corrija como na mesa real: primeiro o EQ na faixa do apito, depois o ganho, sem sumir com a voz.",
        "teoria": "Microfonia é o som da caixa voltando para o microfone e sendo amplificado de novo, em círculo. Ela aparece numa frequência só (um apito). A correção profissional é cortar essa frequência no EQ e, se precisar, reduzir o ganho — sem calar quem está falando.",
        "dica": "Procure o apito no gráfico, corte essa faixa do EQ em -6 dB e baixe o GANHO até o apito sumir.",
        "problema": lambda var: {"voz_ganho": 34, "voz_" + var.get("banda", "magudo"): 8, "voz_fader": 6},
        "criterios": _microfonia,
    },
    "abafada": {
        "nome": "Voz abafada", "duracao": 180, "ordem": 4,
        "publico": "A voz está embolada e sem clareza. Devolva a inteligibilidade.",
        "instrucao": "A voz está embolada (excesso de grave e médio-grave, falta de brilho). Limpe a voz sem deixá-la fina ou estridente.",
        "teoria": "A região de 200 a 400 Hz dá corpo à voz, mas em excesso deixa tudo embolado, como se a pessoa falasse com a mão na boca. O brilho e a clareza das palavras vêm dos agudos.",
        "dica": "Reduza o MÉDIO-GRAVE (300 Hz), baixe o GRAVE ou ligue o FILTRO DE GRAVES e devolva um pouco de AGUDO.",
        "problema": {"voz_mgrave": 9, "voz_grave": 6, "voz_agudo": -6},
        "criterios": [
            ("Tirou o excesso de MÉDIO-GRAVE (300 Hz)", lambda c: c["voz_mgrave"] <= 0, "O embolado está nos 300 Hz: reduza o MÉDIO-GRAVE."),
            ("Controlou o GRAVE (ou ligou o filtro de graves)", lambda c: c["voz_grave"] <= 0 or c["voz_hpf"] == 1, "Reduza o GRAVE ou ligue o FILTRO DE GRAVES (HPF)."),
            ("Recuperou o brilho sem exagerar", lambda c: _entre(c["voz_agudo"], -2, 6), "O AGUDO precisa voltar para perto de 0 a +6."),
            ("Não deixou a voz estridente", lambda c: c["voz_magudo"] <= 6, "Cuidado: MÉDIO-AGUDO alto demais deixa a voz ardida."),
        ],
    },
    "estridente": {
        "nome": "Voz estridente (ardida)", "duracao": 180, "ordem": 5,
        "publico": "A voz está ardida, cansando o ouvido. Deixe-a agradável.",
        "instrucao": "A voz está ardida, com excesso de médio-agudo e agudo. Suavize sem abafar.",
        "teoria": "Entre 2 e 5 kHz fica a região mais sensível do ouvido humano. Um pouco dá clareza; demais, cansa e machuca. O segredo é reduzir só o excesso, sem abafar.",
        "dica": "Reduza o MÉDIO-AGUDO (2,5 kHz) e deixe o AGUDO perto de 0.",
        "problema": {"voz_magudo": 9, "voz_agudo": 6},
        "criterios": [
            ("Reduziu o MÉDIO-AGUDO (2,5 kHz)", lambda c: c["voz_magudo"] <= 0, "A ardência está no MÉDIO-AGUDO: reduza."),
            ("Agudo equilibrado", lambda c: _entre(c["voz_agudo"], -6, 2), "Deixe o AGUDO entre -6 e +2."),
            ("A voz não ficou abafada", lambda c: c["voz_medio"] >= -6 and c["voz_mgrave"] <= 6, "Não corte o MÉDIO nem aumente o MÉDIO-GRAVE para compensar."),
        ],
    },
    "zumbido": {
        "nome": "Zumbido e ronco no grave", "duracao": 150, "ordem": 2,
        "publico": "Há um ronco grave (60 Hz) no som. Limpe sem tirar o corpo da voz.",
        "instrucao": "Tem um zumbido grave (60 Hz, ronco de energia/manuseio). Use o filtro de graves e o EQ, mantendo o corpo da voz.",
        "teoria": "A voz quase não tem nada abaixo de 100 Hz. O que aparece ali costuma ser ronco da rede elétrica (60 Hz), vento ou batida no microfone. O FILTRO DE GRAVES (HPF) corta essa região sem prejudicar a voz.",
        "dica": "Ligue o FILTRO DE GRAVES e baixe um pouco o GRAVE.",
        "problema": {"voz_hpf": 0, "voz_grave": 6}, "zumbido": True,
        "criterios": [
            ("Ligou o FILTRO DE GRAVES (HPF)", lambda c: c["voz_hpf"] == 1, "O HPF corta o que está abaixo de 100 Hz, onde mora o ronco."),
            ("Reduziu o GRAVE", lambda c: c["voz_grave"] <= 0, "Baixe o GRAVE (100 Hz)."),
            ("Manteve o corpo da voz", lambda c: c["voz_mgrave"] >= -6 and c["voz_medio"] >= -6, "Não corte o MÉDIO-GRAVE/MÉDIO: a voz fica fina."),
        ],
    },
    "atraso": {
        "nome": "Atraso / eco na voz", "duracao": 150, "ordem": 8,
        "publico": "A voz está chegando duas vezes (eco). Encontre e corrija a causa.",
        "instrucao": "A voz está repetindo (atraso no canal e efeito de eco ligado). Corrija a causa — abaixar o volume não resolve atraso.",
        "teoria": "Quando o som da caixa chega bem depois do som direto da pessoa, o ouvido percebe duas vozes (eco). As causas comuns são o ATRASO (delay) do canal configurado errado e o EFEITO de eco ligado sem querer.",
        "dica": "Traga o ATRASO DO CANAL para 0 ms e desligue o EFEITO.",
        "problema": {"voz_atraso": 380, "voz_fx": 1},
        "criterios": [
            ("Zerou o ATRASO do canal (até 20 ms)", lambda c: c["voz_atraso"] <= 20, "O atraso do canal está alto: traga o ATRASO para perto de 0 ms."),
            ("Desligou o EFEITO de eco", lambda c: c["voz_fx"] == 0, "O EFEITO (eco) estava ligado."),
            ("Não tentou resolver só abaixando o volume", lambda c: _entre(c["voz_fader"], -15, 6), "Abaixar o fader não corrige atraso; deixe a voz no nível normal."),
        ],
    },
    "equilibrio": {
        "nome": "Voz sumindo na música", "duracao": 180, "ordem": 1,
        "publico": "A música está cobrindo a voz. Equilibre os dois.",
        "instrucao": "A música está mais alta que a voz. Equilibre: a voz deve ficar um pouco acima da música, sem saturar o master.",
        "teoria": "No culto, a mensagem e a letra precisam ser entendidas. Por isso a voz principal fica um pouco acima dos instrumentos. Quem equilibra é o FADER de cada canal; o MASTER controla o total.",
        "dica": "Suba o FADER da VOZ e baixe o FADER da MÚSICA até a voz ficar uns 6 dB acima.",
        "problema": {"voz_fader": -12, "mus_fader": 4},
        "criterios": [
            ("A voz ficou acima da música (3 a 12 dB)", lambda c: _entre(c["voz_fader"] - c["mus_fader"], 3, 12), "Deixe o fader da VOZ de 3 a 12 dB acima do fader da MÚSICA."),
            ("A voz não ficou baixa demais", lambda c: c["voz_fader"] >= -10, "A VOZ ainda está muito baixa."),
            ("Master sem saturar", lambda c: _entre(c["master"], -12, 3), "Deixe o MASTER entre -12 e +3 dB."),
        ],
    },
    "saturacao": {
        "nome": "Voz distorcida (ganho alto demais)", "duracao": 150, "ordem": 6,
        "publico": "A voz está rachada, distorcida. Encontre o ponto certo do ganho.",
        "instrucao": "O GANHO está tão alto que a voz distorce, e alguém tentou compensar baixando o fader. Acerte a estrutura de ganho.",
        "teoria": "O GANHO ajusta quanto sinal entra na mesa; o FADER ajusta quanto vai para as caixas. Ganho alto demais distorce (racha) e não há fader que conserte. Primeiro acerte o ganho, depois o volume no fader.",
        "dica": "Baixe o GANHO até a distorção sumir (por volta de +10) e suba o FADER perto de 0.",
        "problema": {"voz_ganho": 38, "voz_fader": -14},
        "criterios": [
            ("Ganho na faixa certa (sem distorcer)", lambda c: _entre(c["voz_ganho"], 4, 20), "Deixe o GANHO entre +4 e +20: acima disso a voz racha."),
            ("Volume acertado no FADER", lambda c: c["voz_fader"] >= -6, "Depois de acertar o ganho, suba o FADER da voz."),
            ("Master sem saturar", lambda c: _entre(c["master"], -12, 3), "Deixe o MASTER entre -12 e +3 dB."),
        ],
    },
    "dinamica": {
        "nome": "Voz com picos (gritos e sussurros)", "duracao": 150, "ordem": 7,
        "publico": "A voz oscila entre muito baixa e muito alta. Controle a dinâmica.",
        "instrucao": "O pregador alterna sussurros e gritos. Use o COMPRESSOR para segurar os picos, sem subir demais o ganho.",
        "teoria": "O COMPRESSOR reduz automaticamente os momentos mais altos, deixando a voz mais constante. Ele não substitui o ganho correto: com ganho exagerado, o compressor só aumenta o risco de microfonia.",
        "dica": "Ligue o COMPRESSOR e deixe o GANHO entre +6 e +22.",
        "problema": {"voz_comp": 0, "voz_ganho": 28}, "picos": True,
        "criterios": [
            ("Ligou o COMPRESSOR", lambda c: c["voz_comp"] == 1, "O compressor segura os picos de volume."),
            ("Ganho controlado", lambda c: _entre(c["voz_ganho"], 6, 22), "Deixe o GANHO entre +6 e +22."),
            ("A voz continua presente", lambda c: c["voz_fader"] >= -10, "Não baixe demais o FADER da voz."),
        ],
    },
    "panorama": {
        "nome": "Voz de um lado só", "duracao": 120, "ordem": 0,
        "publico": "Metade da igreja não ouve a voz. Acerte o panorama.",
        "instrucao": "A voz está toda em uma caixa e a música puxada para o outro lado. Centralize a voz e equilibre a música.",
        "teoria": "O PANORAMA (pan) decide quanto do canal vai para a caixa da esquerda e da direita. Em igreja, a voz principal fica no centro para que todos os lados ouçam igual.",
        "dica": "Coloque o PANORAMA da VOZ no 0 (centro) e o da MÚSICA perto do centro.",
        "problema": {"voz_pan": -100, "mus_pan": 60},
        "criterios": [
            ("Voz no centro", lambda c: abs(c["voz_pan"]) <= 15, "Traga o PANORAMA da VOZ para perto de 0."),
            ("Música equilibrada nos dois lados", lambda c: abs(c["mus_pan"]) <= 30, "O PANORAMA da MÚSICA está puxado para um lado."),
        ],
    },
}
NIVEIS = {"facil": "Fácil", "medio": "Médio", "dificil": "Difícil"}


def problema_de(tipo: str, var: dict) -> dict:
    p = EXERCICIOS[tipo]["problema"]
    return p(var) if callable(p) else dict(p)


def criterios_de(tipo: str, var: dict) -> list:
    c = EXERCICIOS[tipo]["criterios"]
    return c(var) if callable(c) else c


def avaliar(tipo: str, controles: dict, var: dict | None = None) -> dict:
    criterios = criterios_de(tipo, var or {})
    c = {**controles_normais(), **(controles or {})}
    acertos, erros = [], []
    for nome, teste, dica in criterios:
        if teste(c):
            acertos.append(nome)
        else:
            erros.append(f"{nome} — {dica}")
    nota = round(100 * len(acertos) / len(criterios))
    retorno = "CORREÇÃO BOA" if nota >= 80 else ("CORREÇÃO PARCIAL" if nota >= 50 else "PRECISA CORRIGIR")
    return {"nota": nota, "acertos": acertos, "erros": erros, "retorno": retorno}


# ---------------------------------------------------------------------------- segurança
def hash_senha(senha: str, sal: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), bytes.fromhex(sal), ITERACOES).hex()


def ip_rede() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


_SEM_JANELA = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW: não pisca janela preta ao chamar programas do Windows

_PS_HOTSPOT = r"""
$ErrorActionPreference = 'Stop'
function Saida($o) { [Console]::OutputEncoding = [Text.Encoding]::UTF8; Write-Output ('@@' + ($o | ConvertTo-Json -Compress)) }
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $null = [Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType = WindowsRuntime]
  $null = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime]
  $acao = '__ACAO__'
  $cp = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
  if (-not $cp) { foreach ($p in [Windows.Networking.Connectivity.NetworkInformation]::GetConnectionProfiles()) { $cp = $p; break } }
  if (-not $cp) { Saida @{ ok = $false; erro = 'sem_rede' }; exit }
  $tm = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($cp)
  $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  function Aguardar($op) {
    $t = $asTask.MakeGenericMethod([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult]).Invoke($null, @($op))
    if (-not $t.Wait(30000)) { throw 'tempo esgotado' }
    return $t.Result
  }
  $msg = ''
  if ($acao -eq 'ligar' -and $tm.TetheringOperationalState -ne 'On') {
    $r = Aguardar ($tm.StartTetheringAsync())
    if ($r.Status -ne 'Success') { $msg = [string]$r.Status + ' ' + [string]$r.AdditionalErrorMessage }
  }
  if ($acao -eq 'desligar' -and $tm.TetheringOperationalState -eq 'On') {
    $r = Aguardar ($tm.StopTetheringAsync())
    if ($r.Status -ne 'Success') { $msg = [string]$r.Status + ' ' + [string]$r.AdditionalErrorMessage }
  }
  $cfg = $tm.GetCurrentAccessPointConfiguration()
  Saida @{ ok = ($msg -eq ''); erro = $msg; ligado = ($tm.TetheringOperationalState -eq 'On'); ssid = [string]$cfg.Ssid; senha = [string]$cfg.Passphrase; clientes = [int]$tm.ClientCount; max = [int]$tm.MaxClientCount }
} catch { Saida @{ ok = $false; erro = [string]$_.Exception.Message } }
"""


def _hotspot_ps(acao: str = "estado") -> dict:
    """Liga, desliga ou consulta o Hotspot móvel do Windows (Wi-Fi do próprio computador). Nunca levanta erro: devolve {ok, erro, ligado, ssid, senha, clientes}."""
    if acao not in ("estado", "ligar", "desligar"):
        raise ValueError("ação inválida")
    if os.name != "nt":
        return {"ok": False, "erro": "so_windows"}
    import base64
    cmd = _PS_HOTSPOT.replace("__ACAO__", acao)
    cod = base64.b64encode(cmd.encode("utf-16-le")).decode("ascii")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", cod],
                           capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=60, creationflags=_SEM_JANELA)
    except (OSError, subprocess.SubprocessError) as e:
        return {"ok": False, "erro": f"não consegui chamar o Windows ({e})"}
    for linha in reversed((r.stdout or "").splitlines()):
        if linha.startswith("@@"):
            try:
                d = json.loads(linha[2:])
                return d if isinstance(d, dict) else {"ok": False, "erro": "resposta inesperada"}
            except ValueError:
                break
    return {"ok": False, "erro": ((r.stderr or "").strip()[:200] or "o Windows não respondeu")}



_REGRA_FW = "RMD AudioLab 49326-49327"


def firewall_liberado() -> bool:
    """True se a regra do Firewall que deixa os celulares da sala abrirem o AudioLab já existe."""
    if os.name != "nt":
        return True
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule", f"name={_REGRA_FW}"], capture_output=True, text=True,
                           errors="ignore", timeout=15, creationflags=_SEM_JANELA)
        return r.returncode == 0 and "49326" in (r.stdout or "")
    except (OSError, subprocess.SubprocessError):
        return False


def liberar_firewall() -> dict:
    """Cria a regra do Firewall (só rede local). O Windows pede autorização na tela: o professor toca em Sim."""
    if os.name != "nt":
        return {"ok": True, "ja": True}
    if firewall_liberado():
        return {"ok": True, "ja": True}
    import base64
    ps = ("try { Start-Process -FilePath netsh -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList @('advfirewall','firewall','add','rule',"
          f"'name=\"{_REGRA_FW}\"','dir=in','action=allow','protocol=TCP','localport=49326-49327','profile=any',"
          "'remoteip=LocalSubnet,192.168.0.0/16,10.0.0.0/8,172.16.0.0/12'); Write-Output '@@ok' } catch { Write-Output '@@recusou' }")
    cod = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", cod],
                           capture_output=True, text=True, errors="ignore", timeout=120, creationflags=_SEM_JANELA)
    except (OSError, subprocess.SubprocessError):
        return {"ok": False, "erro": "não consegui pedir a autorização ao Windows"}
    if firewall_liberado():
        return {"ok": True, "ja": False}
    return {"ok": False, "erro": "autorização não concedida" if "@@recusou" in (r.stdout or "") else "o Windows não liberou"}


def firewall_acao(acao: str = "estado") -> dict:
    """Estado/liberação do Firewall para os celulares da sala (vale para qualquer Wi-Fi, não só o hotspot do computador)."""
    if acao == "liberar":
        r = liberar_firewall()
        return {"ok": bool(r.get("ok")), "liberado": firewall_liberado(), "erro": None if r.get("ok") else (r.get("erro") or "não liberado")}
    return {"ok": True, "liberado": firewall_liberado(), "windows": os.name == "nt"}


def hotspot(acao: str = "estado") -> dict:
    """Wi-Fi do computador. Ao ligar, também libera o Firewall (o Windows pede autorização na tela)."""
    fw = None
    if acao == "ligar":
        fw = liberar_firewall()
    d = _hotspot_ps(acao)
    if fw is not None:
        d["firewall"] = bool(fw.get("ok"))
        if not fw.get("ok"):
            d["aviso_firewall"] = fw.get("erro") or "não liberado"
    return d



_REDE_IPS_CACHE: list[dict] = []
_REDE_IPS_ATUALIZADO = 0.0


def ips_rede() -> list[dict]:
    """Lista IPv4 LAN para permitir escolher a interface correta para o QR Code (inclui hotspot)."""
    global _REDE_IPS_CACHE, _REDE_IPS_ATUALIZADO
    agora = time.time()
    if agora - _REDE_IPS_ATUALIZADO < 5:
        return [dict(x) for x in _REDE_IPS_CACHE]

    encontrados = []
    if os.name == "nt":
        try:
            saida = subprocess.run(["ipconfig", "/all"], capture_output=True, text=True, errors="ignore", timeout=4, creationflags=_SEM_JANELA).stdout
            interface = "Adaptador de rede"
            desc_virtual = False
            for linha in saida.splitlines():
                limpa = linha.strip()
                if not limpa:
                    continue
                if re.search(r"^(?:Adaptador|Adapter)\b", limpa, re.I):
                    interface = limpa.rstrip(":")
                    desc_virtual = False
                if re.search(r"(?:Descrição|Description)[^:]*:\s*.*(?:VirtualBox|Tailscale|Loopback|Bluetooth)", limpa, re.I):
                    desc_virtual = True
                if desc_virtual or re.search(r"VirtualBox|Tailscale|Loopback|Bluetooth", interface, re.I):
                    continue
                m = re.search(r"[^\r\n]*IPv4[^\r\n:]*:\s*([0-9]{1,3}(?:\.[0-9]{1,3}){3})", linha, re.I)
                if not m:
                    continue
                ip = m.group(1)
                if ip.startswith(("127.", "169.254.", "0.")) or ip == "255.255.255.255" or ip == "192.168.56.1":
                    continue
                if not any(x["ip"] == ip for x in encontrados):
                    encontrados.append({"ip": ip, "interface": interface})
        except (OSError, subprocess.SubprocessError):
            pass

    rota = ip_rede()
    if rota != "127.0.0.1" and not any(x["ip"] == rota for x in encontrados):
        encontrados.insert(0, {"ip": rota, "interface": "Rede ativa (rota do computador)"})
    elif rota != "127.0.0.1":
        encontrados.sort(key=lambda x: x["ip"] != rota)

    _REDE_IPS_CACHE = encontrados
    _REDE_IPS_ATUALIZADO = agora
    return [dict(x) for x in encontrados]


def _limitar(nome: str, valor) -> float:
    a, b, _ = CONTROLES[nome]
    try:
        v = float(valor)
    except (TypeError, ValueError):
        raise ValueError("valor inválido")
    if v != v:  # NaN
        raise ValueError("valor inválido")
    v = max(a, min(b, v))
    return int(round(v)) if b == 1 else round(v, 1)


class Sala:
    """Estado da aula (com trava, gravado em disco)."""

    def __init__(self, pasta: Path):
        self.pasta = pasta
        self.pasta.mkdir(parents=True, exist_ok=True)
        self.arquivo = pasta / "audiolab.json"
        self.trava = threading.RLock()
        self.sessoes_prof: dict[str, float] = {}
        self.falhas: dict[str, list] = {}
        self.sep: dict[str, dict] = {}  # andamento da separação voz/instrumental de cada louvor (só em memória)
        self.vu: dict[str, tuple] = {}  # medidores ao vivo de cada aluno (só em memória)
        self.projecao: dict = {"modo": "painel", "tema": None, "slide": 0, "aluno": None}  # o que o telão mostra agora (só em memória)
        self.dados = self._ler()
        self._copia_do_dia()
        self.nuvem = chamar_nuvem  # nos testes é trocado por uma nuvem de mentira
        self.nuvem_sem_chave = chamar_nuvem_sem_chave  # ativação de um AudioLab novo (nos testes também é trocada)
        self.arq_nuvem = ARQ_NUVEM
        self._conta = None
        self.raiz_programa = RAIZ  # onde a atualização troca os arquivos (nos testes é uma pasta de mentira)
        self.casa_erro: str | None = None

    # ------------------------------------------------------------------ disco
    def _copia_do_dia(self) -> None:
        """Guarda uma cópia por dia das notas e configurações em dados/copias (nunca apaga as antigas).
        Se o audiolab.json estragar, dá para voltar a cópia do dia anterior."""
        try:
            if not self.arquivo.is_file():
                return
            pasta = self.pasta / "copias"
            alvo = pasta / f"audiolab_{datetime.now():%Y-%m-%d}.json"
            if alvo.exists():
                return
            json.loads(self.arquivo.read_text(encoding="utf-8"))  # só copia um arquivo bom
            pasta.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self.arquivo, alvo)
        except (OSError, ValueError):
            pass

    def _ler(self) -> dict:
        base = {"config": {}, "historico": [], "aula": None, "louvores": []}
        try:
            d = json.loads(self.arquivo.read_text(encoding="utf-8"))
            base.update(d if isinstance(d, dict) else {})
        except (OSError, ValueError):
            pass
        cfg = base["config"]
        cfg.setdefault("nome_empresa", "RMD AudioLab")
        cfg.setdefault("tema", "escuro")
        if not cfg.get("senha_hash"):
            cfg["sal"] = secrets.token_hex(16)
            cfg["senha_hash"] = hash_senha(SENHA_PADRAO, cfg["sal"])
            cfg["senha_padrao"] = True
        return base

    def salvar(self) -> None:
        with self.trava:
            tmp = self.arquivo.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.dados, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.arquivo)
            self._copia_do_dia()

    # ------------------------------------------------------------------ professor
    def entrar_professor(self, senha: str, ip: str) -> str:
        agora = time.time()
        with self.trava:
            f = [t for t in self.falhas.get(ip, []) if agora - t < 300]
            if len(f) >= 5:
                raise PermissionError("Muitas tentativas. Aguarde alguns minutos.")
            cfg = self.dados["config"]
            if not hmac.compare_digest(hash_senha(senha or "", cfg["sal"]), cfg["senha_hash"]):
                f.append(agora)
                self.falhas[ip] = f
                raise PermissionError("Senha incorreta.")
            self.falhas.pop(ip, None)
            tok = secrets.token_urlsafe(24)
            self.sessoes_prof[tok] = agora + 12 * 3600
            return tok

    def professor_ok(self, tok: str | None) -> bool:
        with self.trava:
            fim = self.sessoes_prof.get(tok or "")
            return bool(fim and fim > time.time())

    def sair_professor(self, tok: str | None) -> None:
        with self.trava:
            self.sessoes_prof.pop(tok or "", None)

    def trocar_senha(self, atual: str, nova: str) -> None:
        with self.trava:
            cfg = self.dados["config"]
            if not hmac.compare_digest(hash_senha(atual or "", cfg["sal"]), cfg["senha_hash"]):
                raise PermissionError("A senha atual não confere.")
            nova = (nova or "").strip()
            if len(nova) < 4:
                raise ValueError("A nova senha precisa ter pelo menos 4 caracteres.")
            cfg["sal"] = secrets.token_hex(16)
            cfg["senha_hash"] = hash_senha(nova, cfg["sal"])
            cfg["senha_padrao"] = nova == SENHA_PADRAO
            self.salvar()

    def configurar(self, dados: dict) -> dict:
        with self.trava:
            cfg = self.dados["config"]
            if "nome_empresa" in dados:
                nome = " ".join(str(dados["nome_empresa"] or "").split())[:60]
                cfg["nome_empresa"] = nome or "RMD AudioLab"
            if "nome_curso" in dados:
                curso = " ".join(str(dados["nome_curso"] or "").split())[:80]
                cfg["nome_curso"] = curso or CURSO_PADRAO
            if dados.get("tema") in ("claro", "medio", "escuro"):
                cfg["tema"] = dados["tema"]
            self.salvar()
            return self.info()

    def info(self) -> dict:
        cfg = self.dados["config"]
        return {"nome_empresa": cfg["nome_empresa"], "nome_curso": cfg.get("nome_curso") or CURSO_PADRAO, "tema": cfg["tema"], "versao": VERSAO}

    # ------------------------------------------------------------------ louvores (músicas gravadas da aula)
    def pasta_louvores(self) -> Path:
        p = self.pasta / "louvores"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def louvores(self) -> list[dict]:
        return [{"id": x["id"], "nome": x["nome"], "tamanho": x["tamanho"], "playback": bool(x.get("playback")), "criado": x.get("criado", ""),
                 "separado": bool(x.get("voz") and x.get("inst")), "sep": self.sep.get(x["id"])}
                for x in self.dados.get("louvores", [])]

    def _louvor(self, lid: str) -> dict:
        for x in self.dados.get("louvores", []):
            if x["id"] == lid:
                return x
        raise KeyError("Louvor não encontrado.")

    def guardar_louvor(self, nome: str, ext: str, origem, tamanho: int, tipo: str = "louvor", de: str | None = None) -> dict:
        """Grava o arquivo de áudio que o professor enviou. tipo=louvor cria um item; tipo=playback anexa o instrumental a um louvor."""
        ext = ext.lower()
        if ext not in EXT_AUDIO:
            raise ValueError("Formato não aceito. Use MP3, M4A, WAV, OGG, OPUS, AAC, WEBM ou FLAC.")
        if tamanho <= 0 or tamanho > MAX_LOUVOR:
            raise ValueError(f"Arquivo vazio ou grande demais (máximo {MAX_LOUVOR // (1024 * 1024)} MB).")
        if tipo == "playback":
            with self.trava:
                item = self._louvor(de or "")
        elif len(self.dados.get("louvores", [])) >= 60:
            raise ValueError("A biblioteca já tem 60 louvores. Apague algum antes de enviar outro.")
        nome_arq = secrets.token_hex(8) + ext
        destino = self.pasta_louvores() / nome_arq
        falta = tamanho
        with open(destino, "wb") as f:
            while falta > 0:
                bloco = origem.read(min(256 * 1024, falta))
                if not bloco:
                    break
                f.write(bloco)
                falta -= len(bloco)
        if falta:
            destino.unlink(missing_ok=True)
            raise ValueError("O envio do arquivo foi interrompido. Tente de novo.")
        with self.trava:
            if tipo == "playback":
                antigo = item.get("playback")
                item["playback"] = nome_arq
                item["tamanho"] = item["tamanho"] + tamanho
                if antigo:
                    (self.pasta_louvores() / antigo).unlink(missing_ok=True)
            else:
                nome = " ".join(str(nome or "").split())[:80] or "Louvor"
                item = {"id": secrets.token_hex(5), "nome": nome, "arquivo": nome_arq, "playback": None, "tamanho": tamanho,
                        "criado": datetime.now().strftime("%d/%m/%Y")}
                self.dados.setdefault("louvores", []).append(item)
            self.salvar()
            return {"id": item["id"], "nome": item["nome"]}

    def apagar_louvor(self, lid: str, so_playback: bool = False) -> None:
        with self.trava:
            item = self._louvor(lid or "")
            if self.sep.get(lid, {}).get("estado") in ("instalando", "separando"):
                raise ValueError("Espere terminar a separação deste louvor antes de apagar.")
            arqs = [item.get("playback")] if so_playback else [item.get("arquivo"), item.get("playback"), item.get("voz"), item.get("inst")]
            for a in arqs:
                if a:
                    (self.pasta_louvores() / a).unlink(missing_ok=True)
            if so_playback:
                item["playback"] = None
            else:
                self.dados["louvores"].remove(item)
            self.salvar()

    def arquivo_louvor(self, lid: str, parte: str) -> Path:
        with self.trava:
            item = self._louvor(lid or "")
            nome = {"playback": item.get("playback"), "voz": item.get("voz"), "inst": item.get("inst")}.get(parte, item.get("arquivo"))
        if not nome:
            raise KeyError("Este louvor não tem esta parte (playback ou separação).")
        caminho = self.pasta_louvores() / nome
        if not caminho.is_file():
            raise KeyError("Arquivo do louvor não encontrado.")
        return caminho

    # ------------------------------------------------------------------ separar voz e instrumental (IA local, gratuita: Demucs)
    def _sep(self, lid: str, estado: str, pct: int, msg: str) -> None:
        self.sep[lid] = {"estado": estado, "pct": pct, "msg": msg}

    def separar(self, lid: str) -> None:
        with self.trava:
            self._louvor(lid or "")
            if any(v.get("estado") in ("instalando", "separando") for v in self.sep.values()):
                raise ValueError("Já existe uma separação em andamento. Espere terminar.")
            self._sep(lid, "instalando", 1, "Começando…")
        threading.Thread(target=self._separar_job, args=(lid,), daemon=True).start()

    def _separar_job(self, lid: str) -> None:
        raiz = Path(__file__).resolve().parent
        ia = self.pasta / "ia"
        py = ia / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        marca = ia / "pronto.txt"
        log = self.pasta / "separador.log"
        flags = 0x08000000 if os.name == "nt" else 0  # sem janela

        def anotar(texto: str) -> None:
            try:
                with open(log, "a", encoding="utf-8") as f:
                    f.write(f"{datetime.now():%d/%m/%Y %H:%M:%S} {texto}\n")
            except OSError:
                pass

        def rodar(cmd: list[str], tentar_sem_versao: list[str] | None = None) -> None:
            r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=flags)
            anotar("$ " + " ".join(cmd)[:300] + "\n" + (r.stdout or "")[-1500:] + (r.stderr or "")[-1500:])
            if r.returncode != 0 and tentar_sem_versao:
                return rodar(tentar_sem_versao)
            if r.returncode != 0:
                linhas = (r.stderr or r.stdout or "erro desconhecido").strip().splitlines() or ["erro desconhecido"]
                uteis = [x.strip() for x in linhas if x.strip().lower().startswith(("error:", "erro"))]
                motivo = (uteis[0] if uteis else linhas[-1])[:200]
                raise RuntimeError("a instalação da inteligência falhou (" + motivo + "). Detalhes em dados\\separador.log.")

        try:
            if not (py.is_file() and marca.is_file()):
                self._sep(lid, "instalando", 3, "Preparando a separação (só na 1ª vez, de 10 a 20 minutos, precisa de internet)…")
                base = Path(sys.executable)
                if os.name == "nt" and base.name.lower() == "pythonw.exe" and base.with_name("python.exe").is_file():
                    base = base.with_name("python.exe")
                if not py.is_file():
                    rodar([str(base), "-m", "venv", str(ia)])
                # Sem travar versões antigas: numpy<2 e torch 2.5.1 não existem prontos para o Python 3.14 (pip tentava compilar e falhava).
                # --prefer-binary: usa sempre os pacotes prontos para Windows, nunca tenta compilar.
                pip = [str(py), "-m", "pip", "install", "--no-input", "--disable-pip-version-check", "--prefer-binary"]
                self._sep(lid, "instalando", 8, "Baixando o motor de áudio (1/2)…")
                rodar(pip + ["numpy", "torch", "torchaudio"])
                self._sep(lid, "instalando", 45, "Baixando a inteligência de separação (2/2)…")
                rodar(pip + ["demucs==4.0.1", "soundfile", "imageio-ffmpeg"])
                marca.write_text("ok", encoding="utf-8")
            with self.trava:
                item = self._louvor(lid)
                entrada = self.pasta_louvores() / item["arquivo"]
            saida = self.pasta_louvores() / ("sep_" + lid)
            shutil.rmtree(saida, ignore_errors=True)
            self._sep(lid, "separando", 55, "Separando…")
            env = {**os.environ, "TORCH_HOME": str(ia / "modelos"), "PYTHONIOENCODING": "utf-8", "OMP_NUM_THREADS": str(os.cpu_count() or 4)}
            proc = subprocess.Popen([str(py), str(raiz / "separador.py"), str(entrada), str(saida)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, encoding="utf-8", errors="replace", env=env, creationflags=flags)
            erro = ""
            msg = "Separando…"
            for linha in proc.stdout:
                linha = linha.strip()
                if linha.startswith("PCT "):
                    try:
                        self._sep(lid, "separando", 55 + int(int(linha[4:]) * 0.44), msg)
                    except ValueError:
                        pass
                elif linha.startswith("MSG "):
                    msg = linha[4:]
                    self._sep(lid, "separando", self.sep[lid]["pct"], msg)
                elif linha.startswith("ERRO "):
                    erro = linha[5:]
                elif linha:
                    anotar(linha[:300])
            proc.wait()
            voz = next(iter(sorted(saida.glob("voz.*"))), None)
            inst = next(iter(sorted(saida.glob("instrumental.*"))), None)
            if proc.returncode != 0 or not voz or not inst:
                raise RuntimeError(erro or "A separação não terminou. Veja dados\\separador.log.")
            with self.trava:
                item = self._louvor(lid)
                for k in ("voz", "inst"):
                    if item.get(k):
                        (self.pasta_louvores() / item[k]).unlink(missing_ok=True)
                item["voz"] = secrets.token_hex(8) + voz.suffix
                item["inst"] = secrets.token_hex(8) + inst.suffix
                shutil.move(str(voz), str(self.pasta_louvores() / item["voz"]))
                shutil.move(str(inst), str(self.pasta_louvores() / item["inst"]))
                item["tamanho"] = int(item.get("tamanho", 0)) + (self.pasta_louvores() / item["voz"]).stat().st_size + (self.pasta_louvores() / item["inst"]).stat().st_size
                self.salvar()
            shutil.rmtree(saida, ignore_errors=True)
            self._sep(lid, "pronto", 100, "Pronto: voz e instrumental separados.")
        except Exception as e:  # noqa: BLE001
            anotar("ERRO: " + repr(e))
            self._sep(lid, "erro", 0, "Não foi possível separar: " + str(e)[:300])

    # ------------------------------------------------------------------ aula
    def _aula(self) -> dict:
        a = self.dados.get("aula")
        if not a:
            raise ValueError("Crie a sessão da aula primeiro.")
        return a

    def nova_sessao(self, nome_aula: str) -> dict:
        with self.trava:
            codigo = "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(5))
            self.dados["aula"] = {"codigo": codigo, "nome": " ".join(str(nome_aula or "").split())[:80] or "Treinamento de mesa",
                                  "criada": time.time(), "alunos": {}, "selecionado": None, "exercicio": None, "mensagem": ""}
            self.salvar()
            return self.dados["aula"]

    # 21/11/2026 (pedido do Rinaldo): na aula pelo Wi-Fi, só quem é OPERADOR DE SOM mexe na mesa.
    # A categoria vem do cadastro do treino em casa (tipo de acesso), achado pelo nome; quem não tem cadastro
    # entra sem categoria, como OBSERVADOR, e o professor marca a categoria na tela Alunos.
    @staticmethod
    def _nome_chave(nome: str) -> str:
        t = unicodedata.normalize("NFKD", str(nome or "")).encode("ascii", "ignore").decode()
        return " ".join(t.casefold().split())

    def _categoria_cadastro(self, nome: str):
        chave = self._nome_chave(nome)
        for c in self.dados.get("casa_alunos") or []:
            if c.get("ativo", True) and self._nome_chave(c.get("nome")) == chave:
                return [t for t in (c.get("turmas") or []) if t in TURMAS]
        return None

    def entrar_aluno(self, nome: str, codigo: str, apelido: str | None = None) -> dict:
        nome = " ".join(str(nome or "").split())[:40]
        apelido = " ".join(str(apelido or "").split())[:20] or nome.split(" ")[0]
        if not nome:
            raise ValueError("Digite o seu nome.")
        with self.trava:
            a = self.dados.get("aula")
            if not a or str(codigo or "").strip().upper() != a["codigo"]:
                raise PermissionError("Código da aula inválido. Leia o QR Code de novo.")
            for al in a["alunos"].values():
                if al["nome"].casefold() == nome.casefold():
                    raise ValueError("Já tem alguém com este nome na aula. Use nome e sobrenome.")
            aid = secrets.token_hex(6)
            tok = secrets.token_urlsafe(24)
            turmas = self._categoria_cadastro(nome)
            papel = "OPERADOR" if turmas and "som" in turmas else "OBSERVADOR"
            a["alunos"][aid] = {"id": aid, "nome": nome, "apelido": apelido, "token": tok, "papel": papel, "turmas": turmas, "entrou": time.time(),
                                "visto": time.time(), "controles": controles_normais(), "resultado": None, "terminou": False}
            # operador de som já entra com a mesa liberada; as outras categorias (e quem não tem cadastro) entram como OBSERVADOR
            if papel == "OPERADOR" and not a.get("selecionado"):
                a["selecionado"] = aid
            self.salvar()
            return {"token": tok, "id": aid, "nome": nome}

    def aluno_do_token(self, tok: str | None) -> dict:
        a = self.dados.get("aula")
        if a and tok:
            for al in a["alunos"].values():
                if hmac.compare_digest(al["token"], tok):
                    al["visto"] = time.time()
                    return al
        raise PermissionError("Você não está nesta aula. Entre de novo pelo QR Code.")

    def registrar_vu(self, al: dict, vu, som) -> None:
        """O celular do aluno manda, várias vezes por segundo, o que ele está ouvindo (medidores) — o professor vê ao vivo."""
        limpo = {}
        if isinstance(vu, dict):
            for k in ("voz", "mus", "master"):
                v = vu.get(k)
                if isinstance(v, (int, float)) and v == v:
                    limpo[k] = round(max(0.0, min(1.0, float(v))), 3)
        self.vu[al["id"]] = (time.time(), limpo, bool(som))

    def _aluno(self, aid: str) -> dict:
        al = self._aula()["alunos"].get(aid or "")
        if not al:
            raise KeyError("Aluno não encontrado.")
        return al

    def definir_papel(self, aid: str, papel: str) -> None:
        with self.trava:
            if papel not in ("OPERADOR", "OBSERVADOR"):
                raise ValueError("Função inválida.")
            al = self._aluno(aid)
            if papel == "OPERADOR" and "som" not in (al.get("turmas") or []):
                raise ValueError("Só operador de som pode mexer na mesa. Marque a categoria “Operador de som” primeiro.")
            al["papel"] = papel
            a = self._aula()
            if papel == "OPERADOR" and not a["selecionado"]:
                a["selecionado"] = aid  # primeiro operador já fica em destaque para os observadores e o professor
            self.salvar()

    def definir_categoria(self, aid: str, turma: str) -> None:
        """Categoria do aluno nesta aula (quem não tem cadastro no treino em casa). Operador de som vira OPERADOR; o resto, OBSERVADOR."""
        with self.trava:
            if turma not in TURMAS:
                raise ValueError("Categoria inválida.")
            al = self._aluno(aid)
            al["turmas"] = [turma]
            al["papel"] = "OPERADOR" if turma == "som" else "OBSERVADOR"
            a = self._aula()
            if al["papel"] == "OPERADOR" and not a["selecionado"]:
                a["selecionado"] = aid
            self.salvar()

    def selecionar(self, aid: str | None) -> None:
        with self.trava:
            a = self._aula()
            if aid:
                self._aluno(aid)
            a["selecionado"] = aid or None
            self.salvar()

    def remover(self, aid: str) -> None:
        with self.trava:
            a = self._aula()
            self._aluno(aid)
            del a["alunos"][aid]
            if a["selecionado"] == aid:
                a["selecionado"] = None
            self.salvar()

    def ligar_placar(self, ligado: bool) -> None:
        with self.trava:
            self._aula()["placar"] = bool(ligado)
            self.salvar()

    @staticmethod
    def id_resultado(h: dict) -> str:
        """Identificador estável de uma tentativa (as antigas não tinham id): usa data, aluno, exercício, nota e tempo."""
        if h.get("id"):
            return str(h["id"])
        base = "|".join(str(h.get(k, "")) for k in ("data", "aluno", "exercicio", "nota", "tempo_s", "sessao"))
        return hashlib.sha1(base.encode("utf-8")).hexdigest()[:12]

    def historico(self) -> list[dict]:
        """Todas as tentativas (mais novas primeiro), cada uma com o seu id para poder excluir."""
        return [{**h, "id": self.id_resultado(h)} for h in self.dados["historico"]][::-1]

    def apagar_resultados(self, aluno: str | None = None, ids: list | None = None) -> dict:
        """Exclui tentativas: todas de um aluno (aluno=nome) ou só algumas (ids).
        O que sai vai para 'historico_excluido' (reserva escondida, últimas 2000) para poder recuperar se foi engano."""
        nome = str(aluno or "").strip()
        alvo = {str(i) for i in (ids or []) if i}
        if not nome and not alvo:
            raise ValueError("Diga o aluno ou quais resultados excluir.")
        with self.trava:
            ficam, saem = [], []
            for h in self.dados["historico"]:
                (saem if (nome and h.get("aluno") == nome) or self.id_resultado(h) in alvo else ficam).append(h)
            if not saem:
                raise ValueError("Nenhum resultado encontrado para excluir.")
            agora = datetime.now().strftime("%d/%m/%Y %H:%M")
            reserva = self.dados.setdefault("historico_excluido", [])
            reserva.extend({**h, "excluido_em": agora} for h in saem)
            self.dados["historico_excluido"] = reserva[-2000:]
            self.dados["historico"] = ficam
            self.salvar()
            self._avisar_casa()
            return {"excluidos": len(saem)}

    # ------------------------------------------------------------------ treinos guardados na pasta do aluno
    def guardar_treino(self, aluno: str, area: str, treino: str, nota, detalhe: str = "", origem: str = "computador") -> dict:
        """Resultado de um treino (voz, ouvido ou regência) guardado na pasta do aluno."""
        nome = " ".join(str(aluno or "").split())[:60]
        if not nome:
            raise ValueError("Escreva o nome do aluno.")
        if area not in AREAS_TREINO:
            raise ValueError("Tipo de treino desconhecido.")
        try:
            valor = int(round(float(nota)))
        except (TypeError, ValueError):
            raise ValueError("Nota inválida.") from None
        reg = {"id": secrets.token_hex(6), "data": datetime.now().strftime("%d/%m/%Y %H:%M"), "aluno": nome, "area": area,
               "treino": " ".join(str(treino or "").split())[:80] or "Treino", "nota": max(0, min(100, valor)),
               "detalhe": " ".join(str(detalhe or "").split())[:300], "origem": "celular" if origem == "celular" else "computador"}
        with self.trava:
            lista = self.dados.setdefault("treinos", [])
            lista.append(reg)
            self.dados["treinos"] = lista[-5000:]
            self.salvar()
        return reg

    def treinos(self) -> dict:
        with self.trava:
            itens = list(self.dados.get("treinos") or [])[::-1]
            a = self.dados.get("aula")
            na_aula = [al["nome"] for al in (a or {}).get("alunos", {}).values()] if a else []
            conhecidos = sorted({h["aluno"] for h in self.dados["historico"]} | {t["aluno"] for t in itens}
                                | {n for c in (self.dados.get("avaliacoes") or {}).values() for n in c} | set(na_aula), key=str.casefold)
        return {"itens": itens, "areas": AREAS_TREINO, "alunos_conhecidos": conhecidos}

    def apagar_treinos(self, aluno: str | None = None, ids: list | None = None) -> dict:
        nome = str(aluno or "").strip()
        alvo = {str(i) for i in (ids or []) if i}
        if not nome and not alvo:
            raise ValueError("Diga o aluno ou quais treinos excluir.")
        with self.trava:
            ficam, saem = [], []
            for t in self.dados.get("treinos") or []:
                (saem if (nome and t.get("aluno") == nome) or t.get("id") in alvo else ficam).append(t)
            if not saem:
                raise ValueError("Nenhum treino encontrado para excluir.")
            agora = datetime.now().strftime("%d/%m/%Y %H:%M")
            reserva = self.dados.setdefault("treinos_excluidos", [])
            reserva.extend({**t, "excluido_em": agora} for t in saem)
            self.dados["treinos_excluidos"] = reserva[-2000:]
            self.dados["treinos"] = ficam
            self.salvar()
            return {"excluidos": len(saem)}

    # ------------------------------------------------------------------ recuperação com treinos
    def _progresso(self, aluno: str, familias: list, desde: str) -> tuple[int, int, int]:
        """(dias diferentes com treino de 80%+, média de todos os treinos daquele assunto, quantos treinos) desde a data da nota baixa."""
        alvo = aluno.casefold()
        qual = [t for t in self.dados.get("treinos") or [] if str(t.get("aluno", "")).casefold() == alvo
                and familia_de(t) in familias and dia_de(t.get("data")) >= desde]
        dias = {dia_de(t["data"]) for t in qual if t.get("nota", 0) >= NOTA_TREINO_BOM}
        media = round(sum(t.get("nota", 0) for t in qual) / len(qual)) if qual else 0
        return len(dias), media, len(qual)

    def recuperacoes(self) -> list[dict]:
        """Matérias abaixo de 50% que podem ser recuperadas com treinos, com o andamento de cada aluno."""
        itens = []
        with self.trava:
            def item(curso, curso_nome, materia, materia_nome, aluno, nota, data, fams, texto):
                desde = dia_de(data)
                feitos, media, qtd = self._progresso(aluno, fams, desde)
                itens.append({"curso": curso, "curso_nome": curso_nome, "materia": materia, "materia_nome": materia_nome, "aluno": aluno,
                              "nota": nota, "desde": desde, "familias": fams, "treino": texto, "feitos": min(feitos, DIAS_RECUPERACAO),
                              "precisa": DIAS_RECUPERACAO, "treinos": qtd, "pronta": feitos >= DIAS_RECUPERACAO,
                              "nota_recuperada": max(NOTA_CERTIFICADO, min(NOTA_MINIMA - 1, media))})
            notas = self.dados.get("avaliacoes") or {}
            for cid, c in CURSOS_AVALIADOS.items():
                for aluno, mats in (notas.get(cid) or {}).items():
                    for m in c["materias"]:
                        n = mats.get(m["id"])
                        regra = RECUPERACAO.get((cid, m["id"]))
                        if n and regra and n["nota"] < NOTA_CERTIFICADO:
                            item(cid, c["nome"], m["id"], m["nome"], aluno, n["nota"], n.get("data"), *regra)
            for al in self.trilha()["alunos"]:
                for tipo, best in al["melhores"].items():
                    if best["nota"] < NOTA_CERTIFICADO:
                        item("som", "Operação de Som", tipo, EXERCICIOS[tipo]["nome"], al["aluno"], best["nota"], best.get("data"), *RECUPERACAO[("som", "*")])
        return sorted(itens, key=lambda x: (not x["pronta"], x["aluno"].casefold(), x["curso"]))

    def aprovar_recuperacao(self, curso: str, aluno: str, materia: str) -> dict:
        """O professor aprova: a matéria fica com a média dos treinos (50% a 79%) e o certificado pode sair."""
        r = next((x for x in self.recuperacoes() if x["curso"] == curso and x["aluno"] == aluno and x["materia"] == materia), None)
        if not r:
            raise ValueError("Esta matéria não está em recuperação.")
        if not r["pronta"]:
            raise ValueError(f"Ainda falta treino: {r['feitos']} de {r['precisa']} dias com {NOTA_TREINO_BOM}% ou mais.")
        hoje = datetime.now()
        with self.trava:
            if curso == "som":
                self.dados["historico"].append({
                    "data": hoje.strftime("%d/%m/%Y %H:%M"), "aula": "Recuperação com treinos", "sessao": "-", "exercicio": EXERCICIOS[materia]["nome"],
                    "tipo": materia, "nivel": "—", "aluno": aluno, "papel": "RECUPERAÇÃO", "nota": r["nota_recuperada"], "acertos": 0, "erros": 0,
                    "tempo_s": 0, "detalhe": f"Recuperada com {r['treinos']} treino(s) de ouvido (nota antes: {r['nota']}%)", "id": secrets.token_hex(6)})
            else:
                reg = self.dados["avaliacoes"][curso][aluno][materia]
                obs = (reg.get("obs") or "").strip()
                reg.update({"nota": r["nota_recuperada"], "nota_original": r["nota"], "recuperada": True, "data": hoje.strftime("%d/%m/%Y"),
                            "obs": ((obs + " · ") if obs else "") + f"Recuperada com treinos (antes {r['nota']}%)"})
                reg["obs"] = reg["obs"][:200]
            self.salvar()
        try:
            self.casa_enviar_pendencias()
        except ValueError:
            pass  # sem internet: vai na próxima busca
        return {"nota": r["nota_recuperada"]}

    # ------------------------------------------------------------------ treino em casa (nuvem)
    def casa_estado(self) -> dict:
        cfg = nuvem_config()
        site = (cfg or {}).get("site") or ""
        with self.trava:
            conhecidos = {h["aluno"].casefold() for h in self.dados["historico"]} | {n.casefold() for c in (self.dados.get("avaliacoes") or {}).values() for n in c}
            # treinos de casa dos últimos 7 dias de cada aluno (para ver quem não treinou na semana)
            limite = datetime.now() - timedelta(days=7)
            semana: dict[str, int] = {}
            ultimo: dict[str, datetime] = {}
            for t in self.dados.get("treinos") or []:
                if t.get("origem") != "casa":
                    continue
                try:
                    quando = datetime.strptime(str(t.get("data")), "%d/%m/%Y %H:%M")
                except ValueError:
                    continue
                k = str(t.get("aluno") or "").casefold()
                if k not in ultimo or quando > ultimo[k]:
                    ultimo[k] = quando
                if quando >= limite:
                    semana[k] = semana.get(k, 0) + 1
            alunos = [{**a, "link": f"{site}?c={a['codigo']}" if site else "", "tem_aula": a["nome"].casefold() in conhecidos,
                       "treinos_semana": semana.get(a["nome"].casefold(), 0),
                       "ultimo_treino": ultimo[a["nome"].casefold()].strftime("%d/%m/%Y") if a["nome"].casefold() in ultimo else None}
                      for a in self.dados.get("casa_alunos") or []]
            return {"ligado": bool(cfg), "site": site, "alunos": sorted(alunos, key=lambda a: a["nome"].casefold()),
                    "ultima_busca": self.dados.get("casa_ultima_busca"), "erro": self.casa_erro}

    # ------------------------------------------------------------------ conta do professor e gestão (22/11/2026, pedido do Rinaldo)
    # Cada professor tem o seu AudioLab, ligado à conta dele na nuvem, com só os assuntos que o gestor liberou.
    # O gestor (Rinaldo) cadastra os professores, escolhe os assuntos, bloqueia/libera e gera o código de ativação.
    def conta(self, forcar: bool = False) -> dict:
        """Quem é o professor deste computador e o que ele pode usar. Pergunta à nuvem a cada 5 minutos; sem internet usa o último que sabe."""
        padrao = {"ligado": False, "nome": "", "modulos": list(TURMAS), "todos": True, "gestor": False, "bloqueado": False}
        if not nuvem_config():
            return padrao
        if self._conta and not forcar and time.time() - self._conta[0] < 300:
            return self._conta[1]
        try:
            r = self.nuvem({"acao": "prof_info"})
            mods = [t for t in r.get("modulos") or [] if t in TURMAS]
            d = {"ligado": True, "nome": str(r.get("nome") or ""), "modulos": mods or list(TURMAS), "todos": bool(r.get("todos")) or not mods,
                 "gestor": bool(r.get("gestor")), "bloqueado": False}
            with self.trava:
                self.dados["conta"] = d
                self.salvar()
        except ValueError as e:
            msg = str(e)
            with self.trava:
                guardada = self.dados.get("conta") or {**padrao, "ligado": True}
            d = {**guardada, "erro": msg, "bloqueado": "bloqueado" in msg.casefold()}
        self._conta = (time.time(), d)
        return d

    def ativar(self, codigo: str) -> dict:
        """O professor digita o código de ativação que o gestor mandou: este computador fica ligado à conta dele."""
        cod = re.sub(r"[^A-Z0-9]", "", str(codigo or "").upper())
        if len(cod) < 12:
            raise ValueError("Digite o código de ativação completo (12 letras e números).")
        if nuvem_config(self.arq_nuvem):
            raise ValueError("Este computador já está ativado. Para trocar de professor, fale com o responsável pelo RMD AudioLab.")
        r = self.nuvem_sem_chave({"acao": "ativar", "codigo": cod})
        chave = str(r.get("chave") or "")
        if len(chave) < 30:
            raise ValueError("A nuvem não devolveu a ativação. Tente de novo.")
        self.arq_nuvem.parent.mkdir(parents=True, exist_ok=True)
        self.arq_nuvem.write_text(json.dumps({"url": URL_NUVEM_PADRAO, "chave": chave, "site": SITE_PADRAO}, ensure_ascii=False), encoding="utf-8")
        self._conta = None
        return {"nome": r.get("nome") or "", "modulos": r.get("modulos") or list(TURMAS)}

    # ------------------------------------------------------------------ atualização automática (só no computador do professor)
    def atualizacao(self, forcar: bool = False) -> dict:
        """Confere no site se tem versão nova (no máximo 1 vez por hora). Sem internet: diz que não tem."""
        if not (self.raiz_programa / MARCA_PROFESSOR.name).is_file():
            return {"pode": False, "atual": VERSAO}
        c = getattr(self, "_atualizacao", None)
        if c and not forcar and time.time() - c[0] < 3600:
            return c[1]
        d = {"pode": True, "atual": VERSAO, "nova": None}
        try:
            with urllib.request.urlopen(URL_ATUALIZACAO + "?t=" + str(int(time.time())), timeout=8) as r:
                info = json.loads(r.read() or b"{}")
            if _versao_num(info.get("versao")) > _versao_num(VERSAO) and str(info.get("zip", "")).startswith("https://"):
                d.update(nova=str(info["versao"]), novidades=str(info.get("novidades") or "")[:500], _info=info)
        except (OSError, ValueError, urllib.error.URLError):
            d["erro"] = "sem internet"
        self._atualizacao = (time.time(), d)
        return {k: v for k, v in d.items() if not k.startswith("_")}

    def atualizar(self) -> dict:
        """Baixa a versão nova, confere, troca os arquivos do programa (os dados ficam) e liga o AudioLab de novo."""
        if not (self.raiz_programa / MARCA_PROFESSOR.name).is_file():
            raise ValueError("Este AudioLab não se atualiza sozinho.")
        self.atualizacao(True)
        info = (getattr(self, "_atualizacao", (0, {}))[1] or {}).get("_info")
        if not info:
            raise ValueError("Não tem versão nova agora (ou está sem internet).")
        import hashlib as _h
        import zipfile
        with urllib.request.urlopen(info["zip"], timeout=120) as r:
            bruto = r.read()
        if info.get("sha256") and _h.sha256(bruto).hexdigest() != str(info["sha256"]).lower():
            raise ValueError("O arquivo da atualização chegou com defeito. Tente de novo.")
        with zipfile.ZipFile(io.BytesIO(bruto)) as z:
            nomes = z.namelist()
            if "servidor.py" not in nomes or any(n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/") for n in nomes):
                raise ValueError("O arquivo da atualização não é válido.")
            copia = self.pasta / "copias" / f"programa_antes_{VERSAO}"
            for n in nomes:
                if n.endswith("/") or n.split("/")[0] in ("dados", "certificado", "python"):
                    continue  # nunca mexe nos dados do professor, no certificado nem no Python
                alvo = self.raiz_programa / n
                if alvo.is_file() and not (copia / n).exists():
                    (copia / n).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(alvo, copia / n)
                alvo.parent.mkdir(parents=True, exist_ok=True)
                alvo.write_bytes(z.read(n))
        self.religar()
        return {"versao": info.get("versao")}

    def religar(self) -> None:
        """Liga de novo: o iniciador vê a versão nova no arquivo, desliga este servidor e liga o novo."""
        exe = Path(sys.executable)
        exe = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").is_file() else exe
        flags = 0x00000008 | 0x00000200 | 0x08000000 if os.name == "nt" else 0
        raiz = self.raiz_programa
        threading.Timer(1.5, lambda: subprocess.Popen([str(exe), str(raiz / "iniciar.py")], cwd=str(raiz), creationflags=flags,
                                                      stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)).start()

    def gestao(self) -> dict:
        r = self.nuvem({"acao": "gestor_professores"})
        return {"eu": r.get("eu"), "professores": r.get("professores") or [], "site": SITE_PADRAO}

    @staticmethod
    def _modulos(v) -> list:
        return [t for t in TURMAS if t in (v or [])]

    def gestao_criar(self, nome, contato="", obs="", modulos=None) -> dict:
        nome = " ".join(str(nome or "").split())[:60]
        if not nome:
            raise ValueError("Escreva o nome do professor.")
        mods = self._modulos(modulos)
        if not mods:
            raise ValueError("Marque pelo menos um assunto para o professor.")
        r = self.nuvem({"acao": "gestor_criar", "nome": nome, "contato": str(contato or "")[:80], "obs": str(obs or "")[:300], "modulos": mods})
        return {"professor": r.get("professor"), "codigo": r.get("codigo"), "nome": nome, "modulos": mods}

    def gestao_editar(self, pid: str, d: dict) -> dict:
        corpo = {"acao": "gestor_editar", "id": str(pid or "")[:40]}
        for k in ("nome", "contato", "obs"):
            if k in d:
                corpo[k] = str(d.get(k) or "")[:300]
        if "modulos" in d:
            corpo["modulos"] = self._modulos(d.get("modulos"))
        if "ativo" in d:
            corpo["ativo"] = bool(d.get("ativo"))
        self.nuvem(corpo)
        if self._conta:
            self._conta = None  # se mexeu no próprio cadastro, a tela pega o novo
        return {"ok": True}

    def gestao_suporte(self, nome) -> dict:
        """Manutenção: acha o aluno pelo nome (em qualquer professor) e mostra só dados técnicos, sem notas nem conversas."""
        nome = " ".join(str(nome or "").split())[:60]
        if len(nome) < 3:
            raise ValueError("Digite pelo menos 3 letras do nome do aluno.")
        r = self.nuvem({"acao": "gestor_suporte_aluno", "nome": nome})
        return {"alunos": r.get("alunos") or []}

    def gestao_codigo(self, pid: str) -> dict:
        r = self.nuvem({"acao": "gestor_codigo", "id": str(pid or "")[:40]})
        return {"codigo": r.get("codigo")}

    def casa_criar_aluno(self, nome: str, turmas=None) -> dict:
        """Cria o acesso de casa. turmas = tipo de acesso (voz, regencia, som, bateria, musico): o app mostra só as ferramentas desse tipo."""
        nome = " ".join(str(nome or "").split())[:60]
        if not nome:
            raise ValueError("Escreva o nome do aluno.")
        tipos = [t for t in (turmas or []) if t in TURMAS]
        with self.trava:
            if any(a["nome"].casefold() == nome.casefold() and a.get("ativo", True) for a in self.dados.get("casa_alunos") or []):
                raise ValueError("Este aluno já tem acesso. Use o código que já existe (ou desative o antigo).")
        bruto = "".join(secrets.choice(ALFABETO_CODIGO) for _ in range(8))
        codigo = bruto[:4] + "-" + bruto[4:]
        r = self.nuvem({"acao": "prof_criar_aluno", "nome": nome, "codigo": codigo})
        reg = {"id": r["aluno"]["id"], "nome": nome, "codigo": codigo, "ativo": True, "criado": datetime.now().strftime("%d/%m/%Y %H:%M"), "ultimo_acesso": None, "turmas": tipos}
        if tipos:
            self.nuvem({"acao": "prof_turma", "id": reg["id"], "turmas": tipos})
        with self.trava:
            self.dados.setdefault("casa_alunos", []).append(reg)
            self.salvar()
        site = (nuvem_config() or {}).get("site") or ""
        return {**reg, "link": f"{site}?c={codigo}" if site else ""}

    def casa_novo_codigo(self, aid: str) -> dict:
        """Gera um código novo para o aluno (perdeu o código ou trocou de celular). O antigo para de funcionar."""
        with self.trava:
            a = next((x for x in self.dados.get("casa_alunos") or [] if x["id"] == aid), None)
            if not a:
                raise ValueError("Aluno não encontrado.")
            if not a.get("ativo", True):
                raise ValueError("Reative o acesso antes de gerar um código novo.")
        bruto = "".join(secrets.choice(ALFABETO_CODIGO) for _ in range(8))
        codigo = bruto[:4] + "-" + bruto[4:]
        self.nuvem({"acao": "prof_novo_codigo", "id": aid, "codigo": codigo})
        with self.trava:
            a["codigo"] = codigo
            self.salvar()
        site = (nuvem_config() or {}).get("site") or ""
        return {**a, "link": f"{site}?c={codigo}" if site else ""}

    def casa_ativo(self, aid: str, ativo: bool) -> dict:
        with self.trava:
            a = next((x for x in self.dados.get("casa_alunos") or [] if x["id"] == aid), None)
            if not a:
                raise ValueError("Aluno não encontrado.")
        self.nuvem({"acao": "prof_ativo", "id": aid, "ativo": bool(ativo)})
        with self.trava:
            a["ativo"] = bool(ativo)
            self.salvar()
            return a

    def documentos_de(self, nome: str) -> list[dict]:
        """Boletim/certificado de um aluno nos 3 cursos (mesmos dados que o painel usa para imprimir), para o celular dele."""
        alvo, docs = nome.casefold(), []
        kd = lambda t: str(t)[6:10] + str(t)[3:5] + str(t)[:2]  # dd/mm/aaaa -> aaaammdd
        icones = {"louvor": "🎤", "regencia": "🎼", "bateria": "🥁", "musico": "🎸"}
        for cid, c in self.avaliacoes()["cursos"].items():
            a = next((x for x in c["alunos"] if x["aluno"].casefold() == alvo), None)
            if not a:
                continue
            ms = [(m, a["materias"].get(m["id"])) for m in c["materias"]]
            docs.append({"tipo": cid, "aluno": a["aluno"], "curso": c["nome"], "icone": icones.get(cid, "🎵"), "total": len(ms),
                         "aprovadas": a["aprovadas"], "media": a["media"], "certificado": a["certificado"],
                         "datas": [n["data"] for _m, n in ms if n],
                         "linhas": [{"nome": m["nome"], "nota": n["nota"] if n else None, "data": n["data"] if n else "",
                                     "recuperada": bool(n and n.get("recuperada"))} for m, n in ms]})
        t = self.trilha()
        al = next((x for x in t["alunos"] if x["aluno"].casefold() == alvo), None)
        if al:
            datas = sorted((h["data"][:10] for h in al["historico"]), key=kd)
            docs.append({"tipo": "som", "aluno": al["aluno"], "curso": "Operação de Som", "icone": "🎚️", "total": len(t["ordem"]),
                         "aprovadas": al["aprovados"], "media": al["media"], "tentativas": len(al["historico"]),
                         "aulas": sorted({h.get("aula") for h in al["historico"] if h.get("aula")})[:10], "datas": datas[:1] + datas[-1:],
                         "certificado": al["certificado"],
                         "linhas": [{"nome": o["nome"], "nota": al["melhores"][o["tipo"]]["nota"] if o["tipo"] in al["melhores"] else None,
                                     "data": al["melhores"][o["tipo"]]["data"] if o["tipo"] in al["melhores"] else "",
                                     "nivel": al["melhores"][o["tipo"]].get("nivel", "Médio") if o["tipo"] in al["melhores"] else "—"} for o in t["ordem"]]})
        return docs

    def _avisar_casa(self) -> None:
        """Depois de lançar ou mudar nota: manda logo (em 2 s, sem travar a tela) o boletim e as recuperações para o celular dos alunos."""
        if not getattr(self, "aviso_automatico", False) or getattr(self, "_aviso_pendente", False):
            return
        self._aviso_pendente = True

        def mandar():
            time.sleep(2)
            self._aviso_pendente = False
            try:
                if nuvem_config() and self.dados.get("casa_alunos"):
                    self.casa_enviar_pendencias()
            except Exception as e:  # noqa: BLE001 — sem internet: vai na próxima busca
                print("treino em casa (aviso):", e, flush=True)
        threading.Thread(target=mandar, daemon=True, name="AudioLab-aviso").start()

    def casa_enviar_pendencias(self) -> None:
        """Manda para a nuvem as matérias em recuperação de cada aluno com acesso (o aluno vê no celular). Só manda se mudou."""
        rec = self.recuperacoes()
        with self.trava:
            lista = []
            for a in self.dados.get("casa_alunos") or []:
                if not a.get("ativo", True):
                    continue
                pend = [{"curso": r["curso_nome"], "materia": r["materia_nome"], "familias": r["familias"], "treino": r["treino"],
                         "desde": r["desde"], "precisa": r["precisa"], "pronta": r["pronta"]}
                        for r in rec if r["aluno"].casefold() == a["nome"].casefold()]
                lista.append({"id": a["id"], "pendencias": pend, "documentos": self.documentos_de(a["nome"])})
            assinatura = hashlib.sha1(json.dumps(lista, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
            if not lista or assinatura == self.dados.get("casa_pend_enviado"):
                return
        self.nuvem({"acao": "prof_status", "alunos": lista, "info": {"nome_empresa": self.dados["config"].get("nome_empresa"), "nome_curso": self.info()["nome_curso"]}})
        with self.trava:
            self.dados["casa_pend_enviado"] = assinatura
            self.salvar()

    # ------------------------------------------------------------------ aula com turmas (pelo app, na internet do celular)
    def turmas_estado(self) -> dict:
        """Quadro ao vivo: exercício de cada turma, quem está com o app aberto e a nota de cada um."""
        r = self.nuvem({"acao": "prof_aula"})
        try:
            agora = datetime.fromisoformat(str(r.get("agora")).replace("Z", "+00:00"))
        except ValueError:
            agora = None
        tarefas = r.get("tarefas") or {}
        por_tarefa = {t.get("id"): turma for turma, t in tarefas.items() if isinstance(t, dict) and t.get("id")}
        notas: dict[tuple, int] = {}
        for n in r.get("notas") or []:
            turma = por_tarefa.get(n.get("tarefa"))
            if turma:
                notas[(n["aluno_id"], turma)] = n["nota"]  # vale a última entrega
        alunos = []
        for a in r.get("alunos") or []:
            online = False
            if agora and a.get("ultimo_acesso"):
                try:
                    online = (agora - datetime.fromisoformat(str(a["ultimo_acesso"]).replace("Z", "+00:00"))).total_seconds() < 100
                except ValueError:
                    pass
            alunos.append({"id": a["id"], "nome": a["nome"], "turmas": [t for t in a.get("turmas") or [] if t in TURMAS], "online": online,
                           "notas": {t: notas.get((a["id"], t)) for t in TURMAS}})
        return {"tarefas": tarefas, "alunos": alunos}

    def turmas_aluno(self, aid: str, turmas) -> dict:
        lista = [t for t in (turmas or []) if t in TURMAS]
        self.nuvem({"acao": "prof_turma", "id": aid, "turmas": lista})
        with self.trava:
            for a in self.dados.get("casa_alunos") or []:
                if a["id"] == aid:
                    a["turmas"] = lista
            self.salvar()
        return {"turmas": lista}

    def turmas_tarefa(self, turma: str, tarefa: dict | None) -> dict:
        """Manda (tarefa) ou encerra (None) o exercício de uma turma."""
        if turma not in TURMAS:
            raise ValueError("Turma desconhecida.")
        if tarefa is not None:
            if not isinstance(tarefa, dict) or not tarefa.get("tipo"):
                raise ValueError("Escolha o exercício.")
            tarefa = {"id": secrets.token_hex(6), "tipo": str(tarefa["tipo"])[:30], "nivel": max(0, min(2, int(tarefa.get("nivel") or 0))),
                      "titulo": " ".join(str(tarefa.get("titulo") or "").split())[:80],
                      "opcoes": {k: v for k, v in (tarefa.get("opcoes") or {}).items() if isinstance(v, (int, float, str, bool))} if isinstance(tarefa.get("opcoes"), dict) else {}}
        r = self.nuvem({"acao": "prof_tarefa", "turma": turma, "tarefa": tarefa})
        return {"tarefas": r.get("tarefas") or {}}

    # ------------------------------------------------------------------ chat das turmas (21/11/2026)
    # Cada turma (departamento) conversa com o professor e entre si; cada aluno tem também uma conversa particular com o professor.
    # As mensagens ficam só na nuvem (este computador não guarda cópia).
    def chat(self, canal: str = "", depois: str = "") -> dict:
        corpo = {"acao": "prof_chat"}
        if canal:
            corpo["canal"] = str(canal)[:60]
        if depois:
            corpo["depois"] = str(depois)[:40]
        r = self.nuvem(corpo)
        return {"canais": r.get("canais") or [], "ultimas": r.get("ultimas") or {}, "mensagens": r.get("mensagens") or []}

    def chat_enviar(self, canal: str, texto) -> dict:
        txt = str(texto or "").strip()
        if not txt:
            raise ValueError("Escreva a mensagem.")
        if len(txt) > 500:
            raise ValueError("Mensagem grande demais (até 500 letras).")
        r = self.nuvem({"acao": "prof_chat_enviar", "canal": str(canal or "")[:60], "texto": txt, "nome": "Professor"})
        return {"mensagem": r.get("mensagem")}

    def chat_apagar(self, mid: str) -> dict:
        self.nuvem({"acao": "prof_chat_apagar", "id": str(mid or "")[:40]})
        return {"apagada": True}

    def casa_buscar(self) -> dict:
        """Traz da nuvem os treinos feitos em casa e põe na pasta de cada aluno (sem repetir; o que foi excluído não volta)."""
        with self.trava:
            desde = self.dados.get("casa_desde") or "1970-01-01T00:00:00+00:00"
        try:
            r = self.nuvem({"acao": "prof_treinos", "desde": desde})
            als = self.nuvem({"acao": "prof_alunos"}).get("alunos") or []
        except ValueError as e:
            self.casa_erro = str(e)
            raise
        self.casa_erro = None
        novos = 0
        with self.trava:
            vistos = {t.get("id") for t in self.dados.get("treinos") or []} | {t.get("id") for t in self.dados.get("treinos_excluidos") or []}
            lista = self.dados.setdefault("treinos", [])
            for t in r.get("itens") or []:
                if t.get("area") not in AREAS_TREINO:
                    continue
                if t["criado"] > (self.dados.get("casa_desde") or ""):
                    self.dados["casa_desde"] = t["criado"]
                if t["id"] in vistos:
                    continue
                try:
                    quando = datetime.fromisoformat(str(t["criado"]).replace("Z", "+00:00")).astimezone().strftime("%d/%m/%Y %H:%M")
                except ValueError:
                    quando = datetime.now().strftime("%d/%m/%Y %H:%M")
                lista.append({"id": t["id"], "data": quando, "aluno": " ".join(str(t.get("aluno") or "Aluno").split())[:60], "area": t["area"],
                              "treino": str(t.get("treino") or "Treino")[:80], "nota": max(0, min(100, int(t.get("nota") or 0))),
                              "detalhe": str(t.get("detalhe") or "")[:300], "origem": "casa"})
                vistos.add(t["id"])
                novos += 1
            self.dados["treinos"] = lista[-5000:]
            ultimo = {a["id"]: a.get("ultimo_acesso") for a in als}
            for a in self.dados.get("casa_alunos") or []:
                if ultimo.get(a["id"]):
                    try:
                        a["ultimo_acesso"] = datetime.fromisoformat(str(ultimo[a["id"]]).replace("Z", "+00:00")).astimezone().strftime("%d/%m/%Y %H:%M")
                    except ValueError:
                        pass
            self.dados["casa_ultima_busca"] = datetime.now().strftime("%d/%m/%Y %H:%M")
            self.salvar()
        self.casa_enviar_pendencias()
        return {"novos": novos}

    # ------------------------------------------------------------------ avaliação dos cursos de canto e regência
    def avaliacoes(self) -> dict:
        """Matérias, critérios e as notas lançadas pelo professor, mais a situação de cada aluno em cada curso."""
        notas = self.dados.setdefault("avaliacoes", {})
        cursos = {}
        for cid, c in CURSOS_AVALIADOS.items():
            alunos = []
            for nome, mats in sorted((notas.get(cid) or {}).items(), key=lambda x: x[0].casefold()):
                feitas = [mats[m["id"]] for m in c["materias"] if m["id"] in mats]
                aprovadas = sum(1 for x in feitas if x["nota"] >= NOTA_MINIMA)
                media = round(sum(x["nota"] for x in feitas) / len(feitas)) if feitas else 0
                alunos.append({"aluno": nome, "materias": mats, "aprovadas": aprovadas, "media": media,
                               "certificado": len(feitas) == len(c["materias"]) and all(x["nota"] >= NOTA_CERTIFICADO for x in feitas)})
            cursos[cid] = {**c, "alunos": alunos}
        conhecidos = sorted({h["aluno"] for h in self.dados["historico"]} | {n for c in notas.values() for n in c}, key=str.casefold)
        return {"cursos": cursos, "nota_minima": NOTA_MINIMA, "nota_certificado": NOTA_CERTIFICADO, "alunos_conhecidos": conhecidos}

    def avaliar_materia(self, curso: str, aluno: str, materia: str, itens: list | None = None, nota=None, obs: str = "") -> dict:
        """Lança (ou corrige) a nota de uma matéria. A nota é a soma dos critérios marcados (20% cada),
        a não ser que o professor digite outra nota (0 a 100)."""
        c = CURSOS_AVALIADOS.get(str(curso or ""))
        if not c:
            raise ValueError("Curso desconhecido.")
        m = next((x for x in c["materias"] if x["id"] == materia), None)
        if not m:
            raise ValueError("Matéria desconhecida.")
        nome = " ".join(str(aluno or "").split())[:60]
        if not nome:
            raise ValueError("Escreva o nome do aluno.")
        marcados = [bool(x) for x in (itens or [])][:len(m["criterios"])]
        marcados += [False] * (len(m["criterios"]) - len(marcados))
        if nota is None or nota == "":
            valor = round(100 * sum(marcados) / len(m["criterios"]))
        else:
            try:
                valor = int(round(float(nota)))
            except (TypeError, ValueError):
                raise ValueError("Nota inválida.") from None
            if not 0 <= valor <= 100:
                raise ValueError("A nota vai de 0 a 100.")
        with self.trava:
            reg = self.dados.setdefault("avaliacoes", {}).setdefault(curso, {}).setdefault(nome, {})
            reg[materia] = {"nota": valor, "itens": marcados, "obs": " ".join(str(obs or "").split())[:200],
                            "data": datetime.now().strftime("%d/%m/%Y")}
            self.salvar()
            self._avisar_casa()
            return reg[materia]

    def apagar_avaliacao(self, curso: str, aluno: str, materia: str | None = None) -> dict:
        """Exclui as notas de um aluno num curso (todas ou só de uma matéria). Vai para a reserva escondida."""
        with self.trava:
            reg = (self.dados.get("avaliacoes") or {}).get(str(curso or ""), {})
            if aluno not in reg or (materia and materia not in reg[aluno]):
                raise ValueError("Nada para excluir.")
            saiu = {materia: reg[aluno].pop(materia)} if materia else reg.pop(aluno)
            if not materia or not reg.get(aluno):
                reg.pop(aluno, None)
            reserva = self.dados.setdefault("avaliacoes_excluidas", [])
            reserva.append({"curso": curso, "aluno": aluno, "notas": saiu, "excluido_em": datetime.now().strftime("%d/%m/%Y %H:%M")})
            self.dados["avaliacoes_excluidas"] = reserva[-500:]
            self.salvar()
            self._avisar_casa()
            return {"excluidos": len(saiu)}

    def trilha(self) -> dict:
        """Evolução de cada aluno na trilha de exercícios (melhor nota de cada um) e se já pode receber o certificado."""
        ordem = sorted(EXERCICIOS, key=lambda k: EXERCICIOS[k]["ordem"])
        alunos: dict[str, dict] = {}
        for h in self.dados["historico"]:
            tipo = h.get("tipo") or next((k for k, v in EXERCICIOS.items() if v["nome"] == h["exercicio"]), None)
            if not tipo:
                continue
            al = alunos.setdefault(h["aluno"], {"aluno": h["aluno"], "melhores": {}, "historico": []})
            al["historico"].append(h)
            atual = al["melhores"].get(tipo)
            if not atual or h["nota"] > atual["nota"]:
                al["melhores"][tipo] = {"nota": h["nota"], "data": h["data"], "nivel": h.get("nivel", "Médio")}
        for al in alunos.values():
            feitos = [t for t in ordem if t in al["melhores"] and al["melhores"][t]["nota"] >= NOTA_MINIMA]
            al["aprovados"] = len(feitos)
            al["media"] = round(sum(x["nota"] for x in al["historico"]) / len(al["historico"]))
            al["certificado"] = all(t in al["melhores"] and al["melhores"][t]["nota"] >= NOTA_CERTIFICADO for t in ordem)
        return {"ordem": [{"tipo": t, "nome": EXERCICIOS[t]["nome"]} for t in ordem], "alunos": sorted(alunos.values(), key=lambda x: x["aluno"].casefold())}

    def mensagem(self, texto: str) -> None:
        with self.trava:
            self._aula()["mensagem"] = " ".join(str(texto or "").split())[:160]
            self.salvar()

    # ------------------------------------------------------------------ telão (projeção)
    MODOS_TELAO = ("painel", "slide", "teste", "preto")

    def projetar(self, modo: str, tema: str | None = None, slide: int | None = None, aluno: str | None = None) -> dict:
        """Define o que o telão mostra: painel da aula, um slide do conteúdo, o teste ao vivo de um aluno ou tela preta."""
        if modo not in self.MODOS_TELAO:
            raise ValueError("Modo de projeção inválido.")
        tema = str(tema or "")[:40]
        if tema and not re.fullmatch(r"[a-z0-9_-]+", tema):
            raise ValueError("Tema inválido.")
        try:
            slide = max(0, min(999, int(slide or 0)))
        except (TypeError, ValueError):
            slide = 0
        with self.trava:
            if modo == "teste" and aluno:
                self._aluno(aluno)  # confere se existe
            self.projecao = {"modo": modo, "tema": tema or None, "slide": slide, "aluno": aluno or None}
            return dict(self.projecao)

    def _teste_publico(self) -> dict | None:
        """Espelho do que um aluno faz na mesa, para o telão. NUNCA inclui nota, acerto, erro ou o defeito do exercício."""
        pr = self.projecao
        a = self.dados.get("aula")
        if pr["modo"] != "teste" or not a:
            return None
        al = a["alunos"].get(pr["aluno"] or a.get("selecionado") or "")
        if not al:
            return {"nome": None}
        agora = time.time()
        vu = self.vu.get(al["id"])
        return {"nome": al.get("apelido") or al["nome"].split(" ")[0], "controles": al["controles"], "inicial": al.get("inicial") or controles_normais(),
                "vu": vu[1] if vu and agora - vu[0] < 3 else {}, "seguindo": not pr["aluno"]}

    # ------------------------------------------------------------------ exercício
    def _tempo(self, ex: dict) -> tuple[float, float]:
        corrido = ex["acumulado"] + ((time.time() - ex["desde"]) if ex["status"] == "ATIVO" else 0)
        return corrido, max(0.0, ex["duracao"] - corrido)

    def iniciar(self, tipo: str, duracao: int | None = None, nivel: str | None = None, louvor: str | None = None, modo: str | None = None) -> dict:
        with self.trava:
            if tipo not in EXERCICIOS:
                raise ValueError("Exercício desconhecido.")
            a = self._aula()
            if not a["alunos"]:
                raise ValueError("Nenhum aluno entrou na aula ainda.")
            nivel = nivel if nivel in NIVEIS else "medio"
            d = int(duracao or EXERCICIOS[tipo]["duracao"])
            d = max(30, min(1800, d))
            if louvor:
                self._louvor(louvor)  # confere se existe
            var = {}
            if tipo == "microfonia":  # no difícil o apito pode aparecer em outra faixa
                var["banda"] = secrets.choice(list(BANDAS)) if nivel == "dificil" else "magudo"
            a["exercicio"] = {"tipo": tipo, "status": "ATIVO", "desde": time.time(), "acumulado": 0.0, "duracao": d, "nivel": nivel, "var": var, "louvor": louvor or None, "modo": modo if modo in MODOS_AUDIO else None}
            for al in a["alunos"].values():  # todos começam com o mesmo problema
                al["controles"] = {**controles_normais(), **problema_de(tipo, var)}
                al["inicial"] = dict(al["controles"])  # para o telão mostrar o que o aluno já mexeu
                al["resultado"] = None
                al["terminou"] = False
            self.salvar()
            return a["exercicio"]

    def trocar_audio(self, louvor: str | None, modo: str | None = None) -> None:
        """Troca o áudio do exercício em andamento (louvor da biblioteca ou som do sistema) sem reiniciar as mesas."""
        with self.trava:
            ex = self._aula().get("exercicio")
            if not ex:
                raise ValueError("Nenhum exercício em andamento.")
            if louvor:
                self._louvor(louvor)
            ex["louvor"] = louvor or None
            ex["modo"] = modo if modo in MODOS_AUDIO else None
            self.salvar()

    def pausar(self, pausar: bool) -> None:
        with self.trava:
            ex = self._aula().get("exercicio")
            if not ex or ex["status"] not in ("ATIVO", "PAUSADO"):
                raise ValueError("Nenhum exercício em andamento.")
            if pausar and ex["status"] == "ATIVO":
                ex["acumulado"] += time.time() - ex["desde"]
                ex["status"] = "PAUSADO"
            elif not pausar and ex["status"] == "PAUSADO":
                ex["desde"] = time.time()
                ex["status"] = "ATIVO"
            self.salvar()

    def _registrar(self, a: dict, al: dict, ex: dict, motivo: str) -> None:
        res = avaliar(ex["tipo"], al["controles"], ex.get("var"))
        corrido, _ = self._tempo(ex)
        res.update({"tempo": round(corrido), "motivo": motivo})
        al["resultado"] = res
        al["terminou"] = True
        self.dados["historico"].append({
            "data": datetime.now().strftime("%d/%m/%Y %H:%M"), "aula": a["nome"], "sessao": a["codigo"],
            "exercicio": EXERCICIOS[ex["tipo"]]["nome"], "tipo": ex["tipo"], "nivel": NIVEIS.get(ex.get("nivel"), "Médio"),
            "aluno": al["nome"], "papel": al["papel"],
            "nota": res["nota"], "acertos": len(res["acertos"]), "erros": len(res["erros"]),
            "tempo_s": res["tempo"], "detalhe": "; ".join(res["erros"]) or "sem erros", "id": secrets.token_hex(6)})
        self.dados["historico"] = self.dados["historico"][-5000:]
        self._avisar_casa()

    def aluno_terminou(self, al: dict) -> dict:
        with self.trava:
            a = self._aula()
            ex = a.get("exercicio")
            if not ex or ex["status"] != "ATIVO":
                raise ValueError("Não há exercício ativo.")
            if al["papel"] != "OPERADOR":
                raise PermissionError("Só o operador finaliza o ajuste.")
            if al["terminou"]:
                return al["resultado"]
            self._registrar(a, al, ex, "aluno terminou")
            self.salvar()
            return al["resultado"]

    def finalizar(self, motivo: str = "professor finalizou") -> dict:
        with self.trava:
            a = self._aula()
            ex = a.get("exercicio")
            if not ex or ex["status"] not in ("ATIVO", "PAUSADO"):
                raise ValueError("Nenhum exercício em andamento.")
            for al in a["alunos"].values():
                if al["papel"] == "OPERADOR" and not al["terminou"]:
                    self._registrar(a, al, ex, motivo)
            if ex["status"] == "ATIVO":
                ex["acumulado"] += time.time() - ex["desde"]
            ex["status"] = "FINALIZADO"
            self.salvar()
            return {aid: al["resultado"] for aid, al in a["alunos"].items() if al["resultado"]}

    def verificar_tempo(self) -> None:
        with self.trava:
            a = self.dados.get("aula")
            ex = a and a.get("exercicio")
            if ex and ex["status"] == "ATIVO" and self._tempo(ex)[1] <= 0:
                self.finalizar("tempo esgotado")

    def mudar_controles(self, al: dict, novos: dict) -> dict:
        with self.trava:
            ex = self._aula().get("exercicio")
            if al["papel"] != "OPERADOR":
                raise PermissionError("Você está como OBSERVADOR: a mesa está travada.")
            if not ex or ex["status"] != "ATIVO":
                raise PermissionError("A mesa só libera com o exercício ativo.")
            if al["terminou"]:
                raise PermissionError("Você já finalizou este exercício.")
            if not isinstance(novos, dict):
                raise ValueError("Dados inválidos.")
            for k, v in novos.items():
                if k in CONTROLES:
                    al["controles"][k] = _limitar(k, v)
            return al["controles"]

    # ------------------------------------------------------------------ visões
    def _ex_publico(self, ex: dict | None) -> dict | None:
        if not ex:
            return None
        corrido, resta = self._tempo(ex)
        e = EXERCICIOS[ex["tipo"]]
        var = ex.get("var") or {}
        banda = var.get("banda", "magudo")
        lv = None
        if ex.get("louvor"):
            try:
                x = self._louvor(ex["louvor"])
                sepd = bool(x.get("voz") and x.get("inst"))
                modo = ex.get("modo") if ex.get("modo") in MODOS_AUDIO else None
                if not sepd:
                    modo = "original"
                elif modo is None:
                    modo = "junto"
                lv = {"id": x["id"], "nome": x["nome"], "playback": bool(x.get("playback")), "separado": sepd, "modo": modo}
            except KeyError:
                lv = None
        return {"louvor": lv, "tipo": ex["tipo"], "nome": e["nome"], "publico": e["publico"], "status": ex["status"],
                "duracao": ex["duracao"], "restante": round(resta), "corrido": round(corrido), "zumbido": bool(e.get("zumbido")),
                "picos": bool(e.get("picos")), "nivel": ex.get("nivel", "medio"), "nivel_nome": NIVEIS.get(ex.get("nivel"), "Médio"),
                "banda": banda, "apito_hz": BANDAS[banda][1]}

    def visao_publica(self) -> dict:
        self.verificar_tempo()
        with self.trava:
            a = self.dados.get("aula")
            placar = None
            if a and a.get("placar"):
                linhas = [(al["apelido"] if "apelido" in al else al["nome"].split(" ")[0], al["resultado"]["nota"], al["resultado"]["tempo"])
                          for al in a["alunos"].values() if al.get("resultado")]
                placar = [{"apelido": n, "nota": s, "tempo": tp} for n, s, tp in sorted(linhas, key=lambda x: (-x[1], x[2]))[:10]]
            return {**self.info(), "aula": a["nome"] if a else None, "exercicio": self._ex_publico(a and a.get("exercicio")),
                    "participantes": len(a["alunos"]) if a else 0, "mensagem": (a or {}).get("mensagem", ""), "placar": placar,
                    "projecao": dict(self.projecao), "teste": self._teste_publico()}

    def visao_professor(self) -> dict:
        self.verificar_tempo()
        with self.trava:
            a = self.dados.get("aula")
            agora = time.time()
            alunos = []
            if a:
                for al in sorted(a["alunos"].values(), key=lambda x: x["entrou"]):
                    if "turmas" not in al:  # aluno que entrou antes desta versão: busca a categoria no cadastro
                        al["turmas"] = self._categoria_cadastro(al["nome"])
                        if al["papel"] == "OPERADOR" and al["turmas"] is not None and "som" not in al["turmas"]:
                            al["papel"] = "OBSERVADOR"
                    alunos.append({"id": al["id"], "nome": al["nome"], "apelido": al.get("apelido"), "papel": al["papel"], "turmas": al.get("turmas"), "online": agora - al["visto"] < 15,
                                   "terminou": al["terminou"], "resultado": al["resultado"], "controles": al["controles"],
                                   "vu": (self.vu.get(al["id"]) or (0, {}, False))[1] if agora - (self.vu.get(al["id"]) or (0,))[0] < 3 else {},
                                   "som": bool((self.vu.get(al["id"]) or (0, {}, False))[2]) and agora - (self.vu.get(al["id"]) or (0,))[0] < 3})
            return {**self.info(), "senha_padrao": bool(self.dados["config"].get("senha_padrao")),
                    "aula": ({"codigo": a["codigo"], "nome": a["nome"], "selecionado": a["selecionado"], "mensagem": a["mensagem"], "placar": bool(a.get("placar"))} if a else None),
                    "exercicio": self._ex_publico(a and a.get("exercicio")), "alunos": alunos, "projecao": dict(self.projecao),
                    "rede": {"ip": ip_rede(), "ips": ips_rede(), "porta": PORTA, "porta_segura": PORTA + 1}, "louvores": self.louvores()}

    def visao_aluno(self, al: dict) -> dict:
        self.verificar_tempo()
        with self.trava:
            a = self._aula()
            ex = a.get("exercicio")
            pub = self._ex_publico(ex)
            if pub:
                e = EXERCICIOS[ex["tipo"]]
                # fácil: instrução + dica · médio: instrução · difícil: só o sintoma (o aluno descobre a causa)
                pub["instrucao"] = e["publico"] if pub["nivel"] == "dificil" else e["instrucao"]
                pub["dica"] = e["dica"] if pub["nivel"] == "facil" else None
                pub["teoria"] = e["teoria"]
            # o observador acompanha a mesa do aluno que o professor selecionou
            sel = a["alunos"].get(a["selecionado"] or "")
            if al["papel"] == "OPERADOR":
                mesa, de = al["controles"], al["nome"]
            elif sel:
                mesa, de = sel["controles"], sel["nome"]
            else:
                mesa, de = al["controles"], None
            return {**self.info(), "aula": a["nome"], "eu": {"nome": al["nome"], "papel": al["papel"], "terminou": al["terminou"]},
                    "exercicio": pub, "mesa": mesa, "mesa_de": de, "resultado": al["resultado"]}

    def historico_csv(self) -> bytes:
        saida = io.StringIO()
        w = csv.writer(saida, delimiter=";")
        w.writerow(["Data", "Aula", "Sessão", "Exercício", "Aluno", "Função", "Nota (%)", "Acertos", "Erros", "Tempo (s)", "O que faltou"])
        for h in self.dados["historico"]:
            linha = [h["data"], h["aula"], h["sessao"], h["exercicio"], h["aluno"], h["papel"], h["nota"], h["acertos"], h["erros"], h["tempo_s"], h["detalhe"]]
            w.writerow([("'" + v) if isinstance(v, str) and v[:1] in "=+-@" else v for v in linha])
        return ("﻿" + saida.getvalue()).encode("utf-8")


# ---------------------------------------------------------------------------- servidor web
sala: Sala | None = None
CHAVE_LOCAL = ""  # chave do próprio computador: só o iniciador (iniciar.py) consegue desligar o servidor para atualizar


def _desligar_processo():
    time.sleep(0.3)
    os._exit(0)
EXT_AUDIO = (".mp3", ".m4a", ".wav", ".ogg", ".opus", ".aac", ".webm", ".flac")
TIPOS_AUDIO = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".ogg": "audio/ogg", ".opus": "audio/ogg",
               ".aac": "audio/aac", ".webm": "audio/webm", ".flac": "audio/flac"}
MAX_LOUVOR = 60 * 1024 * 1024
TIPOS = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json", ".webmanifest": "application/manifest+json"}
PAGINAS = {"/casa": "casa/index.html", "/casa/": "casa/index.html", "/": "professor.html", "/professor": "professor.html", "/aluno": "aluno.html", "/projecao": "projecao.html", "/ferramentas": "ferramentas.html",
           "/RMD-AudioLab-Analisador-Mobile.html": "ferramentas.html",
           # nomes antigos continuam funcionando
           "/RMD-AudioLab-Aula.html": "aluno.html", "/RMD-AudioLab-Dashboard.html": "professor.html", "/RMD-AudioLab-Projecao.html": "projecao.html"}


class Tratador(BaseHTTPRequestHandler):
    server_version = "RMD-AudioLab"
    sys_version = ""
    timeout = 30

    def log_message(self, fmt, *args):
        if os.getenv("AUDIOLAB_LOG"):
            sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))

    # ---------------------------------------------------------------- respostas
    def _cabecalhos(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        # 20/11/2026: camera=() proibia a câmera em todas as páginas e a Regência com câmera dava "acesso negado"
        # mesmo com a permissão liberada no celular. Agora câmera e microfone só para o próprio AudioLab (self).
        self.send_header("Permissions-Policy", "microphone=(self), camera=(self)")

    def _json(self, codigo: int, obj, cookie: str | None = None):
        corpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(corpo)))
        if cookie is not None:
            idade = 12 * 3600 if cookie else 0
            self.send_header("Set-Cookie", f"{COOKIE}={cookie}; Path=/; HttpOnly; SameSite=Strict; Max-Age={idade}")
        self._cabecalhos()
        self.end_headers()
        self.wfile.write(corpo)

    def _arquivo(self, caminho: Path, baixar: str | None = None, dados: bytes | None = None):
        if dados is None:
            dados = caminho.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8" if baixar else TIPOS.get(caminho.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(dados)))
        self.send_header("Cache-Control", "no-cache")
        if baixar:
            self.send_header("Content-Disposition", f'attachment; filename="{baixar}"')
        self._cabecalhos()
        self.end_headers()
        self.wfile.write(dados)

    def _audio(self, caminho: Path):
        tamanho = caminho.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", TIPOS_AUDIO.get(caminho.suffix.lower(), "application/octet-stream"))
        self.send_header("Content-Length", str(tamanho))
        self.send_header("Cache-Control", "private, max-age=3600")
        self._cabecalhos()
        self.end_headers()
        with open(caminho, "rb") as f:
            while True:
                bloco = f.read(256 * 1024)
                if not bloco:
                    break
                self.wfile.write(bloco)

    def _corpo(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = -1
        if n < 0 or n > 64 * 1024:
            raise ValueError("Envio inválido.")
        if n == 0:
            return {}
        d = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        if not isinstance(d, dict):
            raise ValueError("Envio inválido.")
        return d

    def _token_prof(self) -> str | None:
        for parte in (self.headers.get("Cookie") or "").split(";"):
            nome, _, valor = parte.strip().partition("=")
            if nome == COOKIE:
                return valor
        return None

    def _prof(self) -> bool:
        return sala.professor_ok(self._token_prof())

    # ---------------------------------------------------------------- GET
    def do_GET(self):  # noqa: N802
        url = urlparse(self.path)
        p = url.path
        try:
            if p == "/api/info":
                return self._json(200, sala.info())
            if p == "/api/publico":
                return self._json(200, sala.visao_publica())
            if p == "/api/exercicios":
                return self._json(200, {"itens": [{"tipo": k, "nome": v["nome"], "publico": v["publico"], "duracao": v["duracao"], "teoria": v["teoria"]}
                                                  for k, v in sorted(EXERCICIOS.items(), key=lambda x: x[1]["ordem"])],
                                        "niveis": NIVEIS, "porta_segura": PORTA + 1,
                                        "controles": {k: list(v) for k, v in CONTROLES.items()}})
            if p == "/api/aluno/estado":
                with sala.trava:
                    al = sala.aluno_do_token(self.headers.get("X-Aluno"))
                return self._json(200, sala.visao_aluno(al))
            m = re.fullmatch(r"/api/louvor/([0-9a-f]{10})/(louvor|playback|voz|inst)", p)
            if m:
                # só quem está na aula (professor ou aluno com token) baixa o áudio
                if not self._prof():
                    with sala.trava:
                        sala.aluno_do_token(self.headers.get("X-Aluno"))
                return self._audio(sala.arquivo_louvor(m.group(1), m.group(2)))
            if p.startswith("/api/prof/"):
                if not self._prof():
                    return self._json(401, {"erro": "Entre com a senha do professor."})
                if p == "/api/prof/estado":
                    return self._json(200, sala.visao_professor())
                if p == "/api/prof/historico":
                    return self._json(200, {"itens": sala.historico()})
                if p == "/api/prof/trilha":
                    return self._json(200, sala.trilha())
                if p == "/api/prof/avaliacoes":
                    return self._json(200, sala.avaliacoes())
                if p == "/api/prof/treinos":
                    return self._json(200, sala.treinos())
                if p == "/api/prof/casa":
                    return self._json(200, sala.casa_estado())
                if p == "/api/prof/turmas":
                    return self._json(200, sala.turmas_estado())
                if p == "/api/prof/conta":
                    return self._json(200, sala.conta())
                if p == "/api/prof/atualizacao":
                    return self._json(200, sala.atualizacao())
                if p == "/api/prof/gestao":
                    return self._json(200, sala.gestao())
                if p == "/api/prof/recuperacoes":
                    return self._json(200, {"itens": sala.recuperacoes(), "dias": DIAS_RECUPERACAO, "nota_boa": NOTA_TREINO_BOM})
                if p == "/api/prof/historico.csv":
                    return self._arquivo(Path("x.csv"), baixar=f"audiolab-resultados-{datetime.now():%Y%m%d}.csv", dados=sala.historico_csv())
                return self._json(404, {"erro": "Endereço não encontrado."})
            pagina = PAGINAS.get(p)
            alvo = ESTATICO / pagina if pagina else (ESTATICO / p.lstrip("/")).resolve()
            if (pagina or ESTATICO.resolve() in alvo.parents) and alvo.is_file():
                return self._arquivo(alvo)
            return self._json(404, {"erro": "Página não encontrada."})
        except PermissionError as e:
            return self._json(403, {"erro": str(e)})
        except (KeyError, ValueError) as e:
            return self._json(400, {"erro": str(e).strip("'")})

    # ---------------------------------------------------------------- POST
    def do_POST(self):  # noqa: N802
        url = urlparse(self.path)
        p = url.path
        try:
            if p == "/api/sistema/desligar":
                # usado pelo iniciador para trocar o servidor antigo pelo novo (só neste computador e com a chave local)
                chave = self.headers.get("X-Chave") or ""
                if self.client_address[0] != "127.0.0.1" or not CHAVE_LOCAL or not hmac.compare_digest(chave, CHAVE_LOCAL):
                    return self._json(403, {"erro": "Não permitido."})
                self._json(200, {"ok": True})
                threading.Thread(target=_desligar_processo, daemon=True).start()
                return None
            if p == "/api/prof/louvor":
                # envio do arquivo de áudio (corpo binário). O cabeçalho X-AudioLab impede envio a partir de outro site.
                if not self._prof() or self.headers.get("X-AudioLab") != "1":
                    return self._json(401, {"erro": "Entre com a senha do professor."})
                q = parse_qs(url.query)
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    n = -1
                r = sala.guardar_louvor((q.get("nome") or [""])[0], (q.get("ext") or [""])[0], self.rfile, n,
                                        (q.get("tipo") or ["louvor"])[0], (q.get("de") or [None])[0])
                return self._json(200, {"ok": True, "dados": r, "estado": sala.visao_professor()})
            if "application/json" not in (self.headers.get("Content-Type") or ""):
                return self._json(415, {"erro": "Envie JSON."})
            d = self._corpo()
            if p == "/api/prof/entrar":
                tok = sala.entrar_professor(d.get("senha"), self.client_address[0])
                return self._json(200, {"ok": True}, cookie=tok)
            if p == "/api/aluno/entrar":
                return self._json(200, sala.entrar_aluno(d.get("nome"), d.get("sessao"), d.get("apelido")))
            if p.startswith("/api/aluno/"):
                with sala.trava:
                    al = sala.aluno_do_token(self.headers.get("X-Aluno"))
                if p == "/api/aluno/controle":
                    return self._json(200, {"mesa": sala.mudar_controles(al, d.get("controles"))})
                if p == "/api/aluno/vu":
                    sala.registrar_vu(al, d.get("vu"), d.get("som"))
                    return self._json(200, {"ok": True})
                if p == "/api/aluno/treino":
                    return self._json(200, {"ok": True, "dados": sala.guardar_treino(al["nome"], d.get("area"), d.get("treino"), d.get("nota"), d.get("detalhe"), "celular")})
                if p == "/api/aluno/terminei":
                    return self._json(200, {"resultado": sala.aluno_terminou(al)})
                return self._json(404, {"erro": "Endereço não encontrado."})
            if p.startswith("/api/prof/"):
                if not self._prof():
                    return self._json(401, {"erro": "Entre com a senha do professor."})
                if p == "/api/prof/sair":
                    sala.sair_professor(self._token_prof())
                    return self._json(200, {"ok": True}, cookie="")
                acoes = {
                    "/api/prof/senha": lambda: sala.trocar_senha(d.get("atual"), d.get("nova")),
                    "/api/prof/config": lambda: sala.configurar(d),
                    "/api/prof/sessao": lambda: sala.nova_sessao(d.get("nome")),
                    "/api/prof/papel": lambda: sala.definir_papel(d.get("aluno"), d.get("papel")),
                    "/api/prof/categoria": lambda: sala.definir_categoria(str(d.get("aluno") or ""), str(d.get("turma") or "")),
                    "/api/prof/selecionar": lambda: sala.selecionar(d.get("aluno")),
                    "/api/prof/remover": lambda: sala.remover(d.get("aluno")),
                    "/api/prof/mensagem": lambda: sala.mensagem(d.get("texto")),
                    "/api/prof/iniciar": lambda: sala.iniciar(d.get("tipo"), d.get("duracao"), d.get("nivel"), d.get("louvor"), d.get("modo")),
                    "/api/prof/audio": lambda: sala.trocar_audio(d.get("louvor"), d.get("modo")),
                    "/api/prof/separar": lambda: sala.separar(d.get("id")),
                    "/api/prof/resultados/apagar": lambda: sala.apagar_resultados(d.get("aluno"), d.get("ids")),
                    "/api/prof/treino": lambda: sala.guardar_treino(d.get("aluno"), d.get("area"), d.get("treino"), d.get("nota"), d.get("detalhe")),
                    "/api/prof/treinos/apagar": lambda: sala.apagar_treinos(d.get("aluno"), d.get("ids")),
                    "/api/prof/casa/aluno": lambda: sala.casa_criar_aluno(d.get("nome"), d.get("turmas")),
                    "/api/prof/ativar": lambda: sala.ativar(str(d.get("codigo") or "")),
                    "/api/prof/conta/atualizar": lambda: sala.conta(True),
                    "/api/prof/atualizar": lambda: sala.atualizar(),
                    "/api/prof/gestao/criar": lambda: sala.gestao_criar(d.get("nome"), d.get("contato"), d.get("obs"), d.get("modulos")),
                    "/api/prof/gestao/editar": lambda: sala.gestao_editar(str(d.get("id") or ""), d),
                    "/api/prof/gestao/codigo": lambda: sala.gestao_codigo(str(d.get("id") or "")),
                    "/api/prof/gestao/suporte": lambda: sala.gestao_suporte(d.get("nome")),
                    "/api/prof/casa/ativo": lambda: sala.casa_ativo(str(d.get("id") or ""), bool(d.get("ativo"))),
                    "/api/prof/casa/buscar": lambda: sala.casa_buscar(),
                    "/api/prof/casa/codigo": lambda: sala.casa_novo_codigo(str(d.get("id") or "")),
                    "/api/prof/turmas/aluno": lambda: sala.turmas_aluno(str(d.get("id") or ""), d.get("turmas")),
                    "/api/prof/turmas/tarefa": lambda: sala.turmas_tarefa(str(d.get("turma") or ""), d.get("tarefa")),
                    "/api/prof/chat": lambda: sala.chat(str(d.get("canal") or ""), str(d.get("depois") or "")),
                    "/api/prof/chat/enviar": lambda: sala.chat_enviar(str(d.get("canal") or ""), d.get("texto")),
                    "/api/prof/chat/apagar": lambda: sala.chat_apagar(str(d.get("id") or "")),
                    "/api/prof/recuperacao/aprovar": lambda: sala.aprovar_recuperacao(str(d.get("curso") or ""), str(d.get("aluno") or ""), str(d.get("materia") or "")),
                    "/api/prof/avaliacao/salvar": lambda: sala.avaliar_materia(d.get("curso"), d.get("aluno"), d.get("materia"), d.get("itens"), d.get("nota"), d.get("obs")),
                    "/api/prof/avaliacao/apagar": lambda: sala.apagar_avaliacao(d.get("curso"), d.get("aluno"), d.get("materia")),
                    "/api/prof/louvor/apagar": lambda: sala.apagar_louvor(d.get("id"), bool(d.get("so_playback"))),
                    "/api/prof/placar": lambda: sala.ligar_placar(d.get("ligado")),
                    "/api/prof/projetar": lambda: sala.projetar(d.get("modo"), d.get("tema"), d.get("slide"), d.get("aluno")),
                    "/api/prof/hotspot": lambda: hotspot(str(d.get("acao") or "estado")),
                    "/api/prof/firewall": lambda: firewall_acao(str(d.get("acao") or "estado")),
                    "/api/prof/pausar": lambda: sala.pausar(True),
                    "/api/prof/continuar": lambda: sala.pausar(False),
                    "/api/prof/finalizar": lambda: sala.finalizar(),
                }
                if p not in acoes:
                    return self._json(404, {"erro": "Endereço não encontrado."})
                r = acoes[p]()
                return self._json(200, {"ok": True, "dados": r if isinstance(r, (dict, list)) else None, "estado": sala.visao_professor()})
            return self._json(404, {"erro": "Endereço não encontrado."})
        except PermissionError as e:
            return self._json(403, {"erro": str(e)})
        except (KeyError, ValueError) as e:
            return self._json(400, {"erro": str(e).strip("'")})


def criar_servidor(host: str = "0.0.0.0", porta: int = PORTA, pasta: Path | None = None) -> ThreadingHTTPServer:
    global sala
    sala = Sala(pasta or PASTA_DADOS)
    # No Windows, "reusar endereço" deixa dois programas na mesma porta (o antigo continuaria atendendo): desligado lá.
    ThreadingHTTPServer.allow_reuse_address = os.name != "nt"
    srv = ThreadingHTTPServer((host, porta), Tratador)
    srv.daemon_threads = True
    return srv


def _porta_ocupada_por_outro() -> bool:
    """True se a porta está com outro programa (ex.: o servidor antigo do AudioLab), e não com este."""
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORTA}/api/info", timeout=2) as r:
            return "nome_empresa" not in r.read().decode("utf-8", "ignore")
    except Exception:  # noqa: BLE001 - qualquer resposta estranha = não é o AudioLab novo
        return True


def _liberar_porta_windows() -> None:
    import subprocess
    try:
        saida = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return
    for linha in saida.splitlines():
        partes = linha.split()
        if len(partes) >= 5 and partes[1].endswith(f":{PORTA}") and partes[3].upper() in ("LISTENING", "ESCUTANDO"):
            subprocess.run(["taskkill", "/PID", partes[4], "/F"], capture_output=True, timeout=10)


def _preparar_execucao() -> None:
    """Sem janela (pythonw) não há onde escrever: guarda as mensagens e erros em dados/servidor.log. Cria a chave local."""
    global CHAVE_LOCAL
    PASTA_DADOS.mkdir(parents=True, exist_ok=True)
    if sys.stdout is None or sys.stderr is None:
        log = open(PASTA_DADOS / "servidor.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    print(f"--- {datetime.now():%d/%m/%Y %H:%M:%S} RMD AudioLab {VERSAO} ligando", flush=True)
    CHAVE_LOCAL = secrets.token_urlsafe(24)
    (PASTA_DADOS / ".chave_local").write_text(CHAVE_LOCAL, encoding="utf-8")


if __name__ == "__main__":
    _preparar_execucao()
    if os.name == "nt" and _porta_ocupada_por_outro():
        # porta respondendo, mas não é este AudioLab (ex.: servidor antigo): fecha o antigo antes de abrir
        try:
            socket.create_connection(("127.0.0.1", PORTA), timeout=1).close()
            _liberar_porta_windows()
            time.sleep(1.5)
        except OSError:
            pass  # porta livre
    try:
        srv = criar_servidor()
    except OSError:
        if os.name == "nt" and _porta_ocupada_por_outro():
            _liberar_porta_windows()  # fecha o servidor antigo que ficou aberto na mesma porta
            time.sleep(1.5)
            try:
                srv = criar_servidor()
            except OSError:
                print(f"A porta {PORTA} está ocupada por outro programa.")
                sys.exit(1)
        else:
            print(f"O AudioLab já está aberto neste computador (porta {PORTA}).")
            sys.exit(0)
    # Endereço seguro (https) na porta seguinte: só para liberar o microfone no celular (analisador, teste vocal).
    cert, chave = RAIZ / "certificado" / "audiolab.crt", RAIZ / "certificado" / "audiolab.key"
    if cert.is_file() and chave.is_file():
        try:
            import ssl
            seguro = ThreadingHTTPServer(("0.0.0.0", PORTA + 1), Tratador)
            seguro.daemon_threads = True
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(str(cert), str(chave))
            seguro.socket = ctx.wrap_socket(seguro.socket, server_side=True)
            threading.Thread(target=seguro.serve_forever, daemon=True, name="AudioLab-https").start()
        except (OSError, ValueError) as e:
            print("Endereço seguro (microfone no celular) indisponível:", e)
    # treino em casa: busca as notas novas da nuvem a cada 5 minutos (se estiver configurado e tiver aluno com acesso)
    def _buscar_casa_sempre():
        while True:
            try:
                if nuvem_config() and sala.dados.get("casa_alunos"):
                    sala.casa_buscar()
            except Exception as e:  # noqa: BLE001 — sem internet: tenta de novo depois
                print("treino em casa:", e, flush=True)
            time.sleep(300)
    threading.Thread(target=_buscar_casa_sempre, daemon=True, name="AudioLab-casa").start()
    sala.aviso_automatico = True  # boletim e recuperação vão para o celular logo depois de lançar a nota
    print("=" * 60)
    print(" RMD AudioLab — sala de aula de áudio")
    print(f" Professor (neste computador): http://127.0.0.1:{PORTA}/")
    print(f" Alunos (celular no mesmo Wi-Fi): http://{ip_rede()}:{PORTA}/aluno")
    print(" Para fechar: feche esta janela.")
    print("=" * 60, flush=True)
    srv.serve_forever()
