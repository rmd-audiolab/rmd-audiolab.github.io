"""RMD AudioLab — iniciador (é o que o ícone da Área de Trabalho abre).

1. Se o servidor já está ligado e é a versão atual: só abre o painel.
2. Se está ligado numa versão antiga: desliga o antigo e liga o novo (atualiza sozinho).
3. Se não está ligado: liga e abre o painel.
Se algo der errado, mostra uma mensagem na tela (em vez de não abrir nada) e grava em dados/iniciar.log.

Uso: iniciar.py            -> liga e abre
     iniciar.py --fechar   -> desliga o servidor
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
import traceback
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
DADOS = Path(os.getenv("AUDIOLAB_DADOS") or (RAIZ / "dados"))
PORTA = int(os.getenv("AUDIOLAB_PORTA", "49326"))
URL = f"http://127.0.0.1:{PORTA}"


def log(msg: str) -> None:
    try:
        DADOS.mkdir(parents=True, exist_ok=True)
        with open(DADOS / "iniciar.log", "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%d/%m/%Y %H:%M:%S} {msg}\n")
    except OSError:
        pass


def aviso(msg: str) -> None:
    log("AVISO: " + msg)
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "RMD AudioLab", 0x40)
            return
        except Exception:  # noqa: BLE001
            pass
    print(msg)


def info() -> dict | None:
    try:
        with urllib.request.urlopen(URL + "/api/info", timeout=1.5) as r:
            d = json.loads(r.read().decode("utf-8", "ignore"))
            return d if isinstance(d, dict) and "nome_empresa" in d else {"estranho": True}
    except Exception:  # noqa: BLE001
        return None


def versao_do_arquivo() -> str:
    m = re.search(r'^VERSAO = "([^"]+)"', (RAIZ / "servidor.py").read_text(encoding="utf-8"), re.M)
    return m.group(1) if m else ""


def esperar(cond, segundos: float) -> bool:
    fim = time.time() + segundos
    while time.time() < fim:
        if cond():
            return True
        time.sleep(0.3)
    return cond()


def matar_pela_porta() -> None:
    """Último recurso (servidor antigo sem o comando de desligar): fecha o programa que está na porta."""
    if os.name != "nt":
        return
    try:
        saida = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=10,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except (OSError, subprocess.SubprocessError):
        return
    for linha in saida.splitlines():
        partes = linha.split()
        if len(partes) >= 5 and partes[1].endswith(f":{PORTA}") and partes[3].upper() in ("LISTENING", "ESCUTANDO"):
            r = subprocess.run(["taskkill", "/PID", partes[4], "/F"], capture_output=True, text=True, timeout=10,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            log(f"taskkill {partes[4]}: {(r.stdout or r.stderr).strip()}")


def desligar() -> bool:
    if info() is None:
        return True
    try:
        chave = (DADOS / ".chave_local").read_text(encoding="utf-8").strip()
        req = urllib.request.Request(URL + "/api/sistema/desligar", data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json", "X-Chave": chave})
        urllib.request.urlopen(req, timeout=3).read()
        log("pedido de desligar aceito")
    except Exception as e:  # noqa: BLE001 - servidor antigo não conhece o comando
        log(f"desligar pelo comando falhou ({e}); tentando pela porta")
    if esperar(lambda: info() is None, 4):
        return True
    matar_pela_porta()
    return esperar(lambda: info() is None, 5)


def python_sem_janela() -> str:
    exe = Path(sys.executable)
    if os.name == "nt":
        w = exe.with_name("pythonw.exe")
        if w.is_file():
            return str(w)
    return str(exe)


def ligar() -> bool:
    flags = 0
    if os.name == "nt":
        flags = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
    DADOS.mkdir(parents=True, exist_ok=True)
    saida = open(DADOS / "servidor.log", "a", encoding="utf-8")  # mensagens e erros do servidor ficam guardados aqui
    subprocess.Popen([python_sem_janela(), str(RAIZ / "servidor.py")], cwd=str(RAIZ), creationflags=flags,
                     stdin=subprocess.DEVNULL, stdout=saida, stderr=subprocess.STDOUT, close_fds=True,
                     env={**os.environ, "PYTHONIOENCODING": "utf-8"})  # 22/11/2026: acentos certos no servidor.log
    log("servidor iniciado")
    return esperar(lambda: (info() or {}).get("nome_empresa") is not None, 15)


def abrir_painel() -> None:
    if os.getenv("AUDIOLAB_SEM_NAVEGADOR"):
        return
    candidatos = [Path(os.environ.get(v, "")) / "Google" / "Chrome" / "Application" / "chrome.exe"
                  for v in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA")]
    for c in candidatos:
        if c.is_file():
            subprocess.Popen([str(c), f"--app={URL}/"], close_fds=True)
            return
    webbrowser.open(URL + "/")


def ultimas_linhas(arquivo: Path, n: int = 8) -> str:
    try:
        return "\n".join(arquivo.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:])
    except OSError:
        return ""


def main(argv: list[str]) -> int:
    if "--fechar" in argv:
        ok = desligar()
        log("fechar: " + ("ok" if ok else "não fechou"))
        if not ok:
            aviso("Não consegui fechar o RMD AudioLab. Reinicie o computador se ele continuar aberto.")
        return 0 if ok else 1
    atual, versao = info(), versao_do_arquivo()
    log(f"abrindo: no ar={atual}, arquivo={versao}")
    if atual is not None and atual.get("versao") != versao:
        if not desligar():
            aviso("Há uma versão antiga do RMD AudioLab aberta e não consegui fechá-la.\n\n"
                  "Reinicie o computador e abra o ícone RMD AudioLab de novo.")
            return 1
        atual = None
    if atual is None and not ligar():
        detalhe = ultimas_linhas(DADOS / "servidor.log")
        aviso("O RMD AudioLab não conseguiu ligar.\n\n" + (detalhe or "Sem detalhes.") +
              "\n\n(Os detalhes ficam em dados\\servidor.log)")
        return 1
    abrir_painel()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception:  # noqa: BLE001
        log(traceback.format_exc())
        aviso("Erro ao abrir o RMD AudioLab:\n\n" + traceback.format_exc(limit=3))
        sys.exit(1)
