@echo off
rem Fecha o servidor do RMD AudioLab (os resultados e os louvores ficam guardados).
cd /d "%~dp0"
if exist "%~dp0python\python.exe" ("%~dp0python\python.exe" iniciar.py --fechar) else (where py >nul 2>nul && (py -3 iniciar.py --fechar) || (python iniciar.py --fechar))
rem garantia: se ainda houver algo na porta, fecha
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":49326" ^| findstr "LISTENING"') do taskkill /PID %%p /F >nul 2>nul
echo RMD AudioLab fechado.
ping -n 2 127.0.0.1 >nul
