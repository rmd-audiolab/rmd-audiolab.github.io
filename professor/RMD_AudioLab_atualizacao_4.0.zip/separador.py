"""RMD AudioLab — separador de voz e instrumental (roda dentro do ambiente de IA do AudioLab, offline depois da 1ª vez).

Uso: python separador.py ENTRADA PASTA_SAIDA
Escreve em PASTA_SAIDA: voz.mp3 e instrumental.mp3 (ou .wav se o conversor não estiver disponível).
Imprime "PCT <0-100>" e "MSG <texto>" para o AudioLab acompanhar o andamento.
Usa o modelo Demucs (htdemucs) — gratuito, roda no processador do computador.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

SEG = 30   # segundos por bloco
SOBRA = 3  # segundos de sobreposição entre blocos (evita "emendas" audíveis)


def dizer(tipo: str, valor) -> None:
    print(f"{tipo} {valor}", flush=True)


def separar_em_blocos(wav, sr: int, aplicar, progresso=lambda p: None):
    """wav: array numpy (canais, amostras). aplicar(bloco)->array (fontes, canais, amostras) onde a última fonte é a VOZ.
    Devolve (voz, instrumental) com o mesmo formato de wav. Os blocos se sobrepõem e são misturados com rampa suave."""
    import numpy as np
    total = wav.shape[1]
    seg, ov = SEG * sr, SOBRA * sr
    voz = np.zeros_like(wav, dtype="float64")
    inst = np.zeros_like(wav, dtype="float64")
    peso = np.zeros(total, dtype="float64")
    passo = max(1, seg - ov)
    inicios = list(range(0, max(1, total - ov), passo)) or [0]
    for n, ini in enumerate(inicios):
        fim = min(total, ini + seg)
        sai = aplicar(wav[:, ini:fim])
        v = sai[-1]
        outros = sai[:-1].sum(axis=0)
        w = np.ones(fim - ini, dtype="float64")
        if ini > 0:
            r = min(ov, len(w)); w[:r] = (np.arange(r) + 1) / (r + 1)
        if fim < total:
            r = min(ov, len(w)); w[-r:] = np.minimum(w[-r:], (np.arange(r, 0, -1)) / (r + 1))
        voz[:, ini:fim] += v * w
        inst[:, ini:fim] += outros * w
        peso[ini:fim] += w
        progresso(int(100 * (n + 1) / len(inicios)))
        if fim >= total:
            break
    peso[peso == 0] = 1
    return (voz / peso).astype("float32"), (inst / peso).astype("float32")


def principal(entrada: str, saida: str) -> int:
    import imageio_ffmpeg
    import numpy as np
    import soundfile as sf
    import torch

    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    Path(saida).mkdir(parents=True, exist_ok=True)
    flags = 0x08000000 if os.name == "nt" else 0  # sem janela preta no Windows
    with tempfile.TemporaryDirectory() as tmp:
        bruto = str(Path(tmp) / "entrada.wav")
        dizer("MSG", "Lendo o áudio…")
        r = subprocess.run([ffmpeg, "-y", "-i", entrada, "-vn", "-ac", "2", "-ar", "44100", "-c:a", "pcm_f32le", bruto],
                           capture_output=True, creationflags=flags)
        if r.returncode != 0:
            dizer("ERRO", "Não consegui ler este arquivo de áudio.")
            return 2
        dados, sr = sf.read(bruto, dtype="float32", always_2d=True)
        wav = dados.T.copy()  # (canais, amostras)
        dizer("PCT", 2)
        dizer("MSG", "Carregando a inteligência de separação (1ª vez baixa ~80 MB)…")
        # Torch novo (2.6+) carrega com weights_only=True por padrão; o modelo do Demucs precisa do modo antigo.
        _carregar = torch.load

        def _carregar_compat(*a, **k):
            k.setdefault("weights_only", False)
            return _carregar(*a, **k)

        torch.load = _carregar_compat
        from demucs.apply import apply_model
        from demucs.pretrained import get_model
        modelo = get_model("htdemucs")
        modelo.eval()
        torch.set_num_threads(max(1, os.cpu_count() or 1))
        dizer("PCT", 6)
        dizer("MSG", "Separando a voz do instrumental…")
        ref = wav.mean(0)
        media, desvio = float(ref.mean()), float(ref.std()) or 1.0
        norm = (wav - media) / desvio
        ordem = list(modelo.sources)
        idx = [i for i, s in enumerate(ordem) if s != "vocals"] + [ordem.index("vocals")]  # voz por último

        def aplicar(bloco):
            x = torch.from_numpy(np.ascontiguousarray(bloco))[None]
            with torch.no_grad():
                y = apply_model(modelo, x, device="cpu", shifts=0, split=True, overlap=0.25, progress=False)[0]
            return y.numpy()[idx]

        voz, inst = separar_em_blocos(norm, sr, aplicar, lambda p: dizer("PCT", 6 + int(p * 0.9)))
        voz = voz * desvio + media
        inst = inst * desvio + media
        dizer("MSG", "Salvando os arquivos…")
        for nome, sinal in (("voz", voz), ("instrumental", inst)):
            sinal = np.clip(sinal, -1.0, 1.0)
            w = Path(tmp) / (nome + ".wav")
            sf.write(str(w), sinal.T, sr, subtype="PCM_16")
            mp3 = Path(saida) / (nome + ".mp3")
            c = subprocess.run([ffmpeg, "-y", "-i", str(w), "-codec:a", "libmp3lame", "-b:a", "192k", str(mp3)], capture_output=True, creationflags=flags)
            if c.returncode != 0 or not mp3.is_file():
                (Path(saida) / (nome + ".wav")).write_bytes(w.read_bytes())
        dizer("PCT", 100)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(principal(sys.argv[1], sys.argv[2]))
    except Exception as e:  # noqa: BLE001
        dizer("ERRO", f"{type(e).__name__}: {e}")
        sys.exit(1)
