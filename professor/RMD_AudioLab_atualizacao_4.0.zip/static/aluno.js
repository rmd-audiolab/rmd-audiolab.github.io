/* RMD AudioLab — tela do aluno (celular) */
"use strict";
(function () {
  const h = AL.h, app = document.getElementById("app"), cabeca = document.getElementById("cabeca");
  const q = new URLSearchParams(location.search);
  let token = null, info = {}, limites = null, S = null, aba = "mesa", mesa = null, enviando = {}, filaTimer = null;
  const motor = new MotorAL();
  const selo = h("span", { class: "selo" }, "");
  try { token = localStorage.getItem("al_aluno"); } catch (e) { /* sem armazenamento */ }
  // vindo do botão "Abrir com microfone (endereço seguro)": o crachá do aluno vem no fim do endereço (#t=...)
  // e é guardado aqui, no endereço seguro; depois sai da barra de endereço.
  let abaInicial = null;
  try {
    const hs = new URLSearchParams(location.hash.slice(1));
    if (hs.get("t")) { token = hs.get("t"); try { localStorage.setItem("al_aluno", token); } catch (e) { /* ok */ } }
    if (hs.get("aba")) abaInicial = hs.get("aba");
    if (location.hash) history.replaceState(null, "", location.pathname + location.search);
  } catch (e) { /* ok */ }
  const linkSeguro = () => `https://${location.hostname}:${Number(location.port) + 1}/aluno#t=${encodeURIComponent(token || "")}&aba=ferramentas`;
  const cab = { headers: {} };
  const api = (c, corpo) => { cab.headers["X-Aluno"] = token || ""; return AL.api(c, corpo, cab); };
  motor.buscar = async (url) => { const r = await fetch(url, { headers: { "X-Aluno": token || "" } }); if (!r.ok) throw new Error("Não foi possível baixar o louvor."); return r.blob(); };
  let estadoLouvor = null;
  motor.aoMudarLouvor = (lv) => { estadoLouvor = lv; if (S) desenharEstado(); };

  function telaEntrar(msg) {
    const nome = h("input", { autocomplete: "name", maxlength: 40, required: true, placeholder: "Seu nome e sobrenome", "aria-label": "Seu nome" });
    const apelido = h("input", { maxlength: 20, placeholder: "Opcional — aparece no placar do telão", "aria-label": "Apelido para o placar" });
    const cod = h("input", { value: (q.get("sessao") || "").toUpperCase(), maxlength: 8, required: true, placeholder: "Código da aula", "aria-label": "Código da aula", style: { "text-transform": "uppercase" } });
    AL.limpar(app, h("div", { class: "cartao entrar" }, h("h2", {}, "Entrar na aula"),
      msg ? h("p", { class: "erro" }, msg) : null,
      h("form", { onsubmit: async (e) => { e.preventDefault();
        try { const r = await AL.api("/api/aluno/entrar", { nome: nome.value, sessao: cod.value, apelido: apelido.value }); token = r.token; try { localStorage.setItem("al_aluno", token); } catch (x) {} montarAula(); }
        catch (er) { AL.toast(er.message, true); } } },
        h("label", {}, "Nome"), nome, h("label", {}, "Código da aula (vem no QR Code)"), cod,
        h("label", {}, "Apelido (só ele aparece no telão)"), apelido,
        h("button", { class: "primario bloco", style: { "margin-top": "1rem" } }, "Entrar na aula"))));
    nome.focus();
  }

  function enviar(nome, valor) {
    S.mesa[nome] = valor; motor.aplicar(S.mesa, S.exercicio); enviando[nome] = valor; recentes[nome] = [valor, Date.now()];
    clearTimeout(filaTimer);
    filaTimer = setTimeout(async () => { const lote = enviando; enviando = {};
      try { await api("/api/aluno/controle", { controles: lote }); } catch (e) { AL.toast(e.message, true); } }, 120);
  }

  let partes = {};
  const recentes = {}; // o que o aluno mexeu agora há pouco vale mais que uma resposta do servidor que chegou atrasada
  function montarAula() {
    if (typeof TreinosAL !== "undefined") TreinosAL.comoAluno(token); // treinos do Laboratório da voz etc. vão para a pasta deste aluno
    const abas = [["mesa", "🎚 Mesa"], ["resultado", "📋 Meu resultado"], ["ferramentas", "🧰 Ferramentas"]];
    const barra = h("div", { class: "abas", role: "tablist" }, abas.map(([id, t]) => h("button", { "data-aba": id, onclick: () => trocar(id) }, t)));
    const corpoMesa = h("div"), corpoRes = h("div"), corpoFer = h("div");
    const status = h("div", { class: "cartao instrucao" }), area = h("div"), canvas = h("canvas", { class: "espectro" });
    const ouvir = h("button", { class: "primario", onclick: () => { motor.ligar(); motor.silenciar(false); ouvir.textContent = "🔊 Som ligado (use fone ou volume baixo)"; if (S) motor.aplicar(S.mesa, S.exercicio); } }, "▶ Ligar o som da mesa");
    const terminei = h("button", { onclick: async () => { try { await api("/api/aluno/terminei", {}); AL.toast("Ajuste entregue! Veja Meu resultado."); trocar("resultado"); } catch (e) { AL.toast(e.message, true); } } }, "✔ Terminei o ajuste");
    AL.limpar(corpoMesa, status, h("div", { class: "cartao" }, h("div", { class: "linha" }, ouvir, h("button", { onclick: () => motor.silenciar(true) }, "Silenciar"), terminei), canvas), area);
    mesa = AL.mesa(area, limites, enviar);
    partes = { status, terminei, corpoMesa, corpoRes, corpoFer, barra, canvas };
    AL.limpar(app, barra, corpoMesa, corpoRes, corpoFer);
    trocar(["mesa", "resultado", "ferramentas"].includes(abaInicial) ? abaInicial : "mesa");
    const desenhar = () => { if (motor.ctx && aba === "mesa") { desenharEspectro(canvas, motor.analisador, motor.ctx.sampleRate); mesa.vu(motor.niveis()); } requestAnimationFrame(desenhar); };
    desenhar();
    laco();
    // manda ao professor, 2x por segundo, o que este celular está ouvindo (medidores) — é isso que ele vê ao vivo
    let mandando = false;
    setInterval(async () => {
      if (mandando || !token) return; mandando = true;
      try { await api("/api/aluno/vu", { vu: motor.ctx ? motor.niveis() : {}, som: motor.ligado() }); } catch (e) { /* sem rede: tenta de novo */ }
      mandando = false;
    }, 500);
    document.addEventListener("visibilitychange", () => { if (!document.hidden && motor.ctx && motor.ctx.state === "suspended") motor.ctx.resume(); });
  }

  function trocar(id) {
    aba = id;
    partes.barra.querySelectorAll("[data-aba]").forEach((b) => b.classList.toggle("ligado", b.dataset.aba === id));
    partes.corpoMesa.classList.toggle("oculto", id !== "mesa"); partes.corpoRes.classList.toggle("oculto", id !== "resultado"); partes.corpoFer.classList.toggle("oculto", id !== "ferramentas");
    if (id === "ferramentas" && !partes.corpoFer.childElementCount) FerramentasAL.montar(partes.corpoFer, { semTelao: true, linkSeguro });
    if (id !== "ferramentas") FerramentasAL.parar();
    if (S) desenharEstado();
  }

  function desenharEstado() {
    const x = S.exercicio, op = S.eu.papel === "OPERADOR";
    const pode = op && x && x.status === "ATIVO" && !S.eu.terminou;
    AL.cabecalho(cabeca, info, S.aula || "Aula", [h("span", { class: "selo " + (op ? "ok" : "") }, op ? "OPERADOR" : "OBSERVADOR"), selo]);
    AL.limpar(partes.status,
      h("p", {}, h("b", {}, S.eu.nome), " · ", op ? "OPERADOR — mesa liberada quando o exercício estiver ativo." : "OBSERVADOR — acompanhe e ouça a mesa" + (S.mesa_de ? " de " + S.mesa_de : "") + "."),
      x ? [h("h2", {}, x.nome + " · " + (x.status === "ATIVO" ? "⏱ " + AL.tempo(x.restante) : x.status)),
          h("p", {}, h("span", { class: "selo" }, "Nível " + (x.nivel_nome || "Médio")), " ", x.instrucao),
          !x.louvor ? h("p", { class: "mudo" }, "🎵 O professor ainda não escolheu a música deste exercício.") : null,
          x.louvor ? h("p", {}, "🎵 Louvor: ", h("b", {}, x.louvor.nome), x.louvor.separado ? h("span", { class: "mudo" }, { junto: " (voz + instrumental)", voz: " (só a voz)", instrumental: " (só o instrumental)", original: " (original)" }[x.louvor.modo] || "") : null,
            !motor.ctx ? h("span", { class: "mudo" }, " — toque em Ligar o som da mesa") : estadoLouvor && estadoLouvor.erro ? h("span", { class: "erro" }, " — " + estadoLouvor.erro)
              : estadoLouvor && estadoLouvor.carregando ? h("span", { class: "mudo" }, " — baixando…") : null) : null,
          x.dica ? h("p", { class: "aviso" }, "💡 Dica: " + x.dica) : null,
          x.teoria ? h("details", { open: !!partes.teoriaAberta, ontoggle: (e) => (partes.teoriaAberta = e.currentTarget.open) }, h("summary", {}, "📘 Entenda o problema (teoria)"), h("p", {}, x.teoria)) : null]
        : h("p", { class: "mudo" }, "Aguardando o professor iniciar um exercício."),
      S.eu.terminou ? h("p", { class: "ok" }, "Você entregou este ajuste. Veja a nota em Meu resultado.") : null,
      !pode ? h("p", { class: "aviso" }, "🔒 Mesa travada: " + (!op ? "você está como OBSERVADOR. Peça ao professor para mudar você para OPERADOR."
        : !x ? "espere o professor iniciar um exercício." : x.status === "PAUSADO" ? "o professor pausou o exercício."
        : x.status === "FINALIZADO" ? "o exercício terminou. Veja a nota em Meu resultado." : S.eu.terminou ? "você já entregou este ajuste." : "")) : null);
    partes.terminei.disabled = !pode;
    if (pode) for (const [n, [v, t]] of Object.entries(recentes)) { if (Date.now() - t < 2000) S.mesa[n] = v; else delete recentes[n]; }
    mesa.editavel(pode); mesa.atualizar(S.mesa);
    motor.aplicar(S.mesa, x);
    const r = S.resultado;
    AL.limpar(partes.corpoRes, h("div", { class: "cartao" }, h("h2", {}, "Meu resultado (só você e o professor veem)"),
      r ? [h("div", { class: "nota " + (r.nota >= 80 ? "ok" : r.nota >= 50 ? "aviso" : "erro") }, r.nota + "%"), h("p", {}, r.retorno + " · tempo " + AL.tempo(r.tempo)),
        h("h3", {}, "O que você acertou"), r.acertos.length ? h("ul", { class: "lista-itens ok" }, r.acertos.map((t) => h("li", {}, t))) : h("p", { class: "mudo" }, "—"),
        r.erros.length ? [h("h3", {}, "O que faltou (e como corrigir)"), h("ul", { class: "lista-itens erro" }, r.erros.map((t) => h("li", {}, t)))] : null]
        : h("p", { class: "mudo" }, op ? "A nota aparece quando você tocar em “Terminei o ajuste” ou quando o professor finalizar." : "Observadores não recebem nota neste exercício.")));
  }

  async function laco() {
    try {
      S = await api("/api/aluno/estado"); selo.className = "selo ok"; selo.textContent = "● conectado";
      if (!Object.keys(enviando).length) desenharEstado();
    } catch (e) {
      if (e.status === 403) { try { localStorage.removeItem("al_aluno"); } catch (x) {} token = null; motor.silenciar(true); return telaEntrar(e.message); }
      selo.className = "selo erro"; selo.textContent = "● sem conexão";
    }
    setTimeout(laco, 600);
  }

  (async function () {
    try { info = await AL.api("/api/info"); AL.tema(info.tema); AL.cabecalho(cabeca, info, "Aluno"); const ex = await AL.api("/api/exercicios"); limites = ex.controles; }
    catch (e) { AL.limpar(app, h("div", { class: "cartao entrar" }, h("h2", {}, "Sem conexão"), h("p", {}, "Confira se o celular está no mesmo Wi-Fi do computador do professor e leia o QR Code de novo."))); return; }
    if (token) { try { S = await api("/api/aluno/estado"); return montarAula(); } catch (e) { token = null; } }
    telaEntrar();
  })();
})();
