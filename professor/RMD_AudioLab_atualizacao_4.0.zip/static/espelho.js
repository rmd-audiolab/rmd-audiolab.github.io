/* RMD AudioLab — espelho do teste ao vivo para o telão: nome do aluno, gráfico de equalização, medidores e o que ele já mexeu.
   NUNCA mostra nota, acerto, erro ou o defeito do exercício. */
"use strict";
const Espelho = (function () {
  const h = AL.h;
  const REG = {
    voz: ["VOZ (microfone)", [["ganho", "GANHO", "dB"], ["grave", "GRAVE", "dB"], ["mgrave", "MÉD-GRAVE", "dB"], ["medio", "MÉDIO", "dB"], ["magudo", "MÉD-AGUDO", "dB"], ["agudo", "AGUDO", "dB"], ["atraso", "ATRASO", "ms"], ["pan", "PAN", ""], ["fader", "FADER", "dB"]], [["hpf", "FILTRO GRAVES"], ["comp", "COMPRESSOR"], ["fx", "EFEITO"]]],
    mus: ["MÚSICA (playback)", [["ganho", "GANHO", "dB"], ["grave", "GRAVE", "dB"], ["mgrave", "MÉD-GRAVE", "dB"], ["medio", "MÉDIO", "dB"], ["magudo", "MÉD-AGUDO", "dB"], ["agudo", "AGUDO", "dB"], ["pan", "PAN", ""], ["fader", "FADER", "dB"]], [["hpf", "FILTRO GRAVES"]]],
  };
  const BANDAS = [["grave", 100], ["mgrave", 300], ["medio", 1000], ["magudo", 2500], ["agudo", 8000]];
  const COR = { voz: "#49c7ef", mus: "#7fd18b" };
  const NS = "http://www.w3.org/2000/svg";
  const x = (f) => 50 + 530 * (Math.log10(f) - Math.log10(20)) / 3, y = (db) => 150 - db * 9;
  const fmt = (v, u) => (u === "dB" && v > 0 ? "+" : "") + Math.round(v) + (u ? " " + u : "");

  function resposta(c, pre) {   // curva aproximada da equalização (dB) do canal
    let d = "";
    for (let i = 0; i <= 160; i++) {
      const f = 20 * Math.pow(1000, i / 160), lf = Math.log10(f);
      let g = 0;
      for (const [k, fc] of BANDAS) g += (c[pre + "_" + k] || 0) * Math.exp(-Math.pow((lf - Math.log10(fc)) / 0.3, 2));
      if (c[pre + "_hpf"]) g -= Math.min(30, f < 100 ? 12 * Math.log2(100 / f) : 0);
      g = Math.max(-15, Math.min(15, g));
      d += (i ? "L" : "M") + x(f).toFixed(1) + " " + y(g).toFixed(1);
    }
    return d;
  }
  function svgEl(tag, attrs) { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v); return e; }

  function montar(el, limites) {
    const nome = h("div", { class: "e-nome" }, ""), sub = h("div", { class: "e-sub" }, ""), tempo = h("div", { class: "e-tempo" }, "");
    const topo = h("div", { class: "e-topo" }, h("div", {}, nome, sub), tempo);
    // gráfico
    const g = svgEl("svg", { viewBox: "0 0 620 310", class: "e-grafico", role: "img", "aria-label": "Equalização do aluno" });
    g.append(svgEl("rect", { x: 0, y: 0, width: 620, height: 310, rx: 14, fill: "rgba(10,22,30,.85)" }));
    for (const db of [-12, -6, 0, 6, 12]) { g.append(svgEl("line", { x1: 50, x2: 580, y1: y(db), y2: y(db), stroke: db === 0 ? "#6f93a3" : "#1f3d4b", "stroke-width": db === 0 ? 2 : 1 })); const t = svgEl("text", { x: 40, y: y(db) + 5, "text-anchor": "end", fill: "#92b7c6", "font-size": 14 }); t.textContent = (db > 0 ? "+" : "") + db; g.append(t); }
    for (const [f, n] of [[20, "20"], [50, "50"], [100, "100"], [200, "200"], [500, "500"], [1000, "1k"], [2000, "2k"], [5000, "5k"], [10000, "10k"], [20000, "20k"]]) { g.append(svgEl("line", { x1: x(f), x2: x(f), y1: 24, y2: 276, stroke: "#1f3d4b", "stroke-width": 1 })); const t = svgEl("text", { x: x(f), y: 296, "text-anchor": "middle", fill: "#92b7c6", "font-size": 14 }); t.textContent = n; g.append(t); }
    const cv = { voz: svgEl("path", { fill: "none", stroke: COR.voz, "stroke-width": 5, "stroke-linecap": "round", "stroke-linejoin": "round" }), mus: svgEl("path", { fill: "none", stroke: COR.mus, "stroke-width": 5, "stroke-linecap": "round", "stroke-linejoin": "round" }) };
    g.append(cv.mus, cv.voz);
    const leg = h("div", { class: "e-leg" }, h("span", { style: { color: COR.voz } }, "● voz"), h("span", { style: { color: COR.mus } }, "● música"), h("span", { class: "mudo" }, "equalização (efeito dos botões de grave a agudo)"));
    // medidores
    const vus = {}, vuEls = h("div", { class: "e-vus" }, [["voz", "VOZ", COR.voz], ["mus", "MÚSICA", COR.mus], ["master", "SAÍDA", "#f2c94c"]].map(([k, n, c]) => { const i = h("i", { style: { background: c } }); vus[k] = i; return h("div", { class: "e-vu" }, h("span", {}, n), h("div", { class: "e-barra-vu" }, i)); }));
    const esq = h("div", { class: "e-esq" }, g, leg, vuEls);
    // linhas por canal
    const linhas = {}, pilulas = {};
    const bloco = (pre) => {
      const [titulo, faders, botoes] = REG[pre];
      return h("div", { class: "e-canal" }, h("h3", { style: { color: COR[pre] } }, titulo),
        faders.map(([k, rot, u]) => {
          const n = pre + "_" + k, [a, b] = limites[n] || [0, 1];
          const fill = h("i"), tick = h("u"), val = h("b", {}, "");
          const lin = h("div", { class: "e-lin" }, h("span", { class: "e-rot" }, rot), h("div", { class: "e-bar" }, fill, tick), val);
          linhas[n] = { lin, fill, tick, val, a, b, u };
          return lin;
        }),
        h("div", { class: "e-pilulas" }, botoes.map(([k, rot]) => { const p = h("span", { class: "e-pil" }, rot); pilulas[pre + "_" + k] = p; return p; })));
    };
    const master = (() => {
      const [a, b] = limites.master || [-60, 6], fill = h("i"), tick = h("u"), val = h("b", {}, "");
      const lin = h("div", { class: "e-lin" }, h("span", { class: "e-rot" }, "MASTER"), h("div", { class: "e-bar" }, fill, tick), val);
      linhas.master = { lin, fill, tick, val, a, b, u: "dB" };
      return h("div", { class: "e-canal e-master" }, h("h3", { style: { color: "#f2c94c" } }, "MASTER"), lin);
    })();
    const col2 = h("div", { class: "e-col" }, bloco("voz")), col3 = h("div", { class: "e-col" }, bloco("mus"), master);
    const rodape = h("div", { class: "e-rodape" }, "Espelho em tempo real da mesa do aluno · em destaque: o que ele já mexeu");
    AL.limpar(el, topo, h("div", { class: "e-corpo" }, esq, col2, col3), rodape);

    const ultimo = {}, quando = {};
    return {
      atualizar(t, ex) {
        const c = t.controles || {}, ini = t.inicial || {};
        nome.textContent = "Teste de " + t.nome;
        sub.textContent = ex ? ex.nome + (ex.status === "PAUSADO" ? " · pausado" : ex.status === "FINALIZADO" ? " · encerrado" : "") : "Aguardando um exercício";
        tempo.textContent = ex ? (ex.status === "FINALIZADO" ? "FIM" : AL.tempo(ex.restante)) : "";
        cv.voz.setAttribute("d", resposta(c, "voz")); cv.mus.setAttribute("d", resposta(c, "mus"));
        for (const k of ["voz", "mus", "master"]) vus[k].style.width = Math.round(Math.min(1, Math.max(0, (t.vu || {})[k] || 0)) * 100) + "%";
        const agora = Date.now();
        for (const [n, L] of Object.entries(linhas)) {
          const v = c[n]; if (v === undefined) continue;
          const pc = (z) => Math.max(0, Math.min(100, 100 * (z - L.a) / ((L.b - L.a) || 1)));
          L.fill.style.width = pc(v) + "%"; L.tick.style.left = pc(ini[n] === undefined ? v : ini[n]) + "%";
          L.val.textContent = fmt(v, L.u);
          const mudou = ini[n] !== undefined && Math.abs(v - ini[n]) >= 1;
          if (ultimo[n] !== undefined && ultimo[n] !== v) quando[n] = agora;
          ultimo[n] = v;
          L.lin.classList.toggle("mudou", mudou); L.lin.classList.toggle("agora", agora - (quando[n] || 0) < 2500);
        }
        for (const [n, p] of Object.entries(pilulas)) {
          const v = c[n]; if (v === undefined) continue;
          p.classList.toggle("on", !!v);
          const mudou = ini[n] !== undefined && !!v !== !!ini[n];
          if (ultimo[n] !== undefined && ultimo[n] !== v) quando[n] = agora;
          ultimo[n] = v;
          p.classList.toggle("mudou", mudou); p.classList.toggle("agora", agora - (quando[n] || 0) < 2500);
        }
      },
    };
  }
  return { montar };
})();
