/* RMD AudioLab — Etapa 2 (Técnicas vocais) e Etapa 3 (Técnicas de regência). 15/11/2026, pedido do Rinaldo.
   Este arquivo só ACRESCENTA: figuras novas em FIG.F, dois temas novos em CONTEUDO.temas e o roteiro do professor em EXPLICACOES_INICIANTES.
   Os temas antigos ("Canto e microfone", "Regência básica") continuam iguais.
   Ilustrações: desenho próprio em SVG (sem foto da internet, sem direitos de terceiros). Algumas são animadas (o desenho se move no telão). */
"use strict";
(function (H) {
  const { C, F, svg, tx, rect, circ, lin, cam, seta, r1 } = H;
  const quebra = (s, n) => { const p = String(s).split(" "), L = []; let a = ""; p.forEach((w) => { if ((a + " " + w).trim().length > n) { L.push(a); a = w; } else a = (a + " " + w).trim(); }); if (a) L.push(a); return L; };
  const anim = (attr, valores, dur, extra) => '<animate attributeName="' + attr + '" values="' + valores + '" dur="' + dur + 's" repeatCount="indefinite"' + (extra || "") + "/>";

  // ---------- modelos de figura (cartões numerados e tabela), iguais em estilo aos de figuras.js
  function cartoes(id, aria, titulo, itens, cor, rodape) {
    F[id] = () => {
      let s = tx(400, 40, titulo, { t: 25, a: "middle", w: 700 });
      const n = itens.length, cols = n > 5 ? 2 : 1, rows = Math.ceil(n / cols), w = cols === 1 ? 680 : 340, h = Math.min(74, Math.floor((330 - (rows - 1) * 10) / rows)), x0 = cols === 1 ? 60 : 40, y0 = 68;
      itens.forEach(([t, d], i) => {
        const c = i % cols, r = Math.floor(i / cols), x = x0 + c * (w + 20), y = y0 + r * (h + 10);
        s += rect(x, y, w, h, { rx: 12, f: cor, op: 0.1, s: cor, sw: 2 }) + circ(x + 28, y + h / 2, 17, { f: cor }) + tx(x + 28, y + h / 2 + 7, String(i + 1), { t: 20, a: "middle", w: 800, c: "#0b1820" });
        const ls = quebra(d, cols === 1 ? 74 : 38);
        s += tx(x + 56, y + (ls.length > 1 ? 24 : 30), t, { t: 19, w: 700, c: cor }) + tx(x + 56, y + (ls.length > 1 ? 45 : 54), ls.slice(0, 2), { t: 14.5, c: C.txt });
      });
      if (rodape) s += tx(400, 432, rodape, { t: 16, a: "middle", c: C.mudo });
      return svg(aria, s);
    };
  }
  function tabela(id, aria, titulo, cols, linhas, cor, rodape) {
    F[id] = () => {
      let s = tx(400, 40, titulo, { t: 25, a: "middle", w: 700 });
      const tot = cols.reduce((a, c) => a + c.w, 0), X = 40, W = 720, rh = Math.min(58, Math.floor(320 / linhas.length)); let x = X;
      const xs = cols.map((c) => { const r = x; x += W * c.w / tot; return r; });
      s += rect(X, 64, W, 34, { rx: 8, f: cor, op: 0.25 });
      cols.forEach((c, i) => (s += tx(xs[i] + 12, 87, c.t, { t: 16, w: 700, c: cor })));
      linhas.forEach((l, r) => {
        const y = 104 + r * rh;
        if (r % 2 === 0) s += rect(X, y, W, rh - 4, { rx: 6, f: "#ffffff", op: 0.04 });
        l.forEach((cel, i) => { const ls = quebra(cel, Math.max(10, Math.floor(W * cols[i].w / tot / 8.2))); s += tx(xs[i] + 12, y + (ls.length > 1 ? 21 : 30), ls.slice(0, 2), { t: i === 0 ? 16 : 14.5, w: i === 0 ? 700 : 400 }); });
      });
      if (rodape) s += tx(400, 438, rodape, { t: 16, a: "middle", c: C.mudo });
      return svg(aria, s);
    };
  }
  const caixa = (x, y, w, h, cor, titulo, linhas) => rect(x, y, w, h, { rx: 14, f: cor, op: 0.1, s: cor, sw: 2 }) + tx(x + w / 2, y + 30, titulo, { t: 18, a: "middle", w: 800, c: cor }) +
    tx(x + w / 2, y + 56, linhas, { t: 14.5, a: "middle" });

  // ================================================================ ETAPA 2 — TÉCNICAS VOCAIS
  const V = "#ff8fb8";
  cartoes("v2_mapa", "Os oito assuntos da Etapa 2", "Etapa 2 — Técnicas vocais", [
    ["Respiração e apoio", "O ar é o motor da voz."], ["Aquecimento", "Preparar o corpo antes de cantar."], ["Afinação", "Ouvir, comparar e acertar a nota."], ["Projeção", "Voz que chega longe sem gritar."],
    ["Dicção", "Letra clara: vogais e consoantes."], ["Interpretação", "Cantar a mensagem, não só as notas."], ["Saúde vocal", "Cuidar do instrumento que não se troca."], ["Ministério", "Técnica a serviço da congregação."]], V, "Cada assunto tem explicação, exemplo e exercício prático.");

  F.v2_aparelho = () => {
    let s = tx(400, 40, "Como a voz é produzida: 4 partes", { t: 25, a: "middle", w: 700 });
    const it = [["Motor", "pulmões e diafragma", "empurram o ar", C.az], ["Vibrador", "pregas vocais", "vibram com o ar", C.am], ["Ressoadores", "garganta, boca, nariz", "ampliam e dão cor", C.ver], ["Articuladores", "língua, lábios, dentes", "formam as palavras", V]];
    it.forEach(([t, a, b, c], i) => {
      const x = 30 + i * 192;
      s += rect(x, 80, 172, 210, { rx: 16, f: c, op: 0.12, s: c, sw: 2.5 }) + circ(x + 86, 132, 34, { f: c, op: 0.3, s: c, sw: 3 }) + tx(x + 86, 142, String(i + 1), { t: 30, a: "middle", w: 800 });
      s += tx(x + 86, 200, t, { t: 21, a: "middle", w: 800, c }) + tx(x + 86, 232, quebra(a, 18), { t: 15, a: "middle" }) + tx(x + 86, 272, b, { t: 14, a: "middle", c: C.mudo });
      if (i < 3) s += seta(x + 174, 185, x + 190, 185, C.mudo, 3);
    });
    // pregas vocais vistas de cima, abrindo e fechando (animado)
    s += tx(400, 330, "Pregas vocais vistas de cima (vibram centenas de vezes por segundo)", { t: 15, a: "middle", c: C.am });
    s += '<ellipse cx="400" cy="380" rx="70" ry="34" fill="#3a1f26" stroke="' + C.pele + '" stroke-width="3"/>';
    s += '<path d="M400 350 L372 410" stroke="' + C.am + '" stroke-width="9" stroke-linecap="round">' + anim("d", "M400 350 L372 410;M400 350 L392 410;M400 350 L372 410", 0.5) + "</path>";
    s += '<path d="M400 350 L428 410" stroke="' + C.am + '" stroke-width="9" stroke-linecap="round">' + anim("d", "M400 350 L428 410;M400 350 L408 410;M400 350 L428 410", 0.5) + "</path>";
    s += tx(250, 386, "respirando: abertas", { t: 14, a: "middle", c: C.mudo }) + tx(560, 386, "cantando: fecham e vibram", { t: 14, a: "middle", c: C.mudo });
    return svg("Motor, vibrador, ressoadores e articuladores da voz, com as pregas vocais animadas", s);
  };

  F.v2_diafragma = () => {
    let s = tx(400, 38, "Respiração diafragmática (veja o movimento)", { t: 24, a: "middle", w: 700 });
    const cx = 230, T = 6;
    // corpo de frente: tronco
    s += '<path d="M140 90 Q230 60 320 90 L340 300 Q340 400 230 410 Q120 400 120 300 Z" fill="#12303d" stroke="' + C.linha + '" stroke-width="3"/>';
    // pulmões: crescem na inspiração
    const pulmao = (x, lado) => '<g transform="translate(' + x + ' 190)"><g>' + '<animateTransform attributeName="transform" type="scale" values="0.9 0.86;1.04 1.08;1.04 1.08;0.9 0.86;0.9 0.86" keyTimes="0;0.33;0.4;0.95;1" dur="' + T + 's" repeatCount="indefinite"/>' +
      '<path d="' + (lado < 0 ? "M10 -80 Q-60 -70 -62 20 Q-60 70 -8 64 Z" : "M-10 -80 Q60 -70 62 20 Q60 70 8 64 Z") + '" fill="' + C.az + '" fill-opacity="0.45" stroke="' + C.az + '" stroke-width="3"/></g></g>';
    s += pulmao(cx - 18, -1) + pulmao(cx + 18, 1);
    // diafragma: cúpula que desce (inspira) e sobe devagar (expira)
    const alto = "M135 262 Q230 170 325 262", baixo = "M135 282 Q230 238 325 282";
    s += '<path d="' + alto + '" fill="none" stroke="' + C.am + '" stroke-width="7" stroke-linecap="round"><animate attributeName="d" values="' + alto + ";" + baixo + ";" + baixo + ";" + alto + ";" + alto + '" keyTimes="0;0.33;0.4;0.95;1" dur="' + T + 's" repeatCount="indefinite"/></path>';
    // barriga que expande
    s += '<path d="M330 300 Q352 340 330 380" fill="none" stroke="' + C.ver + '" stroke-width="5" stroke-linecap="round"><animate attributeName="d" values="M330 300 Q345 340 330 380;M330 300 Q372 340 330 380;M330 300 Q372 340 330 380;M330 300 Q345 340 330 380;M330 300 Q345 340 330 380" keyTimes="0;0.33;0.4;0.95;1" dur="' + T + 's" repeatCount="indefinite"/></path>';
    s += tx(cx, 436, "diafragma (amarelo) · pulmões (azul) · barriga (verde)", { t: 14, a: "middle", c: C.mudo });
    // fases: acende a fase atual
    const fase = (y, cor, titulo, txt, vals) => '<g>' + rect(420, y, 350, 92, { rx: 14, f: cor, op: 0.12, s: cor, sw: 2 }) + '<rect x="420" y="' + y + '" width="350" height="92" rx="14" fill="' + cor + '" fill-opacity="0">' + anim("fill-opacity", vals, T, ' keyTimes="0;0.33;0.4;0.95;1"') + "</rect>" + tx(440, y + 32, titulo, { t: 20, w: 800, c: cor }) + tx(440, y + 58, txt, { t: 14.5 }) + "</g>";
    s += fase(80, C.az, "1. Inspira (pelo nariz)", ["O diafragma DESCE; a barriga e as costelas", "se abrem. Os ombros NÃO sobem."], "0.35;0.35;0;0;0.35");
    s += fase(190, C.am, "2. Expira cantando (apoio)", ["O diafragma sobe DEVAGAR: o ar sai", "aos poucos, sem empurrar a garganta."], "0;0;0.35;0.35;0");
    s += rect(420, 300, 350, 92, { rx: 14, f: C.verm, op: 0.08, s: C.verm, sw: 2, d: "6 5" }) + tx(440, 332, "Errado: respiração alta", { t: 19, w: 800, c: C.verm }) + tx(440, 358, ["Ombros sobem e o peito estufa: pouco ar", "e tensão no pescoço."], { t: 14.5 });
    return svg("Animação da respiração diafragmática: diafragma desce na inspiração e sobe devagar ao cantar", s);
  };

  F.v2_apoio = () => {
    let s = tx(400, 38, "Apoio: o ar sai de forma constante", { t: 25, a: "middle", w: 700 });
    const X = 90, Y = 360, W = 640;
    s += lin(X, Y, X + W, Y, C.linha, 2) + lin(X, Y, X, 80, C.linha, 2) + tx(X - 10, 90, "ar", { t: 15, a: "end", c: C.mudo }) + tx(X + W, Y + 26, "tempo da frase →", { t: 15, a: "end", c: C.mudo });
    s += cam("M" + X + " 120 Q" + (X + 60) + " 330 " + (X + 230) + " 352 L" + (X + 300) + " 358", C.verm, 5) + tx(X + 250, 300, "sem apoio: gasta tudo no começo", { t: 16, c: C.verm, w: 700 });
    s += cam("M" + X + " 140 L" + (X + 560) + " 190 Q" + (X + 600) + " 200 " + (X + 620) + " 350", C.ver, 5) + tx(X + 200, 140, "com apoio: saída firme até o fim da frase", { t: 16, c: C.ver, w: 700 });
    s += circ(X + 560, 190, 7, { f: C.ver }) + tx(X + 560, 222, "respira na pausa", { t: 14, a: "middle", c: C.mudo });
    s += tx(400, 404, "Teste: solte o ar em \"ssssss\" contando. A meta é 20 a 30 segundos com som igual do começo ao fim.", { t: 15.5, a: "middle" });
    s += tx(400, 432, "Apoio não é apertar a barriga: é manter as costelas abertas e soltar o ar devagar.", { t: 15, a: "middle", c: C.mudo });
    return svg("Gráfico do ar ao longo da frase, sem apoio e com apoio", s);
  };

  cartoes("v2_exerc_resp", "Exercícios de respiração", "Exercícios de respiração (5 minutos)", [
    ["Deitado com um livro", "O livro na barriga sobe ao inspirar e desce ao soltar."], ["Contagem 4-4-8", "Inspira em 4, segura em 4, solta em 8. Aumente aos poucos."], ["Sssss contínuo", "Solte o ar em S, firme e igual, contando os segundos."],
    ["Ffff em pulsos", "F-F-F-F curtos: a barriga dá pequenos impulsos."], ["Mãos nas costelas", "Inspire abrindo as costelas para os lados, sem ombros."], ["Respirar na letra", "Marque na letra onde respirar, antes de ensaiar."]], V, "Ombros parados, pescoço solto, ar entrando pelo nariz sempre que der tempo.");

  tabela("v2_aquec", "Roteiro de aquecimento vocal de 10 minutos", "Aquecimento vocal em 10 minutos", [{ t: "Tempo", w: 0.7 }, { t: "Exercício", w: 2 }, { t: "Para quê", w: 1.6 }], [
    ["1 min", "Alongar pescoço e ombros; bocejar", "soltar a tensão"], ["2 min", "Respiração 4-4-8 e Sssss", "ativar o apoio"], ["2 min", "Vibrar lábios (brrr) ou língua (trrr) subindo e descendo", "aquecer sem esforço"],
    ["2 min", "Canudo: cantar uma música dentro do canudo", "equilibrar ar e voz"], ["2 min", "Hum (boca fechada) e \"nhã-nhã\" em escalas curtas", "ressonância na frente"], ["1 min", "Vogais A-É-I-Ó-U e um trecho do louvor", "ligar técnica e música"]], V, "Comece no grave e suave. Suba aos poucos. Se doer ou arranhar, pare.");

  F.v2_sovt = () => {
    let s = tx(400, 38, "Exercícios de \"trato semiocluído\": canudo e vibração", { t: 23, a: "middle", w: 700 });
    s += caixa(30, 70, 236, 250, C.az, "Canudo", ["Cantar ou fazer sirene", "dentro de um canudo.", "Começa com o canudo", "no ar; depois num copo", "com água (bolhas)."]);
    // canudo animado com bolhas
    s += rect(110, 246, 80, 66, { rx: 8, f: C.az, op: 0.18, s: C.az, sw: 2 }) + lin(150, 214, 150, 300, C.am, 6);
    [0, 0.4, 0.8].forEach((a) => (s += '<circle cx="150" cy="300" r="5" fill="#cfe0e7" fill-opacity="0.8"><animate attributeName="cy" values="300;252" dur="1.2s" begin="' + a + 's" repeatCount="indefinite"/><animate attributeName="r" values="3;7" dur="1.2s" begin="' + a + 's" repeatCount="indefinite"/></circle>'));
    s += caixa(282, 70, 236, 250, C.am, "Lábios (brrr)", ["Lábios soltos vibrando,", "como motor de carro.", "Faça sirene do grave", "ao agudo. Se travar,", "apoie as bochechas."]);
    s += caixa(534, 70, 236, 250, C.ver, "Língua (trrr) e hum", ["R vibrado de língua", "ou boca fechada em", "\"hummm\", sentindo", "cócegas nos lábios", "e no nariz."]);
    s += tx(400, 356, "Por que funciona: a boca quase fechada cria uma pequena contrapressão de ar,", { t: 16, a: "middle" });
    s += tx(400, 380, "que ajuda as pregas vocais a vibrar com menos esforço. É seguro e muito usado por fonoaudiólogos.", { t: 16, a: "middle" });
    s += tx(400, 420, "2 a 3 minutos bastam. Volume baixo; nada de força.", { t: 15, a: "middle", c: C.mudo });
    return svg("Exercícios de canudo, vibração de lábios e de língua para aquecer a voz", s);
  };

  F.v2_afinacao = () => {
    let s = tx(400, 38, "Afinação: a voz precisa chegar no alvo", { t: 25, a: "middle", w: 700 });
    const X = 70, W = 660, notas = [[0, 2], [1, 3], [2, 4], [3, 3], [4, 2]];
    const y = (n) => 300 - n * 45;
    for (let n = 0; n <= 5; n++) s += lin(X, y(n), X + W, y(n), C.grade, 1);
    notas.forEach(([i, n]) => (s += rect(X + i * 132 + 6, y(n) - 9, 120, 18, { rx: 9, f: C.ver, op: 0.35, s: C.ver, sw: 2 })));
    s += tx(X, 330, "verde = nota certa (alvo)", { t: 14, c: C.ver });
    // voz desafinada (vermelha) e afinada (amarela) alternando
    let d1 = "", d2 = "";
    notas.forEach(([i, n], k) => {
      const x0 = X + i * 132 + 6, desvio = [14, 18, -16, 12, 20][k];
      d1 += (k ? " L" : "M") + x0 + " " + (y(n) + desvio + 10) + " Q" + (x0 + 30) + " " + (y(n) + desvio) + " " + (x0 + 120) + " " + (y(n) + desvio);
      d2 += (k ? " L" : "M") + x0 + " " + (y(n) + 14) + " Q" + (x0 + 26) + " " + y(n) + " " + (x0 + 120) + " " + y(n);
    });
    s += '<path d="' + d1 + '" fill="none" stroke="' + C.verm + '" stroke-width="4">' + anim("stroke-opacity", "1;1;0;0;1", 6) + "</path>";
    s += '<path d="' + d2 + '" fill="none" stroke="' + C.am + '" stroke-width="4">' + anim("stroke-opacity", "0;0;1;1;0", 6) + "</path>";
    s += tx(400, 360, "vermelho: abaixo ou acima do alvo (desafinado) · amarelo: chega e fica na nota", { t: 15, a: "middle" });
    s += tx(400, 392, "Afinar = ouvir a nota, imaginar antes de cantar e corrigir ouvindo o resultado.", { t: 16, a: "middle", w: 700, c: C.am });
    s += tx(400, 422, "Diferença de 1/4 de tom já é percebida pelo ouvido. Use o \"Teste vocal\" nas Ferramentas.", { t: 14.5, a: "middle", c: C.mudo });
    return svg("Gráfico de afinação: voz desafinada fora do alvo e voz afinada sobre as notas", s);
  };

  cartoes("v2_afin_treino", "Exercícios de afinação", "Treino de afinação", [
    ["Nota e eco", "O teclado toca uma nota; você repete. Depois, 3 notas."], ["Escala devagar", "Dó-Ré-Mi-Fá-Sol subindo e descendo, sem pressa."], ["Intervalos", "Lembre de músicas conhecidas para cada salto."],
    ["Acorde parado", "Banda segura um acorde; cada voz acha a sua nota."], ["Gravar e ouvir", "Grave no celular: o ouvido percebe mais de fora."], ["Afinador", "Use o Teste vocal do AudioLab para ver a nota."]], V, "Desafinar quase sempre é falta de escuta ou de apoio, não falta de dom.");

  F.v2_projecao = () => {
    let s = tx(400, 38, "Projetar a voz não é gritar", { t: 26, a: "middle", w: 700 });
    s += caixa(40, 70, 340, 230, C.verm, "Gritar", ["Força na garganta", "Pescoço tenso, veias saltadas", "Ar empurrado de uma vez", "Rouquidão depois do culto", "Voz dura, sem cor"]);
    s += caixa(420, 70, 340, 230, C.ver, "Projetar", ["Ar com apoio (barriga e costelas)", "Garganta aberta, como no bocejo", "Som na \"máscara\" (frente do rosto)", "Boca bem aberta nas vogais", "Voz cheia, chega ao fundo"]);
    // ondas saindo (animadas)
    for (let i = 0; i < 3; i++) s += '<path d="M590 330 q20 20 0 40" fill="none" stroke="' + C.ver + '" stroke-width="4" stroke-linecap="round"><animateTransform attributeName="transform" type="translate" values="0 0;140 0" dur="2s" begin="' + (i * 0.66) + 's" repeatCount="indefinite"/>' + anim("stroke-opacity", "1;0", 2, ' begin="' + (i * 0.66) + 's"') + "</path>";
    s += tx(400, 350, "Exercício: diga \"ei!\" como quem chama alguém do outro lado da rua,", { t: 16, a: "middle" }) + tx(400, 374, "sentindo a barriga trabalhar e a garganta solta.", { t: 16, a: "middle" });
    s += tx(400, 420, "No templo com som, o microfone faz o volume: o cantor faz a qualidade.", { t: 15.5, a: "middle", c: C.am, w: 700 });
    return svg("Comparação entre gritar e projetar a voz", s);
  };

  F.v2_ressoadores = () => {
    let s = tx(400, 38, "Ressoadores: onde a voz \"soa\"", { t: 25, a: "middle", w: 700 });
    // perfil de cabeça simples
    s += '<path d="M220 110 Q300 70 360 120 Q392 150 386 196 L404 230 L384 240 Q392 266 378 284 Q360 300 330 296 L326 340 L236 340 L240 300 Q178 270 176 200 Q178 140 220 110 Z" fill="#12303d" stroke="' + C.pele + '" stroke-width="3"/>';
    const zona = (x, y, r, cor, d) => '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + cor + '" fill-opacity="0.35" stroke="' + cor + '" stroke-width="2">' + anim("r", r + ";" + (r + 6) + ";" + r, 1.6, ' begin="' + d + 's"') + "</circle>";
    s += zona(290, 140, 26, C.rox, 0) + zona(352, 214, 22, C.ver, 0.4) + zona(340, 268, 20, C.am, 0.8) + zona(280, 330, 26, C.lar, 1.2);
    const leg = [[C.rox, "Cabeça", "notas agudas, voz leve e brilhante"], [C.ver, "Máscara (nariz e maçãs do rosto)", "clareza e projeção: \"hum\", \"nhã\""], [C.am, "Boca", "vogais abertas, som redondo"], [C.lar, "Peito", "notas graves, voz cheia e firme"]];
    leg.forEach(([c, t, d], i) => { const y = 100 + i * 74; s += circ(470, y + 8, 12, { f: c }) + tx(492, y + 6, t, { t: 18, w: 800, c }) + tx(492, y + 30, d, { t: 15 }); });
    s += tx(400, 410, "Exercício: \"hummm\" com boca fechada até sentir cócegas nos lábios; depois abra para \"mmmá\".", { t: 15.5, a: "middle" });
    s += tx(400, 436, "A voz equilibrada usa todos os ressoadores juntos.", { t: 15, a: "middle", c: C.mudo });
    return svg("Perfil da cabeça com os ressoadores: cabeça, máscara, boca e peito", s);
  };

  cartoes("v2_articuladores", "Os articuladores da fala", "Os articuladores: quem forma as palavras", [
    ["Lábios", "P, B, M, F, V e as vogais O e U. Precisam se mexer!"], ["Língua", "T, D, L, N, R, S. Ponta solta e ágil, sem recuar para a garganta."], ["Mandíbula", "Solta, abre a boca nas vogais. Queixo travado abafa a voz."],
    ["Palato mole (céu da boca)", "Sobe no bocejo e abre espaço: voz mais redonda."], ["Dentes", "Apoio para S, Z, X e F. Sibilante demais apita no microfone."]], V, "Quanto mais livres os articuladores, mais clara a letra.");

  F.v2_vogais = () => {
    let s = tx(400, 38, "Vogais: o formato da boca", { t: 25, a: "middle", w: 700 });
    const v = [["A", 46, 54, "boca bem aberta"], ["É", 52, 36, "aberta, sorriso leve"], ["Ê", 48, 28, "meio aberta"], ["I", 56, 16, "sorriso, dentes à mostra"], ["Ó", 38, 46, "redonda e aberta"], ["Ô", 30, 34, "redonda, mais fechada"], ["U", 18, 20, "bico, lábios à frente"]];
    v.forEach(([l, rx, ry, d], i) => {
      const x = 62 + i * 112, y = 170;
      s += '<ellipse cx="' + x + '" cy="' + y + '" rx="' + rx + '" ry="' + ry + '" fill="#3a1f26" stroke="' + C.rosa + '" stroke-width="5"/>';
      if (l === "I" || l === "É") s += rect(x - rx * 0.7, y - ry + 4, rx * 1.4, 8, { rx: 3, f: "#f4f4f4" });
      s += tx(x, 270, l, { t: 40, a: "middle", w: 800, c: V }) + tx(x, 300, quebra(d, 13), { t: 13, a: "middle", c: C.mudo });
    });
    s += tx(400, 360, "Cante a música só com as vogais (sem consoantes): a voz fica ligada e a afinação melhora.", { t: 16, a: "middle" });
    s += tx(400, 388, "Vogal pura: não deixe o \"A\" virar \"Ã\" nem o \"Ê\" virar \"Ei\" no meio da nota longa.", { t: 16, a: "middle" });
    s += tx(400, 424, "Em grupo, todos fazem a MESMA vogal: é o segredo do som unido.", { t: 15.5, a: "middle", c: C.am, w: 700 });
    return svg("Formatos de boca para as vogais A, É, Ê, I, Ó, Ô e U", s);
  };

  // ---------- exercício da caneta (animado em 3 passos, ciclo de 9 s)
  const kf9 = (v) => r1(v * 1000) / 1000;
  const so = (a, b, D) => {   // visível só entre a e b segundos do ciclo D (troca seca)
    const ini = a <= 0, fim = b >= D;
    const v = ini && fim ? "1;1" : ini ? "1;0" : fim ? "0;1" : "0;1;0", k = ini && fim ? "0;1" : ini ? "0;" + kf9(b / D) : fim ? "0;" + kf9(a / D) : "0;" + kf9(a / D) + ";" + kf9(b / D);
    return '<animate attributeName="opacity" values="' + v + '" keyTimes="' + k + '" calcMode="discrete" dur="' + D + 's" repeatCount="indefinite"/>';
  };
  F.v2_caneta = () => {
    const D = 9;
    let s = tx(400, 36, "Exercício da caneta: soltar a língua e os lábios", { t: 24, a: "middle", w: 700 });
    // rosto de frente
    s += circ(200, 235, 118, { f: C.pele, s: "#c99d78", sw: 3 }) + '<path d="M95 190 Q200 60 305 190 Q300 120 200 112 Q100 120 95 190Z" fill="#5a3a26"/>';
    s += circ(160, 215, 10, { f: "#24323a" }) + circ(240, 215, 10, { f: "#24323a" }) + '<path d="M196 230 Q190 258 204 262" fill="none" stroke="#b07f5c" stroke-width="3"/>';
    // boca: abre e fecha quando fala (a partir de 3 s)
    let ry = ["9"], kt = ["0"];
    for (let t = 3; t < D - 0.01; t += 0.25) { ry.push(String([8, 17, 11, 19, 7, 15][Math.round(t * 4) % 6])); kt.push(kf9(t / D)); }
    ry.push("9"); kt.push("1");
    s += '<ellipse cx="200" cy="296" rx="38" ry="9" fill="#7a2230" stroke="#5b1621" stroke-width="2"><animate attributeName="ry" values="' + ry.join(";") + '" keyTimes="' + kt.join(";") + '" dur="' + D + 's" repeatCount="indefinite"/></ellipse>';
    s += '<rect x="176" y="288" width="48" height="6" rx="2" fill="#ffffff" opacity="0.9"/>';
    // caneta atravessada entre os dentes: entra, fica, sai
    s += '<g><animateTransform attributeName="transform" type="translate" values="320 0;0 0;0 0;0 -60;0 -60" keyTimes="0;0.13;0.66;0.7;1" dur="' + D + 's" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;1;0;0" keyTimes="0;0.1;0.66;0.7;1" dur="' + D + 's" repeatCount="indefinite"/>'
      + rect(58, 289, 250, 14, { rx: 7, f: "#3b7dd8", s: "#1f4f94", sw: 2 }) + rect(272, 286, 46, 20, { rx: 6, f: "#1f4f94" }) + '<path d="M58 289 L40 296 L58 303Z" fill="#d9e2ea"/>' + "</g>";
    // ondas de som quando fala
    s += '<g opacity="0">' + so(3, D, D) + [0, 1, 2].map((i) => '<path d="M' + (334 + i * 18) + " " + (276 - i * 8) + " Q" + (346 + i * 18) + " 296 " + (334 + i * 18) + " " + (316 + i * 8) + '" fill="none" stroke="' + C.am + '" stroke-width="3"><animate attributeName="opacity" values="0.2;1;0.2" dur="0.6s" begin="' + i * 0.2 + 's" repeatCount="indefinite"/></path>').join("") + "</g>";
    // balão de fala
    s += '<g opacity="0">' + so(3, 6, D) + rect(240, 64, 168, 56, { rx: 14, f: "#ffffff" }) + '<path d="M262 118 L250 140 L282 118Z" fill="#ffffff"/>' + tx(324, 99, "O ra-to ro-eu...", { t: 17, a: "middle", w: 800, c: "#24323a" }) + "</g>";
    s += '<g opacity="0">' + so(6, D, D) + rect(240, 64, 168, 56, { rx: 14, f: "#ffffff" }) + '<path d="M262 118 L250 140 L282 118Z" fill="#ffffff"/>' + tx(324, 99, "Ficou claro! ✔", { t: 17, a: "middle", w: 800, c: "#2f8a45" }) + "</g>";
    s += '<g opacity="0">' + so(0.6, 3, D) + tx(200, 392, "↑ caneta de lado, só apoiada nos dentes", { t: 15, a: "middle", w: 700, c: "#3b9df0" }) + "</g>";
    // passos (acendem na vez)
    const P = [[0, 3, "1", "Morda a caneta de lado", ["atravessada, sem apertar:", "ela só fica apoiada."]], [3, 6, "2", "Leia a letra em voz alta", ["por 1 minuto, exagerando", "o movimento da boca."]], [6, 9, "3", "Tire a caneta e leia de novo", ["a língua e os lábios ficam", "soltos: a palavra sai clara."]]];
    P.forEach(([a, b, n, t, d], i) => {
      const y = 70 + i * 106;
      s += rect(430, y, 350, 96, { rx: 14, f: V, op: 0.08, s: V, sw: 2 }) + '<rect x="430" y="' + y + '" width="350" height="96" rx="14" fill="' + V + '" opacity="0">' + so(a, b, D).replace('values="0;1;0"', 'values="0;0.28;0"').replace('values="1;0"', 'values="0.28;0"').replace('values="0;1"', 'values="0;0.28"') + "</rect>";
      s += circ(462, y + 34, 18, { f: V }) + tx(462, y + 41, n, { t: 20, a: "middle", w: 800, c: "#0b1820" }) + tx(492, y + 40, t, { t: 18.5, w: 800, c: V }) + tx(492, y + 66, d, { t: 15, c: C.txt });
    });
    s += tx(400, 428, "Use caneta limpa (ou lápis/rolha) · 1 minuto basta · se doer o maxilar, pare.", { t: 15, a: "middle", c: C.mudo });
    return svg("Animação de um rosto com caneta atravessada entre os dentes: morder de lado, ler em voz alta e depois ler sem a caneta", s);
  };

  // ---------- trava-línguas: a frase acende sílaba por sílaba, devagar e depois rápido (ciclo de 10 s)
  F.v2_trava = () => {
    const D = 10, sil = ["O", "ra", "to", "ro", "eu", "a", "rou", "pa", "do", "rei", "de", "Ro", "ma"], lento = 0.45, rapido = 0.2, ini2 = sil.length * lento + 0.6;
    let s = tx(400, 36, "Trava-línguas: devagar primeiro, depois rápido", { t: 24, a: "middle", w: 700 });
    s += rect(20, 52, 760, 122, { rx: 14, f: V, op: 0.08, s: V, sw: 2 });
    s += '<g>' + so(0, ini2, D) + tx(40, 80, "🐢 devagar, exagerando a boca", { t: 16, w: 800, c: C.ver }) + "</g>" + '<g opacity="0">' + so(ini2, D, D) + tx(40, 80, "🐇 agora rápido, sem errar", { t: 16, w: 800, c: C.lar }) + "</g>";
    s += tx(760, 80, "o R aparece em destaque", { t: 13.5, a: "end", c: C.mudo });
    sil.forEach((p, i) => {
      const x = 64 + i * 56, t1 = i * lento, t2 = ini2 + i * rapido, foco = /r/i.test(p);
      const k = ["0", kf9(t1 / D), kf9((t1 + lento) / D), kf9(t2 / D), kf9((t2 + rapido) / D), "1"], v = ["0.35", "1", "0.35", "1", "0.35", "0.35"];
      if (i === 0) { k.splice(1, 1); v.splice(0, 1); }
      s += '<text x="' + x + '" y="136" text-anchor="middle" font-size="27" font-weight="800" fill="' + (foco ? C.verm : C.txt) + '" opacity="0.35"><animate attributeName="opacity" values="' + v.join(";") + '" keyTimes="' + k.join(";") + '" calcMode="discrete" dur="' + D + 's" repeatCount="indefinite"/>' + p + "</text>";
    });
    s += '<circle cy="158" r="6" fill="' + C.am + '"><animate attributeName="cx" values="64;' + (64 + 12 * 56) + ";" + (64 + 12 * 56) + ";64;" + (64 + 12 * 56) + ";" + (64 + 12 * 56) + '" keyTimes="0;' + kf9(12 * lento / D) + ";" + kf9((ini2 - 0.05) / D) + ";" + kf9(ini2 / D) + ";" + kf9((ini2 + 12 * rapido) / D) + ';1" dur="' + D + 's" repeatCount="indefinite"/></circle>';
    // outros trava-línguas, com o som que cada um treina
    const L = [["TR", "Três pratos de trigo para três tigres tristes.", C.az], ["R e NH", "A aranha arranha a rã. A rã arranha a aranha.", C.ver], ["S e B", "O sabiá não sabia que o sábio sabia que o sabiá não sabia assobiar.", C.am], ["P", "O peito do pé de Pedro é preto.", C.lar]];
    L.forEach(([som, f, c], i) => {
      const x = 20 + (i % 2) * 390, y = 186 + Math.floor(i / 2) * 104;
      s += rect(x, y, 370, 94, { rx: 12, f: c, op: 0.1, s: c, sw: 2 }) + rect(x + 12, y + 12, 74, 30, { rx: 15, f: c }) + tx(x + 49, y + 33, som, { t: 16, a: "middle", w: 800, c: "#0b1820" }) + tx(x + 98, y + 33, "treina o som", { t: 13.5, c: C.mudo });
      s += tx(x + 14, y + 64, quebra("\"" + f + "\"", 42).slice(0, 2), { t: 16, w: 700, c: C.txt });
    });
    s += tx(400, 412, "Como fazer: 1) devagar, articulando bem · 2) mais rápido · 3) três vezes seguidas sem errar.", { t: 15.5, a: "middle", w: 700 });
    s += tx(400, 438, "No canto: consoante rápida e clara; S, R e T do fim da palavra, todos juntos no corte.", { t: 14.5, a: "middle", c: C.mudo });
    return svg("Trava-língua O rato roeu a roupa do rei de Roma acendendo sílaba por sílaba, devagar e rápido, e outros quatro trava-línguas", s);
  };

  cartoes("v2_consoantes_antigo", "Consoantes e trava-línguas", "Consoantes e trava-línguas", [
    ["Caneta entre os dentes", "Leia a letra com uma caneta mordida; depois sem: fica mais claro."], ["O rato roeu...", "\"O rato roeu a roupa do rei de Roma\" — devagar e depois rápido."], ["Três tigres", "\"Três pratos de trigo para três tigres tristes.\""],
    ["Final junto", "S, R e T do fim da palavra: todos soltam no mesmo tempo."], ["P e B no microfone", "Cante levemente de lado para não estourar."], ["Fale a letra", "Leia em voz alta, no ritmo, antes de cantar."]], V, "Letra entendida é mensagem entendida.");

  F.v2_frase = () => {
    let s = tx(400, 38, "Interpretação: a frase tem começo, ápice e fim", { t: 24, a: "middle", w: 700 });
    // arco da frase com a letra
    s += cam("M70 260 Q400 60 730 260", C.am, 5) + tx(400, 120, "ápice (palavra mais importante)", { t: 15, a: "middle", c: C.am });
    const pal = [["Grande", 90], ["é", 190], ["o", 240], ["Senhor", 330], ["e", 445], ["mui", 500], ["digno", 580], ["de louvor", 690]];
    pal.forEach(([p, x]) => (s += tx(x, 300, p, { t: 22, a: "middle", w: p === "Senhor" ? 800 : 400, c: p === "Senhor" ? C.am : C.txt })));
    s += tx(395, 338, "'", { t: 34, a: "middle", w: 800, c: C.az }) + tx(395, 362, "respira", { t: 13, a: "middle", c: C.az });
    // crescendo e decrescendo
    s += cam("M90 384 L380 368 M90 384 L380 400", C.ver, 3) + cam("M420 368 L710 384 M420 400 L710 384", C.ver, 3);
    s += tx(235, 424, "cresce (mp → f)", { t: 15, a: "middle", c: C.ver }) + tx(565, 424, "diminui (f → mp)", { t: 15, a: "middle", c: C.ver });
    s += tx(400, 210, "Pergunte: o que esta frase quer dizer? Cante isso.", { t: 16, a: "middle", c: C.mudo });
    return svg("Arco de uma frase musical com respiração, ápice e dinâmica", s);
  };

  cartoes("v2_interpretacao", "Passos para interpretar uma música", "Interpretar é contar a mensagem", [
    ["Leia a letra como texto", "Entenda quem fala, com quem fala e o que pede."], ["Ache as palavras-chave", "Elas recebem mais apoio, nunca grito."], ["Marque respirações", "Respirar no meio da palavra quebra o sentido."],
    ["Dinâmica", "Estrofe mais suave, refrão mais cheio, final como pede a letra."], ["Rosto e olhar", "A expressão acompanha a mensagem."], ["Menos enfeite", "Melisma demais esconde a letra e confunde quem canta junto."]], V, "Técnica serve à mensagem; a mensagem não serve à técnica.");

  F.v2_registros = () => {
    let s = tx(400, 38, "Controle: registros da voz e a passagem", { t: 25, a: "middle", w: 700 });
    const X = 120, W = 560;
    const faixa = (y, h, cor, t, d) => rect(X, y, W, h, { rx: 12, f: cor, op: 0.18, s: cor, sw: 2 }) + tx(X + 20, y + h / 2 - 2, t, { t: 19, w: 800, c: cor }) + tx(X + 20, y + h / 2 + 22, d, { t: 14.5 });
    s += faixa(70, 92, C.rox, "Voz de cabeça (agudos)", "leve, brilhante; vibra mais na cabeça");
    s += faixa(170, 92, C.ver, "Voz mista (a ponte)", "mistura das duas: passa do grave ao agudo sem quebrar");
    s += faixa(270, 92, C.lar, "Voz de peito (graves e médios)", "cheia, parecida com a fala; vibra no peito");
    s += seta(735, 350, 735, 80, C.am, 4) + tx(750, 220, "mais agudo", { t: 14, c: C.am, r: -90 });
    s += lin(X, 166, X + W, 166, C.verm, 2, "8 6") + lin(X, 266, X + W, 266, C.verm, 2, "8 6");
    s += tx(400, 396, "Na passagem a voz pode \"quebrar\": treine sirenes suaves com canudo ou brrr, do grave ao agudo.", { t: 15.5, a: "middle" });
    s += tx(400, 424, "Não puxe a voz de peito para o agudo com força: é a causa mais comum de rouquidão.", { t: 15, a: "middle", c: C.mudo });
    return svg("Registros da voz: peito, misto e cabeça, com as passagens", s);
  };

  tabela("v2_higiene", "Higiene vocal: o que fazer e o que evitar", "Saúde vocal no dia a dia", [{ t: "Situação", w: 1 }, { t: "Faça", w: 1.7 }, { t: "Evite", w: 1.7 }], [
    ["Água", "Goles ao longo do dia, também no ensaio", "Ficar horas sem beber água"], ["Descanso", "Pausa de 10 minutos a cada hora de uso", "Ensaio longo seguido de culto sem pausa"], ["Fala", "Volume moderado; chegue perto para falar", "Gritar, cochichar forçado, falar sobre barulho"],
    ["Garganta", "Engolir saliva ou um gole de água", "Pigarrear e tossir para limpar"], ["Ambiente", "Ar umidificado, vapor de água", "Fumaça, poeira, ar-condicionado direto"], ["Corpo", "Dormir bem; jantar leve antes de cantar", "Refluxo sem tratar, álcool, cigarro"]], V, "Gelado e quente não \"estragam\" a voz por si; o que machuca é forçar e não descansar.");

  cartoes("v2_alerta", "Sinais de alerta na voz", "Sinais de alerta: procure ajuda", [
    ["Rouquidão por mais de 2 semanas", "Procure um otorrinolaringologista (médico de garganta)."], ["Dor ao cantar ou falar", "Voz não deve doer. Pare e descanse."], ["Perdeu os agudos", "Notas que saíam fáceis agora falham ou soam ásperas."],
    ["Cansa muito rápido", "Voz some no fim do culto ou do dia."], ["Pigarro constante", "Pode ser refluxo ou alergia: trate a causa."]], C.verm, "O fonoaudiólogo trata e treina a voz; o médico examina as pregas vocais.");

  cartoes("v2_ministro", "O cantor como ministro de louvor", "Técnicas para ministros de louvor", [
    ["Preparo completo", "Oração, letra decorada, tom e ordem combinados antes."], ["Conduzir a igreja", "O objetivo é a congregação cantar junto, não assistir."], ["Olhar para o povo", "Olhos fechados o tempo todo afastam quem canta."],
    ["Falas curtas", "Entre músicas, frases breves e claras. Nada de sermão."], ["Melodia simples", "Cante a melodia que o povo conhece; enfeite pouco."], ["Ouvir a equipe", "Retorno certo, volume equilibrado, atenção ao líder."]], V, "Técnica e espiritualidade andam juntas: uma não substitui a outra.");

  F.v2_tom = () => {
    let s = tx(400, 38, "O tom certo para a congregação cantar", { t: 25, a: "middle", w: 700 });
    // teclado simplificado de Sol a Mi com faixa confortável Lá–Ré
    const nomes = ["Sol", "Lá", "Si", "Dó", "Ré", "Mi", "Fá", "Sol", "Lá", "Si", "Dó", "Ré", "Mi", "Fá"], X = 50, w = 50;
    nomes.forEach((n, i) => (s += rect(X + i * w, 90, w - 2, 150, { rx: 4, f: "#e8eef1" }) + tx(X + i * w + w / 2 - 1, 226, n, { t: 13, a: "middle", c: "#0b1820", w: 700 })));
    [0, 1, 3, 4, 6, 7, 8, 10, 11].forEach((i) => (s += rect(X + i * w + w * 0.68, 90, w * 0.62, 92, { rx: 3, f: "#14232b" })));
    s += rect(X + 1 * w, 250, w * 11, 26, { rx: 13, f: C.ver, op: 0.6 }) + tx(X + 6.5 * w, 268, "faixa confortável: do Lá grave ao Ré agudo (mulheres)", { t: 14.5, a: "middle", w: 700, c: "#0b1820" });
    s += tx(400, 310, "Homens cantam a mesma melodia uma oitava abaixo.", { t: 16, a: "middle" });
    s += tx(400, 344, "Se a melodia passa muito do Ré agudo, a igreja para de cantar ou grita.", { t: 16, a: "middle" });
    s += tx(400, 378, "Escolha o tom pela congregação, não pelo solista: o solista pode fazer voz diferente por cima.", { t: 16, a: "middle", c: C.am, w: 700 });
    s += tx(400, 420, "Referência prática de ministérios de louvor; ajuste conforme a igreja.", { t: 14, a: "middle", c: C.mudo });
    return svg("Faixa de notas confortável para a congregação cantar, no teclado", s);
  };

  cartoes("v2_backing", "Técnicas para backing vocal", "Backing vocal e harmonia", [
    ["Voz abaixo do líder", "O backing sustenta; a melodia principal fica na frente."], ["Abrir vozes", "Comece pela terça acima da melodia; ensaie separado."], ["Mesma vogal e corte", "Respirar, pronunciar e terminar junto."],
    ["Microfone igual", "Todos na mesma distância para o técnico equilibrar."], ["Não dobrar o líder", "Cantar igual ao solista o tempo todo embola o som."], ["Ouvir o vizinho", "Se não ouve quem está ao lado, está alto demais."]], V, "Três vozes afinadas valem mais que seis vozes disputando.");

  tabela("v2_ensaio", "Roteiro de ensaio do ministério de louvor", "Ensaio do ministério (60 minutos)", [{ t: "Tempo", w: 0.8 }, { t: "O que fazer", w: 2.4 }, { t: "Quem conduz", w: 1.1 }], [
    ["10 min", "Oração e aquecimento vocal", "líder / preparador"], ["10 min", "Afinação: acorde parado e escalas", "líder"], ["20 min", "Músicas novas: por partes, vozes separadas", "líder e backings"],
    ["15 min", "Repertório do culto do começo ao fim, com transições", "todos + técnico"], ["5 min", "Avaliação: o que melhorou e o que treinar em casa", "líder"]], V, "Grave o ensaio e mande para o grupo: cada um treina a sua voz em casa.");

  // ================================================================ ETAPA 3 — TÉCNICAS DE REGÊNCIA
  const R = "#ffb347";
  cartoes("r3_mapa", "Os oito assuntos da Etapa 3", "Etapa 3 — Técnicas de regência", [
    ["O papel do regente", "Líder musical e de pessoas."], ["Postura e gestos", "O corpo comunica antes da voz."], ["Compassos", "Os desenhos de 2, 3, 4 e 6 tempos."], ["Entradas e cortes", "Começar e terminar juntos."],
    ["Andamento", "Manter, acelerar e frear com segurança."], ["Dinâmica", "Forte e suave pelo tamanho do gesto."], ["Comunicação", "Falar pouco, mostrar muito."], ["Organização", "Coral e conjunto bem estruturados."]], R, "Os padrões de compasso deste tema são animados: acompanhe a bolinha.");

  cartoes("r3_papel", "O papel do regente", "O papel do regente", [
    ["Antes do ensaio", "Estuda a partitura, escolhe o tom e planeja o ensaio."], ["No ensaio", "Ensina as vozes, corrige, une o grupo e cuida do tempo."], ["Na apresentação", "Dá entradas, mantém o andamento, dinâmica e cortes."],
    ["Com as pessoas", "Motiva, respeita, resolve conflitos e forma novos líderes."], ["Com a equipe", "Combina com banda, técnico de som e liderança da igreja."]], R, "O regente não faz som: ele faz o grupo soar junto.");

  cartoes("r3_estudo", "Como estudar a música antes do ensaio", "Estudar a música antes do ensaio", [
    ["Ouvir e cantar", "Cante todas as vozes, pelo menos os trechos difíceis."], ["Forma", "Marque introdução, estrofes, refrão, ponte e final."], ["Respirações", "Marque com ' onde o grupo respira junto."],
    ["Entradas", "Circule cada entrada de naipe e de solista."], ["Dinâmica", "Escreva p, mf, f e os crescendos."], ["Pontos difíceis", "Separe o que vai precisar de mais ensaio."]], R, "Quem não sabe a música não consegue reger: só acompanha.");

  F.r3_postura = () => {
    let s = tx(400, 36, "Postura e plano de regência", { t: 25, a: "middle", w: 700 });
    const cx = 250;
    // plano de regência (caixa)
    s += rect(cx - 150, 150, 300, 150, { rx: 16, f: R, op: 0.12, s: R, sw: 2, d: "8 6" }) + tx(cx - 195, 210, ["plano", "de", "regência"], { t: 15, a: "middle", c: R, w: 700 });
    // corpo
    s += circ(cx, 92, 34, { f: C.pele, op: 0.9 }) + cam("M" + (cx - 70) + " 150 Q" + cx + " 128 " + (cx + 70) + " 150 L" + (cx + 60) + " 330 L" + (cx - 60) + " 330 Z", C.az, 3, { f: C.az, op: 0.35 });
    s += lin(cx - 40, 330, cx - 50, 420, C.az, 12) + lin(cx + 40, 330, cx + 50, 420, C.az, 12);
    // braços à frente (animação leve da mão direita)
    s += cam("M" + (cx - 66) + " 160 Q" + (cx - 120) + " 210 " + (cx - 90) + " 240", C.pele, 10) + circ(cx - 90, 244, 10, { f: C.pele });
    s += '<g>' + cam("M" + (cx + 66) + " 160 Q" + (cx + 120) + " 210 " + (cx + 92) + " 240", C.pele, 10) + circ(cx + 92, 244, 10, { f: C.pele }) + '<animateTransform attributeName="transform" type="translate" values="0 -30;0 30;0 -30" dur="1.6s" repeatCount="indefinite"/></g>';
    const d = [["Pés", "afastados na largura dos ombros"], ["Joelhos", "soltos, nunca travados"], ["Ombros", "baixos e relaxados"], ["Cotovelos", "afastados do corpo, à frente"], ["Gesto", "da cintura à altura dos ombros"], ["Olhar", "no coro; partitura só de relance"]];
    d.forEach(([t, x], i) => (s += circ(470, 100 + i * 52, 8, { f: R }) + tx(488, 106 + i * 52, t + ": ", { t: 17, w: 800, c: R }) + tx(488 + t.length * 10 + 16, 106 + i * 52, x, { t: 15.5 })));
    s += tx(600, 425, "Tensão no regente vira tensão no grupo.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Regente em pé com o plano de regência à frente do corpo e lista de postura", s);
  };

  F.r3_ictus = () => {
    let s = tx(400, 38, "O ictus: o ponto exato do tempo", { t: 25, a: "middle", w: 700 });
    s += lin(120, 330, 680, 330, C.am, 4) + tx(690, 336, "ictus", { t: 18, c: C.am, w: 800 });
    // bola quicando: rápida perto do ponto, lenta no alto
    s += '<circle cx="400" cy="120" r="22" fill="' + R + '"><animate attributeName="cy" values="120;308;120" keyTimes="0;0.5;1" calcMode="spline" keySplines="0.55 0 1 0.45;0 0.55 0.45 1" dur="1s" repeatCount="indefinite"/></circle>';
    s += '<ellipse cx="400" cy="334" rx="40" ry="6" fill="' + C.am + '" fill-opacity="0.4">' + anim("rx", "10;44;10", 1) + "</ellipse>";
    s += tx(140, 140, ["A mão cai como uma", "bola: acelera e", "\"quica\" no ponto."], { t: 16, c: C.txt });
    s += tx(560, 140, ["Depois do ponto, o", "rebote sobe e prepara", "o próximo tempo."], { t: 16, c: C.txt });
    s += tx(400, 380, "Um ictus claro = todos cantam e tocam no mesmo instante.", { t: 17, a: "middle", w: 700 });
    s += tx(400, 412, "Gesto sem ponto (\"mão de massa\") deixa o grupo inseguro e atrasado.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Animação de uma bola quicando que mostra o ictus, o ponto do tempo no gesto de regência", s);
  };

  tabela("r3_maos", "Funções da mão direita e da mão esquerda", "Mão direita e mão esquerda", [{ t: "", w: 0.9 }, { t: "Mão direita", w: 2 }, { t: "Mão esquerda", w: 2 }], [
    ["Função", "Tempo, andamento e compasso", "Entradas, dinâmica e expressão"], ["Quando", "Sempre, do começo ao fim", "Só quando tem algo a dizer"], ["Exemplo", "Desenho do 4/4 constante", "Palma para cima = cresce; para baixo = suaviza"],
    ["Cuidado", "Não parar nem mudar o tamanho sem motivo", "Não imitar a direita o tempo todo (\"espelho\")"], ["Corte", "Fecha o desenho no tempo combinado", "Pode fechar junto para reforçar"]], R, "Treine diante do espelho: uma mão marca, a outra pede.");

  // ---------- padrões animados: a bolinha percorre o desenho; o número acende no tempo
  function padraoAnimado(n, bpmPadrao, cor, dicas, nome) {
    return (op) => {   // op (opcional, vindo do metrônomo): {bpm, dur} para o desenho andar junto com o som
      const bpm = (op && op.bpm) || bpmPadrao;
      const cx = 250, cy = 230, P = {
        2: { pts: [[cx - 10, cy + 110], [cx + 50, cy + 60]], ctl: [[cx + 90, cy - 70], [cx + 10, cy - 250]] },
        3: { pts: [[cx, cy + 110], [cx + 140, cy + 80], [cx + 70, cy - 10]], ctl: [[cx + 40, cy + 10], [cx + 170, cy - 30], [cx + 20, cy - 250]] },
        4: { pts: [[cx, cy + 110], [cx - 130, cy + 70], [cx + 140, cy + 75], [cx + 50, cy + 5]], ctl: [[cx - 40, cy - 10], [cx, cy + 20], [cx + 170, cy - 10], [cx + 10, cy - 260]] },
      }[n];
      const q = (a, k, b, t) => [(1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * k[0] + t * t * b[0], (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * k[1] + t * t * b[1]];
      let d = "M" + P.pts[0][0] + " " + P.pts[0][1], comp = [0];
      for (let i = 0; i < n; i++) {
        const a = P.pts[i], b = P.pts[(i + 1) % n], k = P.ctl[i];
        d += " Q" + k[0] + " " + k[1] + " " + b[0] + " " + b[1];
        let L = 0, ant = a; for (let j = 1; j <= 40; j++) { const p = q(a, k, b, j / 40); L += Math.hypot(p[0] - ant[0], p[1] - ant[1]); ant = p; }
        comp.push(comp[i] + L);
      }
      const tot = comp[n], dur = (op && op.dur) ? Math.round(op.dur * 1000) / 1000 : r1(n * 60 / bpm);
      const kp = comp.map((c) => r1(c / tot * 1000) / 1000).join(";"), kt = comp.map((c, i) => r1(i / n * 1000) / 1000).join(";"), ks = Array(n).fill("0.1 0.5 0.9 0.5").join(";");
      let s = tx(400, 38, "Compasso " + ((op && op.nome) || nome) + " — veja o gesto se mover", { t: 24, a: "middle", w: 700 });
      s += '<path d="' + d + '" fill="none" stroke="' + cor + '" stroke-width="5" stroke-opacity="0.55" stroke-linecap="round"/>';
      P.pts.forEach((p, i) => {
        const t = i / n, kt2 = i === 0 ? "0;0.12;1" : "0;" + r1(t * 1000 - 1) / 1000 + ";" + t + ";" + r1(Math.min(0.999, t + 0.12) * 1000) / 1000 + ";1", vals = i === 0 ? "1;0.15;0.15" : "0.15;0.15;1;0.15;0.15";
        s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="22" fill="' + cor + '" fill-opacity="0.15" stroke="' + cor + '" stroke-width="3"><animate attributeName="fill-opacity" values="' + vals + '" keyTimes="' + kt2 + '" dur="' + dur + 's" repeatCount="indefinite"/></circle>' + tx(p[0], p[1] + 8, String(i + 1), { t: 22, a: "middle", w: 800 });
      });
      s += '<circle r="13" fill="#ffffff" stroke="' + cor + '" stroke-width="4"><animateMotion path="' + d + '" dur="' + dur + 's" repeatCount="indefinite" keyPoints="' + kp + '" keyTimes="' + kt + '" calcMode="spline" keySplines="' + ks + '"/></circle>';
      s += rect(470, 90, 300, 270, { rx: 16, f: cor, op: 0.1, s: cor, sw: 2 });
      dicas.forEach((t, i) => (s += tx(490, 126 + i * 42, t, { t: 16.5 })));
      s += tx(620, 392, "visto de frente, mão direita · " + bpm + " BPM", { t: 14, a: "middle", c: C.mudo });
      s += tx(250, 432, "a bolinha anda rápido no ponto e devagar no alto", { t: 14, a: "middle", c: C.mudo });
      return svg("Animação do padrão de regência de " + n + " tempos", s);
    };
  }
  F.r3_anim2 = padraoAnimado(2, 80, C.lar, ["1: cai firme para baixo", "2: rebote e sobe", "Marchas e músicas rápidas", "6/8 rápido também vai em 2", "Conte \"um, dois\" em voz alta"], "2/4");
  F.r3_anim3 = padraoAnimado(3, 80, C.ver, ["1: cai para baixo", "2: abre para a direita", "3: sobe e volta ao topo", "Valsas e hinos em 3/4", "Conte \"um, dois, três\""], "3/4");
  F.r3_anim4 = padraoAnimado(4, 72, C.az, ["1: cai (o mais forte)", "2: para dentro (esquerda)", "3: cruza para fora (direita)", "4: sobe e prepara o 1", "O mais usado no louvor"], "4/4");

  // gesto animado genérico: pts (pontos do tempo), ctl (curvas), rot (número escrito em cada ponto); todos no mesmo ciclo "dur"
  function gestoAnimado(pts, ctl, rot, cor, dur, raio) {
    const n = pts.length, q = (a, k, b, t) => [(1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * k[0] + t * t * b[0], (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * k[1] + t * t * b[1]];
    let d = "M" + pts[0][0] + " " + pts[0][1], comp = [0];
    for (let i = 0; i < n; i++) {
      const a = pts[i], b = pts[(i + 1) % n], k = ctl[i];
      d += " Q" + k[0] + " " + k[1] + " " + b[0] + " " + b[1];
      let L = 0, ant = a; for (let j = 1; j <= 40; j++) { const p = q(a, k, b, j / 40); L += Math.hypot(p[0] - ant[0], p[1] - ant[1]); ant = p; }
      comp.push(comp[i] + L);
    }
    const tot = comp[n], kp = comp.map((c) => r1(c / tot * 1000) / 1000).join(";"), kt = comp.map((c, i) => r1(i / n * 1000) / 1000).join(";"), ks = Array(n).fill("0.1 0.5 0.9 0.5").join(";");
    let s = '<path d="' + d + '" fill="none" stroke="' + cor + '" stroke-width="4" stroke-opacity="0.55" stroke-linecap="round"/>';
    pts.forEach((p, i) => {
      const t = i / n, larg = Math.min(0.12, 0.6 / n), kt2 = i === 0 ? "0;" + larg + ";1" : "0;" + r1(t * 1000 - 1) / 1000 + ";" + r1(t * 1000) / 1000 + ";" + r1(Math.min(0.999, t + larg) * 1000) / 1000 + ";1", vals = i === 0 ? "1;0.15;0.15" : "0.15;0.15;1;0.15;0.15";
      s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="' + raio + '" fill="' + cor + '" fill-opacity="0.15" stroke="' + cor + '" stroke-width="3"><animate attributeName="fill-opacity" values="' + vals + '" keyTimes="' + kt2 + '" dur="' + dur + 's" repeatCount="indefinite"/></circle>' + tx(p[0], p[1] + raio * 0.36, rot[i], { t: raio, a: "middle", w: 800 });
    });
    s += '<circle r="' + Math.round(raio * 0.6) + '" fill="#ffffff" stroke="' + cor + '" stroke-width="4"><animateMotion path="' + d + '" dur="' + dur + 's" repeatCount="indefinite" keyPoints="' + kp + '" keyTimes="' + kt + '" calcMode="spline" keySplines="' + ks + '"/></circle>';
    return s;
  }
  // linha "1 2 3 4 5 6": cada número acende na sua colcheia (fortes = os que o gesto marca)
  function contagem6(cx, y, cor, fortes, dur) {
    let s = "";
    for (let k = 0; k < 6; k++) {
      const x = cx - 125 + k * 50, t = k / 6, forte = fortes.includes(k);
      const kt = k === 0 ? "0;0.14;1" : "0;" + r1(t * 1000 - 1) / 1000 + ";" + r1(t * 1000) / 1000 + ";" + r1(Math.min(0.999, t + 0.14) * 1000) / 1000 + ";1", vals = k === 0 ? "1;0.3;0.3" : "0.3;0.3;1;0.3;0.3";
      s += '<text x="' + x + '" y="' + y + '" text-anchor="middle" font-size="' + (forte ? 30 : 22) + '" font-weight="800" fill="' + (forte ? cor : "#e8f4f8") + '" opacity="0.3"><animate attributeName="opacity" values="' + vals + '" keyTimes="' + kt + '" dur="' + dur + 's" repeatCount="indefinite"/>' + (k + 1) + "</text>";
    }
    return s;
  }
  F.r3_pad6 = (op) => {   // op (do metrônomo): {bpm, dur}; bpm = colcheias por minuto
    const bpm = (op && op.bpm) || 150, dur = (op && op.dur) ? Math.round(op.dur * 1000) / 1000 : r1(6 * 60 / bpm);
    let s = tx(400, 36, "Compasso 6/8: em 2 (rápido) ou em 6 (lento) — veja o gesto", { t: 23, a: "middle", w: 700 });
    s += rect(20, 56, 370, 362, { rx: 16, f: C.lar, op: 0.08, s: C.lar, sw: 2 }) + rect(410, 56, 370, 362, { rx: 16, f: C.rox, op: 0.08, s: C.rox, sw: 2 });
    s += tx(205, 86, "Rápido: rege em 2", { t: 20, a: "middle", w: 800, c: C.lar }) + tx(595, 86, "Lento: rege em 6", { t: 20, a: "middle", w: 800, c: C.rox });
    s += tx(205, 110, "1 gesto para cada 3 colcheias", { t: 14.5, a: "middle", c: C.mudo }) + tx(595, 110, "1 gesto para cada colcheia", { t: 14.5, a: "middle", c: C.mudo });
    // em 2: mesmo desenho do 2/4; o "2" do gesto cai na colcheia 4
    s += gestoAnimado([[190, 340], [255, 290]], [[300, 195], [205, -30]], ["1", "4"], C.lar, dur, 24);
    // em 6: 1 desce, 2 e 3 para dentro, 4 cruza para fora, 5 fora, 6 sobe
    s += gestoAnimado([[600, 342], [530, 317], [467, 286], [677, 325], [747, 294], [642, 247]],
      [[558, 279], [488, 275], [575, 425], [726, 272], [740, 223], [617, 13]], ["1", "2", "3", "4", "5", "6"], C.rox, dur, 17);
    s += contagem6(205, 402, C.lar, [0, 3], dur) + contagem6(595, 402, C.rox, [0, 1, 2, 3, 4, 5], dur);
    s += tx(400, 440, "Se contar 6 ficou corrido, passe para 2.  ·  " + bpm + " colcheias por minuto", { t: 15.5, a: "middle" });
    return svg("Animação do compasso 6/8 regido em 2 tempos e em 6 tempos, lado a lado", s);
  };

  // anacruse animada: ciclo de 8 tempos (2 compassos de 4/4). Tempo 1 do ciclo = clique forte do metrônomo.
  // 1-2: conta em silêncio · 3: preparação · 4: "A-" (anacruse) · 1: "LE-" (tempo forte) · 2: "lu-" · 3-4: "ia"
  F.r3_anacruse = (op) => {
    const bpm = (op && op.bpm) || 72, bt = 60 / bpm, dur = Math.round(bt * 8 * 1000) / 1000, N = 8;
    const kf = (v) => r1(v * 1000) / 1000;
    const disc = (k0, k1) => {   // visível só entre o tempo k0 e k1 do ciclo (troca seca)
      if (k0 <= 0) return 'values="1;0" keyTimes="0;' + kf(k1 / N) + '"';
      if (k1 >= N) return 'values="0;1" keyTimes="0;' + kf(k0 / N) + '"';
      return 'values="0;1;0" keyTimes="0;' + kf(k0 / N) + ";" + kf(k1 / N) + '"';
    };
    const pisca = (ks) => {   // acende forte no instante de cada tempo de ks e apaga aos poucos
      let v = ["0.15"], t = ["0"];
      ks.forEach((k) => { const a = k / N; if (a > 0) { v.push("0.15"); t.push(kf(a - 0.002)); } v.push("1"); t.push(kf(a)); v.push("0.15"); t.push(kf(Math.min(0.999, a + 0.06))); });
      v.push("0.15"); t.push("1"); return 'values="' + v.join(";") + '" keyTimes="' + t.join(";") + '"';
    };
    let s = tx(400, 36, "Anacruse: a música começa ANTES do tempo 1", { t: 24, a: "middle", w: 700 });
    // ---- esquerda: a mão regendo 4/4
    s += rect(20, 56, 320, 300, { rx: 16, f: R, op: 0.07, s: R, sw: 2 }) + tx(180, 82, "A mão do regente (4 tempos)", { t: 16, a: "middle", w: 700, c: R });
    const P = [[175, 327], [84, 299], [273, 302], [210, 254]], K = { "0": [147, 243], "1": [175, 264], "2": [294, 243], "3": [182, 68] };
    const ordem = [2, 3, 0, 1, 2, 3];   // começa parada no 3, passa 4, 1, 2, 3, 4
    const q = (a, k, b, t) => [(1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * k[0] + t * t * b[0], (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * k[1] + t * t * b[1]];
    let d = "M" + P[2][0] + " " + P[2][1], comp = [0];
    for (let i = 0; i < ordem.length - 1; i++) {
      const a = P[ordem[i]], b = P[ordem[i + 1]], k = K[ordem[i]];
      d += " Q" + k[0] + " " + k[1] + " " + b[0] + " " + b[1];
      let L = 0, ant = a; for (let j = 1; j <= 40; j++) { const p = q(a, k, b, j / 40); L += Math.hypot(p[0] - ant[0], p[1] - ant[1]); ant = p; }
      comp.push(comp[i] + L);
    }
    const tot = comp[comp.length - 1], kp = [0].concat(comp.map((c) => kf(c / tot)), [1]).join(";");
    const kt = ["0", kf(2 / N), kf(3 / N), kf(4 / N), kf(5 / N), kf(6 / N), kf(7 / N), "1"].join(";");
    const ks = ["0 0 1 1"].concat(Array(5).fill("0.1 0.5 0.9 0.5"), ["0 0 1 1"]).join(";");
    s += '<path d="M175 327 Q147 243 84 299 Q175 264 273 302 Q294 243 210 254 Q182 68 175 327" fill="none" stroke="' + R + '" stroke-width="4" stroke-opacity="0.45" stroke-linecap="round"/>';
    const quando = [[4], [5], [2, 6], [3, 7]], corP = [C.ver, R, C.verm, C.az];
    P.forEach((p, i) => (s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="20" fill="' + corP[i] + '" fill-opacity="0.15" stroke="' + corP[i] + '" stroke-width="3"><animate attributeName="fill-opacity" ' + pisca(quando[i]) + ' dur="' + dur + 's" repeatCount="indefinite"/></circle>' + tx(p[0], p[1] + 7, String(i + 1), { t: 20, a: "middle", w: 800 })));
    s += tx(300, 336, "prepara", { t: 13, a: "middle", c: C.verm, w: 700 }) + tx(250, 232, "\"A-\"", { t: 15, a: "middle", c: C.az, w: 700 });
    s += '<circle r="12" fill="#ffffff" stroke="' + R + '" stroke-width="4"><animateMotion path="' + d + '" dur="' + dur + 's" repeatCount="indefinite" keyPoints="' + kp + '" keyTimes="' + kt + '" calcMode="spline" keySplines="' + ks + '"/>'
      + '<animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;' + kf(7.5 / N) + ";" + kf(7.9 / N) + ";" + kf(7.98 / N) + ';1" dur="' + dur + 's" repeatCount="indefinite"/></circle>';
    // ---- direita: linha do tempo com 2 compassos
    s += tx(565, 82, "Contagem e letra", { t: 16, a: "middle", w: 700, c: C.mudo });
    const bx = (k) => 357 + k * 52 + (k >= 4 ? 14 : 0);
    const cel = [["1", "", C.mudo], ["2", "", C.mudo], ["3", "prepara", C.verm], ["4", "A-", C.az], ["1", "LE-", C.ver], ["2", "lu-", C.txt], ["3", "ia", C.txt], ["4", "~", C.txt]];
    cel.forEach(([n, l, c], k) => {
      const x = bx(k);
      const acende = k === 0 ? 'values="0.55;0.12" keyTimes="0;' + kf(1 / N) + '"' : 'values="0.12;0.55;0.12" keyTimes="0;' + kf(k / N) + ";" + kf((k + 1) / N) + '"';
      s += '<rect x="' + x + '" y="100" width="48" height="96" rx="9" fill="' + c + '" fill-opacity="0.12" stroke="' + c + '" stroke-width="2"><animate attributeName="fill-opacity" ' + acende + ' calcMode="discrete" dur="' + dur + 's" repeatCount="indefinite"/></rect>';
      s += tx(x + 24, 132, n, { t: k === 4 ? 26 : 22, a: "middle", w: 800, c: k === 4 ? C.ver : C.txt }) + (l ? tx(x + 24, 178, l, { t: l === "prepara" ? 11.5 : 19, a: "middle", w: 800, c }) : "");
    });
    s += lin(bx(4) - 9, 92, bx(4) - 9, 206, C.txt, 4) + tx(bx(4) - 9, 224, "barra do compasso", { t: 12, a: "middle", c: C.mudo });
    s += tx(bx(0) + 102, 246, "compasso de espera", { t: 13.5, a: "middle", c: C.mudo }) + tx(bx(4) + 102, 246, "compasso 1 da música", { t: 13.5, a: "middle", c: C.ver });
    s += '<path d="M' + (bx(3) + 24) + ' 262 Q' + (bx(3) + 50) + " 290 " + (bx(4) + 20) + ' 262" fill="none" stroke="' + C.az + '" stroke-width="2.5"/>' + tx(bx(3) + 40, 304, "o \"A\" fica ANTES da barra", { t: 14, a: "middle", c: C.az, w: 700 });
    s += '<line y1="94" y2="202" stroke="' + C.am + '" stroke-width="3"><animate attributeName="x1" values="' + bx(0) + ";" + (bx(7) + 48) + '" dur="' + dur + 's" repeatCount="indefinite"/><animate attributeName="x2" values="' + bx(0) + ";" + (bx(7) + 48) + '" dur="' + dur + 's" repeatCount="indefinite"/></line>';
    // ---- frase que muda a cada tempo
    const fr = [[0, 2, "1... 2... conte em silêncio, mão parada no alto", C.mudo], [2, 3, "3: PREPARAÇÃO — a mão se move e todos respiram", C.verm], [3, 4, "4: todos cantam \"A-\" — esta é a anacruse", C.az], [4, 5, "1: \"LE-\" cai no tempo forte (começo do compasso)", C.ver], [5, 8, "a música segue normalmente: \"lu - ia...\"", C.txt]];
    s += rect(20, 368, 760, 40, { rx: 10, f: C.bg2, op: 0.9 });
    fr.forEach(([a, b, t, c]) => (s += '<g opacity="' + (a === 0 ? 1 : 0) + '"><animate attributeName="opacity" ' + disc(a, b) + ' calcMode="discrete" dur="' + dur + 's" repeatCount="indefinite"/>' + tx(400, 395, t, { t: 18, a: "middle", w: 800, c }) + "</g>"));
    s += tx(400, 434, "Regra: a preparação é UM tempo antes da primeira nota. \"Parabéns pra você\" também começa assim (\"Pa-ra\" vem antes do \"BÉNS\").", { t: 13, a: "middle", c: C.mudo });
    return svg("Animação da anacruse: a mão do regente prepara no tempo 3, o coro canta A no tempo 4 e LE cai no tempo 1", s);
  };
  F.r3_anacruse_antigo = () => {
    let s = tx(400, 38, "Música que começa antes do tempo 1 (anacruse)", { t: 24, a: "middle", w: 700 });
    const X = 80, W = 640, y = 200;
    s += lin(X, y, X + W, y, C.linha, 2);
    const m = [[0, "4", "preparação", C.mudo], [0.33, "1", "", C.txt]];
    [0, 1, 2, 3, 4, 5, 6].forEach((i) => s += lin(X + i * W / 6, y - 10, X + i * W / 6, y + 10, C.linha, 2));
    s += tx(X + 0 * W / 6, y + 40, "3", { t: 20, a: "middle", c: C.mudo }) + tx(X + 1 * W / 6, y + 40, "4", { t: 20, a: "middle", c: R, w: 800 }) + tx(X + 2 * W / 6, y + 40, "1", { t: 24, a: "middle", w: 800 }) + tx(X + 3 * W / 6, y + 40, "2", { t: 20, a: "middle" });
    s += rect(X + 0.6 * W / 6, y - 70, W / 6 * 0.9, 46, { rx: 10, f: C.az, op: 0.2, s: C.az, sw: 2 }) + tx(X + 1.05 * W / 6, y - 40, "\"Vem,\"", { t: 18, a: "middle", w: 700 });
    s += rect(X + 1.6 * W / 6, y - 70, W / 6 * 2.2, 46, { rx: 10, f: C.ver, op: 0.2, s: C.ver, sw: 2 }) + tx(X + 2.7 * W / 6, y - 40, "\"está na hora...\"", { t: 18, a: "middle", w: 700 });
    s += seta(X + 0.1 * W / 6, y + 70, X + 0.9 * W / 6, y + 70, R, 3) + tx(X + 0.5 * W / 6, y + 96, "preparo no 3", { t: 14, a: "middle", c: R });
    s += tx(400, 330, "Se a música começa no tempo 4, a preparação é dada no tempo 3.", { t: 17, a: "middle", w: 700 });
    s += tx(400, 360, "Regra geral: a preparação é sempre UM tempo antes da primeira nota.", { t: 16, a: "middle" });
    s += tx(400, 400, "Não faça o compasso inteiro antes: confunde o grupo e alguém entra cedo.", { t: 15, a: "middle", c: C.mudo });
    return svg("Linha do tempo de uma música que começa no tempo 4, com a preparação no tempo 3", s);
  };

  F.r3_entrada = () => {
    let s = tx(400, 38, "Dar a entrada em 4 passos", { t: 26, a: "middle", w: 700 });
    const it = [["Olhar", "Olhe para quem vai entrar, um pouco antes.", C.az], ["Respirar", "Respire com o grupo, no andamento da música.", C.ver], ["Preparar", "Gesto preparatório um tempo antes.", C.am], ["Entrar", "Ictus claro: o som começa junto.", R]];
    it.forEach(([t, d, c], i) => {
      const x = 30 + i * 192;
      s += '<g>' + rect(x, 90, 172, 220, { rx: 16, f: c, op: 0.12, s: c, sw: 2.5 }) + '<rect x="' + x + '" y="90" width="172" height="220" rx="16" fill="' + c + '" fill-opacity="0">' + anim("fill-opacity", i === 0 ? "0.4;0;0;0;0.4" : i === 1 ? "0;0.4;0;0;0" : i === 2 ? "0;0;0.4;0;0" : "0;0;0;0.4;0", 4, ' keyTimes="0;0.25;0.5;0.75;1" calcMode="discrete"') + "</rect>";
      s += circ(x + 86, 140, 30, { f: c }) + tx(x + 86, 150, String(i + 1), { t: 28, a: "middle", w: 800, c: "#0b1820" }) + tx(x + 86, 205, t, { t: 22, a: "middle", w: 800, c }) + tx(x + 86, 236, quebra(d, 19), { t: 14.5, a: "middle" }) + "</g>";
      if (i < 3) s += seta(x + 174, 200, x + 190, 200, C.mudo, 3);
    });
    s += tx(400, 350, "Entrada de naipe: mão esquerda aberta, apontando com a palma, nunca com o dedo.", { t: 16, a: "middle" });
    s += tx(400, 380, "Solista: um aceno de cabeça e o olhar bastam.", { t: 16, a: "middle" });
    s += tx(400, 420, "O tamanho e a velocidade do preparo já dizem o andamento e o volume.", { t: 15, a: "middle", c: C.am, w: 700 });
    return svg("Quatro passos para dar a entrada: olhar, respirar, preparar e entrar", s);
  };

  F.r3_cortes = () => {
    let s = tx(400, 38, "Tipos de corte (terminar juntos)", { t: 25, a: "middle", w: 700 });
    s += caixa(30, 70, 236, 260, C.az, "Corte circular", ["Pequeno laço e", "fecha no ponto.", "Bom para finais", "suaves e legato."]);
    s += '<path d="M120 270 q40 -50 60 -10 q10 30 -30 20" fill="none" stroke="' + C.az + '" stroke-width="5" stroke-linecap="round" stroke-dasharray="200" stroke-dashoffset="200">' + anim("stroke-dashoffset", "200;0;0", 2) + "</path>";
    s += caixa(282, 70, 236, 260, C.am, "Corte em gancho", ["Mão sobe e cai", "num ponto seco.", "Bom para finais", "fortes e marcados."]);
    s += '<path d="M370 280 q30 -70 60 -20 l0 12" fill="none" stroke="' + C.am + '" stroke-width="5" stroke-linecap="round" stroke-dasharray="200" stroke-dashoffset="200">' + anim("stroke-dashoffset", "200;0;0", 2) + "</path>";
    s += caixa(534, 70, 236, 260, C.ver, "Mão que fecha", ["A mão aberta", "fecha devagar.", "Bom para notas", "longas e fermatas."]);
    s += '<circle cx="652" cy="270" r="26" fill="' + C.pele + '">' + anim("r", "26;26;10;10;26", 2) + "</circle>";
    s += tx(400, 362, "Todo corte tem preparo: o grupo precisa ver o corte chegando.", { t: 16, a: "middle", w: 700 });
    s += tx(400, 392, "Combine em qual tempo a nota acaba e onde vai o S ou o R final (no corte, todos juntos).", { t: 15.5, a: "middle" });
    s += tx(400, 424, "Depois do corte, mãos paradas: silêncio também é regido.", { t: 15, a: "middle", c: C.mudo });
    return svg("Três tipos de corte de regência: circular, em gancho e mão que fecha, com animação", s);
  };

  F.r3_fermata = () => {
    let s = tx(400, 38, "Fermata: segurar e soltar juntos", { t: 25, a: "middle", w: 700 });
    s += cam("M95 170 Q150 90 205 170", R, 9) + circ(150, 158, 12, { f: R }) + tx(150, 210, "fermata", { t: 16, a: "middle", c: C.mudo });
    const passos = [["1. Chegar", "Marque o tempo até a nota com fermata."], ["2. Segurar", "Pare a mão no alto, mas mantenha a energia (não abaixe)."], ["3. Dinâmica", "A esquerda pode pedir crescendo ou diminuendo."], ["4. Cortar ou seguir", "Corte claro; ou, se a música continua, o corte já é a preparação."]];
    passos.forEach(([t, d], i) => (s += rect(280, 70 + i * 78, 490, 66, { rx: 12, f: R, op: 0.1, s: R, sw: 2 }) + tx(300, 98 + i * 78, t, { t: 18, w: 800, c: R }) + tx(300, 122 + i * 78, d, { t: 14.5 })));
    s += tx(400, 420, "A fermata é do regente: ensaie quanto tempo segurar e como sair dela.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Passos para reger uma fermata", s);
  };

  F.r3_metronomo = () => {
    let s = tx(400, 38, "Controle do andamento", { t: 25, a: "middle", w: 700 });
    const cx = 190, cy = 340, bpm = 72, dur = r1(2 * 60 / bpm);
    s += '<path d="M120 360 L150 90 L230 90 L260 360 Z" fill="#12303d" stroke="' + C.linha + '" stroke-width="3"/>';
    s += '<g><line x1="' + cx + '" y1="' + cy + '" x2="' + cx + '" y2="110" stroke="' + R + '" stroke-width="5" stroke-linecap="round"/>' + rect(cx - 12, 170, 24, 22, { rx: 4, f: R }) +
      '<animateTransform attributeName="transform" type="rotate" values="-24 ' + cx + " " + cy + ";24 " + cx + " " + cy + ";-24 " + cx + " " + cy + '" keyTimes="0;0.5;1" calcMode="spline" keySplines="0.45 0 0.55 1;0.45 0 0.55 1" dur="' + dur + 's" repeatCount="indefinite"/></g>';
    s += tx(cx, 396, bpm + " BPM", { t: 22, a: "middle", w: 800, c: R });
    const d = [["Comece no BPM combinado", "Ouça o metrônomo antes, cante a frase por dentro, e só então prepare."], ["Não corra no forte", "Crescendo e refrão animado tendem a acelerar."], ["Não arraste no suave", "Partes suaves tendem a atrasar: mantenha o pulso."], ["Banda com click", "Se há click, o regente segue o click, não o contrário."], ["Treine sozinho", "Reja com o metrônomo do celular por 5 minutos."]];
    d.forEach(([t, x], i) => (s += tx(320, 92 + i * 66, t, { t: 18, w: 800, c: R }) + tx(320, 116 + i * 66, x, { t: 14.5 })));
    return svg("Metrônomo animado e dicas para manter o andamento", s);
  };

  tabela("r3_andamento_mud", "Mudanças de andamento e como reger", "Mudar o andamento com segurança", [{ t: "Termo", w: 1.1 }, { t: "O que é", w: 1.5 }, { t: "Como reger", w: 2.2 }], [
    ["Ritardando (rit.)", "vai ficando mais lento", "Gestos um pouco maiores e mais pesados, aos poucos"], ["Accelerando (accel.)", "vai ficando mais rápido", "Gestos menores e mais leves, aos poucos"], ["A tempo", "volta ao andamento", "Um tempo de preparação já no andamento antigo"],
    ["Rubato", "flexível, \"respirando\"", "Só com o grupo bem ensaiado; olhar constante"], ["Final lento", "último verso mais largo", "Avise no ensaio; desenhe maior e olhe para todos"]], R, "Mudança de andamento sempre ensaiada. Surpresa no culto quebra o grupo.");

  F.r3_dinamica = () => {
    let s = tx(400, 38, "Dinâmica: o tamanho do gesto é o volume", { t: 24, a: "middle", w: 700 });
    const n = [["pp", 30, C.az], ["p", 50, C.az], ["mf", 80, C.ver], ["f", 115, C.am], ["ff", 150, C.verm]];
    n.forEach(([t, r, c], i) => {
      const x = 90 + i * 155, y = 210;
      s += '<path d="M' + x + " " + (y - r) + " L" + x + " " + (y + r * 0.8) + '" stroke="' + c + '" stroke-width="4" stroke-linecap="round"/>';
      s += '<circle cx="' + x + '" cy="' + (y - r) + '" r="9" fill="' + c + '">' + '<animate attributeName="cy" values="' + (y - r) + ";" + (y + r * 0.8) + ";" + (y - r) + '" dur="1s" repeatCount="indefinite"/></circle>';
      s += tx(x, 360, t, { t: 32, a: "middle", w: 800, i: true, c });
    });
    s += tx(400, 395, "Pequeno e perto do corpo = suave · grande e aberto = forte", { t: 17, a: "middle", w: 700 });
    s += tx(400, 425, "Mão esquerda: palma para cima pede mais; palma para baixo pede menos.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Gestos de tamanhos diferentes para pianissimo, piano, mezzo forte, forte e fortissimo", s);
  };

  cartoes("r3_articulacao_antigo", "Articulação e caráter no gesto", "Caráter da música no gesto", [
    ["Legato (ligado)", "Gesto contínuo e redondo, sem paradas bruscas."], ["Staccato (curto)", "Gesto pequeno e seco, ponto bem marcado."], ["Acento", "Um ictus mais forte só naquele tempo."],
    ["Marcato (marcado)", "Todos os tempos firmes, como marcha."], ["Alegre × solene", "Rosto, postura e energia mudam junto com o gesto."]], R, "O grupo canta como você rege: gesto pesado, som pesado.");

  cartoes("r3_sinais_antigo", "Sinais combinados para usar durante a música", "Comunicar sem parar a música", [
    ["Repetir", "Dedo indicador girando no alto."], ["Voltar ao refrão", "Mão em \"C\" ou sinal combinado no ensaio."], ["Última vez / final", "Punho fechado no alto."],
    ["Mais / menos volume", "Palma para cima ou para baixo."], ["Só voz (banda para)", "Mão espalmada para a banda."], ["Atenção", "Olhar firme e mão aberta parada."]], R, "Combine os sinais no ensaio e use sempre os mesmos.");

  // ---------- caráter animado: a "mão" (bolinha) bate 4 tempos na linha do ictus; embaixo, como o som sai
  const kf3 = (v) => r1(v * 1000) / 1000;
  const flash = (t0, dur, base, alto) => {   // acende no instante t0 (0..1 do ciclo) e apaga aos poucos
    const v = t0 <= 0 ? [alto, base, base] : [base, base, alto, base, base], t = t0 <= 0 ? ["0", "0.12", "1"] : ["0", kf3(t0 - 0.002), kf3(t0), kf3(Math.min(0.999, t0 + 0.12)), "1"];
    return '<animate attributeName="opacity" values="' + v.join(";") + '" keyTimes="' + t.join(";") + '" dur="' + dur + 's" repeatCount="indefinite"/>';
  };
  function painelCarater(x, y, nome, desc, cor, tipo, dur) {
    const X0 = x + 40, Wd = 290, base = y + 128;
    // cada tempo: lista de [fração do tempo, altura] e as curvas entre eles
    const forma = (k) => ({
      legato: [[[0.5, -34], [1, 0]], ["0.4 0 0.6 1", "0.4 0 0.6 1"]],
      staccato: [[[0.16, -30], [0.84, -30], [1, 0]], ["0 0.7 0.3 1", "0 0 1 1", "0.7 0 1 0.3"]],
      marcato: [[[0.5, -56], [1, 0]], ["0 0.55 0.45 1", "0.55 0 1 0.45"]],
      acento: [[[0.5, k === 1 ? -72 : -26], [1, 0]], ["0 0.55 0.45 1", "0.55 0 1 0.45"]],
    })[tipo];
    let vals = [base], kts = ["0"], spl = [];
    for (let k = 0; k < 4; k++) { const [pts, sp] = forma(k); pts.forEach(([f, h]) => { vals.push(base + h); kts.push(kf3((k + f) / 4)); }); spl.push(...sp); }
    let s = rect(x, y, 370, 172, { rx: 14, f: cor, op: 0.08, s: cor, sw: 2 });
    s += tx(x + 16, y + 28, nome, { t: 20, w: 800, c: cor }) + tx(x + 16, y + 50, desc, { t: 14, c: C.mudo });
    s += lin(X0 - 14, base + 12, X0 + Wd + 14, base + 12, C.am, 3);
    // como o som sai (acende quando a mão bate)
    for (let k = 0; k < 4; k++) {
      const xs = X0 + k * Wd / 4, t0 = k / 4;
      if (tipo === "legato") { if (k === 0) s += '<rect x="' + (X0 - 8) + '" y="' + (y + 150) + '" width="' + (Wd - 90) + '" height="12" rx="6" fill="' + cor + '" opacity="0.8"/>'; }
      else if (tipo === "staccato") s += '<circle cx="' + xs + '" cy="' + (y + 156) + '" r="6" fill="' + cor + '" opacity="0.3">' + flash(t0, dur, 0.3, 1) + "</circle>";
      else { const g = tipo === "acento" && k === 2, hgt = g ? 20 : 12; s += '<rect x="' + (xs - 22) + '" y="' + (y + 162 - hgt) + '" width="44" height="' + hgt + '" rx="3" fill="' + cor + '" opacity="0.3">' + flash(t0, dur, 0.3, 1) + "</rect>"; if (g) s += tx(xs, y + 138, ">", { t: 22, a: "middle", w: 800, c: C.verm }); }
    }
    if (tipo === "legato") s += tx(X0 + Wd + 22, y + 161, "som ligado", { t: 12, a: "end", c: C.mudo });
    if (tipo === "acento") s += '<circle cx="' + (X0 + 2 * Wd / 4) + '" cy="' + (base + 12) + '" r="22" fill="none" stroke="' + C.verm + '" stroke-width="3" opacity="0">' + flash(0.5, dur, 0, 1) + "</circle>";
    s += '<circle r="11" fill="#ffffff" stroke="' + cor + '" stroke-width="4" cx="' + X0 + '" cy="' + base + '"><animate attributeName="cx" values="' + X0 + ";" + (X0 + Wd) + '" dur="' + dur + 's" repeatCount="indefinite"/>'
      + '<animate attributeName="cy" values="' + vals.join(";") + '" keyTimes="' + kts.join(";") + '" calcMode="spline" keySplines="' + spl.join(";") + '" dur="' + dur + 's" repeatCount="indefinite"/></circle>';
    return s;
  }
  F.r3_articulacao = (op) => {   // op (metrônomo): {bpm, dur}
    const bpm = (op && op.bpm) || 80, dur = (op && op.dur) ? Math.round(op.dur * 1000) / 1000 : r1(4 * 60 / bpm);
    let s = tx(400, 36, "Caráter da música no gesto — veja a mão e ouça o som", { t: 23, a: "middle", w: 700 });
    s += painelCarater(20, 52, "Legato (ligado)", "redondo e contínuo, sem parar", C.az, "legato", dur);
    s += painelCarater(410, 52, "Staccato (curto)", "pequeno, seco, para no ar", C.lar, "staccato", dur);
    s += painelCarater(20, 236, "Marcato (marcado)", "todos os tempos firmes, como marcha", C.ver, "marcato", dur);
    s += painelCarater(410, 236, "Acento", "só um tempo mais forte (aqui, o 3)", C.verm, "acento", dur);
    s += tx(400, 434, "Alegre × solene: rosto, postura e energia mudam junto. Gesto pesado = som pesado.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Animação de quatro jeitos de reger: legato, staccato, marcato e acento, com o som de cada um", s);
  };

  // ---------- sinais de comunicação: cada sinal com a mão desenhada e se mexendo
  F.r3_sinais = () => {
    const D = 4;   // ciclo de 4 s
    const em = (x, y, e, t, extra) => '<text x="' + x + '" y="' + y + '" text-anchor="middle" font-size="' + t + '" font-family="Segoe UI Emoji, Apple Color Emoji, Noto Color Emoji, sans-serif">' + (extra || "") + e + "</text>";
    const mov = (vals, kt) => '<animateTransform attributeName="transform" type="translate" values="' + vals + '"' + (kt ? ' keyTimes="' + kt + '"' : "") + ' dur="' + D + 's" repeatCount="indefinite"/>';
    let s = tx(400, 36, "Comunicar sem parar a música — os sinais da mão", { t: 23, a: "middle", w: 700 });
    const card = (i, x, y, nome, desc, corpo) => {
      let c = rect(x, y, 246, 176, { rx: 14, f: R, op: 0.08, s: R, sw: 2 }) + circ(x + 22, y + 24, 14, { f: R }) + tx(x + 22, y + 30, String(i), { t: 16, a: "middle", w: 800, c: "#0b1820" });
      c += tx(x + 44, y + 30, nome, { t: 17, w: 800, c: R }) + corpo + tx(x + 123, y + 164, desc, { t: 13.5, a: "middle", c: C.txt });
      return c;
    };
    const X = [20, 277, 534], Y = [52, 240];
    // 1 repetir: dedo girando em círculo, com seta circular
    s += card(1, X[0], Y[0], "Repetir", "indicador girando no alto", '<circle cx="143" cy="130" r="34" fill="none" stroke="' + C.am + '" stroke-width="3" stroke-dasharray="150 64"><animateTransform attributeName="transform" type="rotate" values="0 143 130;360 143 130" dur="1.6s" repeatCount="indefinite"/></circle>'
      + '<g><animateMotion path="M18 0 A18 18 0 0 1 -18 0 A18 18 0 0 1 18 0" dur="1.6s" repeatCount="indefinite"/>' + em(143, 145, "☝️", 44) + "</g>");
    // 2 voltar ao refrão: mão em "C" que balança para trás
    s += card(2, X[1], Y[0], "Voltar ao refrão", "mão em \"C\" (combinado)", '<g>' + mov("0 0;-16 0;0 0", "0;0.5;1") + '<path d="M' + (X[1] + 150) + " 104 A30 30 0 1 0 " + (X[1] + 150) + ' 158" fill="none" stroke="' + C.pele + '" stroke-width="16" stroke-linecap="round"/>' + tx(X[1] + 186, 140, "C", { t: 26, a: "middle", w: 800, c: C.am }) + "</g>"
      + tx(X[1] + 60, 140, "↩", { t: 34, a: "middle", c: C.am }));
    // 3 última vez: punho que sobe e fica no alto
    s += card(3, X[2], Y[0], "Última vez / final", "punho fechado no alto", '<g>' + mov("0 30;0 -6;0 -6;0 30", "0;0.25;0.85;1") + em(X[2] + 123, 140, "✊", 52) + "</g>" + tx(X[2] + 205, 130, "fim", { t: 16, a: "middle", w: 800, c: C.am }));
    // 4 volume: palma para cima sobe (+), palma para baixo desce (−)
    s += card(4, X[0], Y[1], "Mais / menos volume", "palma p/ cima sobe · p/ baixo desce", '<g opacity="1"><animate attributeName="opacity" values="1;0" keyTimes="0;0.5" calcMode="discrete" dur="' + D + 's" repeatCount="indefinite"/>' + '<g>' + mov("0 24;0 -16;0 -16", "0;0.4;1") + em(110, 352, "🫴", 50) + "</g>" + tx(190, 330, "+ mais", { t: 18, a: "middle", w: 800, c: C.ver }) + "</g>"
      + '<g opacity="0"><animate attributeName="opacity" values="0;1" keyTimes="0;0.5" calcMode="discrete" dur="' + D + 's" repeatCount="indefinite"/>' + '<g>' + mov("0 -16;0 -16;0 24", "0;0.5;0.9") + em(110, 352, "🫳", 50) + "</g>" + tx(190, 330, "− menos", { t: 18, a: "middle", w: 800, c: C.lar }) + "</g>");
    // 5 só voz: mão espalmada para a banda, que para
    s += card(5, X[1], Y[1], "Só voz (banda para)", "mão espalmada para a banda", '<g>' + mov("0 0;14 0;14 0;0 0", "0;0.2;0.8;1") + em(X[1] + 80, 340, "✋", 50) + "</g>"
      + '<g><animate attributeName="opacity" values="1;0.25;0.25;1" keyTimes="0;0.2;0.8;1" dur="' + D + 's" repeatCount="indefinite"/>' + em(X[1] + 180, 334, "🎸🥁", 30) + "</g>" + tx(X[1] + 180, 360, "param", { t: 13, a: "middle", c: C.mudo }));
    // 6 atenção: olhar firme e mão aberta parada
    s += card(6, X[2], Y[1], "Atenção", "olhar firme, mão aberta parada", em(X[2] + 85, 344, "👀", 44) + em(X[2] + 165, 346, "🖐️", 48)
      + '<circle cx="' + (X[2] + 165) + '" cy="330" r="38" fill="none" stroke="' + C.am + '" stroke-width="3"><animate attributeName="r" values="30;44;30" dur="2s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.9;0.1;0.9" dur="2s" repeatCount="indefinite"/></circle>');
    s += tx(400, 438, "Combine os sinais no ensaio e use sempre os mesmos. O olhar chega antes do gesto.", { t: 15.5, a: "middle", c: C.mudo });
    return svg("Seis sinais de mão do regente, desenhados e animados: repetir, refrão, final, volume, só voz e atenção", s);
  };

  tabela("r3_falar", "Como falar com o grupo no ensaio", "Falar pouco, mostrar muito", [{ t: "Em vez de...", w: 1 }, { t: "Diga ou faça...", w: 1.4 }], [
    ["\"Está horrível!\"", "\"Contraltos, compasso 12: vamos só vocês, devagar.\""], ["Explicar 5 minutos", "Cante o trecho do jeito certo e peça para repetirem."], ["Corrigir tudo de uma vez", "Uma correção por vez; repita até melhorar."],
    ["Falar por cima da banda", "Pare a música com o corte, depois fale."], ["Só apontar erros", "Elogie o que melhorou: o grupo aprende mais."]], R, "Regra de ouro: mais tempo cantando do que ouvindo o regente falar.");

  tabela("r3_naipes", "Naipes do coral e extensões aproximadas", "Classificar vozes e formar naipes", [{ t: "Naipe", w: 1 }, { t: "Extensão aproximada", w: 1.8 }, { t: "Dica", w: 1.8 }], [
    ["Soprano", "do Dó central até o Lá agudo", "geralmente faz a melodia"], ["Contralto", "do Fá abaixo do Dó central até o Ré", "harmonia por baixo da melodia"], ["Tenor", "do Dó grave até o Lá (oitava abaixo do soprano)", "falta tenor? use barítonos agudos"],
    ["Baixo", "do Mi grave até o Dó central", "base do acorde; sustenta a afinação"], ["Como testar", "escala no teclado, sem forçar", "ouça onde a voz fica confortável e bonita"]], R, "Classifique pela região confortável (tessitura), não pela nota mais alta que a pessoa alcança.");

  F.r3_palco = () => {
    let s = tx(400, 34, "Coral com banda: organização do palco", { t: 24, a: "middle", w: 700 });
    s += '<path d="M60 360 Q400 40 740 360 Z" fill="#12303d" fill-opacity="0.55" stroke="' + C.linha + '" stroke-width="2"/>';
    const b = (x, y, w, h, c, t) => rect(x, y, w, h, { rx: 10, f: c, op: 0.3, s: c, sw: 2 }) + tx(x + w / 2, y + h / 2 + 6, t, { t: 14.5, a: "middle", w: 700 });
    s += b(250, 110, 300, 40, C.rosa, "Coral: S  A  T  B (degraus)") + b(120, 210, 130, 44, C.rox, "Teclado / piano") + b(550, 210, 130, 44, C.lar, "Bateria e baixo") + b(300, 175, 200, 36, C.ver, "Violão e guitarra");
    s += circ(400, 300, 26, { f: R, op: 0.85 }) + tx(400, 306, "R", { t: 20, a: "middle", w: 800, c: "#0b1820" }) + tx(400, 344, "regente: todos o veem", { t: 14, a: "middle", c: R });
    s += b(330, 240, 140, 30, C.az, "retornos (caixas)");
    s += tx(400, 396, "PLATEIA / CONGREGAÇÃO", { t: 14, a: "middle", c: C.mudo });
    s += tx(400, 428, "Teste: cada cantor vê o regente? A banda vê o regente? O técnico sabe a ordem?", { t: 15.5, a: "middle" });
    return svg("Planta do palco com coral nos degraus, banda nos lados e regente no centro", s);
  };

  tabela("r3_ensaio_plano", "Plano de ensaio de coral de 90 minutos", "Planejar o ensaio do coral (90 minutos)", [{ t: "Tempo", w: 0.8 }, { t: "Atividade", w: 2.3 }, { t: "Objetivo", w: 1.5 }], [
    ["10 min", "Oração, avisos rápidos e aquecimento", "corpo e voz prontos"], ["10 min", "Afinação: acorde parado, escalas por naipe", "ouvido atento"], ["25 min", "Música nova: por naipe, devagar, depois juntos", "aprender notas"],
    ["10 min", "Intervalo curto com água", "descanso vocal"], ["25 min", "Repertório: polir dinâmica, entradas e cortes", "acabamento"], ["10 min", "Cantar algo inteiro e avaliar", "terminar bem"]], R, "Escreva o plano antes e chegue 15 minutos antes do grupo.");

  cartoes("r3_organizacao", "Organização do coral e do conjunto", "Organização do coral e conjunto", [
    ["Lista de presença", "Saber quem vem ajuda a planejar as vozes."], ["Líder de naipe", "Uma pessoa por naipe ajuda a ensinar e avisar."], ["Pasta e repertório", "Letra, partitura e cifra iguais para todos."],
    ["Áudio-guia por naipe", "Grave cada voz separada e envie para treinar em casa."], ["Escala e calendário", "Datas de ensaio e de apresentação com antecedência."], ["Combinado com o técnico", "Ordem, microfones e retornos definidos antes."]], R, "Organização libera o ensaio para fazer música.");

  // ================================================================ CONTEÚDO (telão) — dois temas novos
  // 15/11/2026 (Rinaldo): os temas que já existiam continuam e passam a ser a Etapa 1 do curso (quem já fez pode pular).
  if (typeof CONTEUDO !== "undefined") CONTEUDO.temas.forEach((t) => {
    if (["som", "tecnica", "canto", "musica", "musicos", "regencia"].includes(t.id) && !/^Etapa 1/.test(t.nome)) t.nome = "Etapa 1 · " + t.nome;
    // metrônomo também nos padrões da Etapa 1 (som e luzes; o desenho desses é parado)
    if (t.id === "regencia") t.slides.forEach((s) => { const m = { padrao2: [2, 80], padrao3: [3, 80], padrao4: [4, 72], andamentos: [4, 100] }[s.id]; if (m && !s.metronomo) s.metronomo = { tempos: m[0], bpm: m[1] }; });
  });
  if (typeof CONTEUDO !== "undefined" && !CONTEUDO.temas.some((t) => t.id === "etapa2")) {
    CONTEUDO.temas.push({
      id: "etapa2", nome: "Etapa 2 · Técnicas vocais", publico: "Cantores, ministros de louvor e backing vocal", cor: V,
      resumo: "Aparelho vocal, respiração e apoio, aquecimento, afinação, projeção e ressonância, dicção, interpretação, registros, saúde vocal e técnicas para ministros de louvor. Cada assunto tem exercício prático no roteiro do professor.",
      slides: [
        { id: "v2-mapa", titulo: "O que vamos aprender", fig: "v2_mapa", pontos: ["Oito assuntos: **respiração**, **aquecimento**, **afinação**, **projeção**, **dicção**, **interpretação**, **saúde** e **ministério**.", "Cada assunto tem explicação, figura e **exercício na hora**.", "Venha com roupa confortável e uma garrafa de água."], fala: "Pergunte quem já canta e há quanto tempo. Ajuda a dosar o nível." },
        { id: "v2-aparelho", titulo: "Como a voz é produzida", fig: "v2_aparelho", pontos: ["**Motor**: pulmões e diafragma empurram o ar.", "**Vibrador**: as pregas vocais vibram com esse ar.", "**Ressoadores**: garganta, boca e nariz ampliam e dão cor.", "**Articuladores**: língua, lábios e dentes formam as palavras."], fala: "Mostre que cantar bem é fazer as 4 partes trabalharem juntas." },
        { id: "v2-diafragma", titulo: "Respiração diafragmática", fig: "v2_diafragma", pontos: ["Ao inspirar, o **diafragma desce**: a barriga e as costelas se abrem.", "Os **ombros não sobem**; o peito não estufa.", "Ar pelo nariz quando der tempo; pela boca nas pausas curtas."], fala: "Deixe a animação rodando e faça a turma respirar junto com ela." },
        { id: "v2-apoio", titulo: "Apoio: controlar a saída do ar", fig: "v2_apoio", vocal: "respiracao", pontos: ["Apoio é **soltar o ar devagar e constante**, mantendo as costelas abertas.", "Sem apoio, o ar acaba no começo da frase e a voz cai no fim.", "Teste do \"ssss\": meta de **20 a 30 segundos** com som igual."] },
        { id: "v2-exerc-resp", titulo: "Exercícios de respiração", fig: "v2_exerc_resp", vocal: "respiracao", pontos: ["Livro na barriga, contagem **4-4-8**, \"ssss\" contínuo e \"f-f-f\" em pulsos.", "Faça **5 minutos por dia**, não só no ensaio.", "Marque na letra **onde respirar**."] },
        { id: "v2-aquec", titulo: "Aquecimento vocal em 10 minutos", fig: "v2_aquec", vocal: "aquecimento", pontos: ["Corpo solto → respiração → vibração → canudo → ressonância → vogais.", "Comece **grave e suave**; suba aos poucos.", "Aquecer antes de cantar evita rouquidão e melhora a afinação."], fala: "Conduza o aquecimento inteiro com a turma em pé." },
        { id: "v2-sovt", titulo: "Canudo e vibração", fig: "v2_sovt", vocal: "aquecimento", pontos: ["Cantar no **canudo**, vibrar os **lábios** (brrr) ou a **língua** (trrr).", "A boca quase fechada ajuda as pregas a vibrar **com menos esforço**.", "2 a 3 minutos, **volume baixo**."], fala: "Leve canudos para distribuir. Copo com água deixa o exercício divertido." },
        { id: "v2-afinacao", titulo: "Afinação começa no ouvido", fig: "v2_afinacao", vocal: "afinacao", pontos: ["Afinar é **ouvir, imaginar a nota e corrigir** ouvindo o resultado.", "Desafinar é, quase sempre, falta de **escuta** ou de **apoio**.", "Retorno ruim também desafina: peça ao técnico para se ouvir."] },
        { id: "v2-afin-treino", titulo: "Treino de afinação", fig: "v2_afin_treino", vocal: "afinacao", pontos: ["Nota e eco, escala devagar, intervalos, acorde parado.", "**Grave e ouça**: o ouvido percebe mais de fora.", "Use o **Teste vocal** nas Ferramentas do AudioLab."], fala: "Abra Ferramentas › Teste vocal e mostre a nota de um aluno no telão." },
        { id: "v2-projecao", titulo: "Projetar não é gritar", fig: "v2_projecao", vocal: "vogais", pontos: ["Projeção = **ar com apoio + garganta aberta + ressonância**.", "Grito = força na garganta, voz dura e rouquidão.", "Com microfone, o volume é do técnico; a **qualidade** é do cantor."] },
        { id: "v2-ressoadores", titulo: "Ressonância: onde a voz soa", fig: "v2_ressoadores", vocal: "vogais", pontos: ["**Peito** nos graves, **boca** nas vogais, **máscara** na clareza, **cabeça** nos agudos.", "\"Hum\" e \"nhã\" levam a voz para a frente do rosto.", "Voz equilibrada usa todos os ressoadores."] },
        { id: "v2-articuladores", titulo: "Os articuladores", fig: "v2_articuladores", pontos: ["Lábios, língua, mandíbula, palato e dentes formam as palavras.", "**Mandíbula solta** e língua ágil = letra clara.", "Queixo travado e boca pouco aberta abafam a voz."] },
        { id: "v2-vogais", titulo: "Vogais abertas e puras", fig: "v2_vogais", vocal: "vogais", pontos: ["A vogal carrega a nota: **abra a boca** e mantenha o formato.", "Vogal pura: o \"Ê\" não vira \"Ei\" na nota longa.", "Em grupo, **todos fazem a mesma vogal**."] },
        { id: "v2-consoantes", titulo: "Consoantes: exercício da caneta", fig: "v2_caneta", pontos: ["Consoantes **rápidas e claras**; a vogal fica com o tempo da nota.", "**Caneta de lado** entre os dentes, ler 1 minuto, depois **sem** a caneta.", "Não aperte a caneta: ela só fica apoiada."] },
        { id: "v2-trava", titulo: "Trava-línguas", fig: "v2_trava", pontos: ["**Devagar** primeiro, exagerando a boca; depois **rápido**.", "Cada trava-língua treina um som: **R**, **TR**, **NH**, **S**, **P**.", "S, R e T finais: **todos juntos** no corte."] },
        { id: "v2-interpretacao", titulo: "Interpretar é contar a mensagem", fig: "v2_interpretacao", pontos: ["Leia a letra como texto: **quem fala, para quem, o que pede**.", "Palavras-chave recebem mais apoio, não grito.", "Menos enfeite, mais mensagem."] },
        { id: "v2-frase", titulo: "A frase musical", fig: "v2_frase", pontos: ["Toda frase tem **começo, ápice e fim**.", "Respire **entre** as ideias, nunca no meio da palavra.", "Crescer até o ápice e voltar dá vida à frase."] },
        { id: "v2-registros", titulo: "Controle: registros da voz", fig: "v2_registros", vocal: "aquecimento", pontos: ["Voz de **peito** (graves), **mista** (ponte) e de **cabeça** (agudos).", "Na passagem a voz pode quebrar: treine **sirenes suaves**.", "Não puxe a voz de peito para o agudo com força."], avancado: true },
        { id: "v2-higiene", titulo: "Saúde vocal no dia a dia", fig: "v2_higiene", pontos: ["**Água** ao longo do dia e **pausas** de 10 minutos por hora de uso.", "Evite gritar, cochichar forçado e pigarrear.", "Sono, refluxo tratado e ar sem fumaça protegem a voz."] },
        { id: "v2-alerta", titulo: "Sinais de alerta", fig: "v2_alerta", pontos: ["Rouquidão por **mais de 2 semanas**: procure um otorrino.", "Voz **não deve doer**. Dor é sinal para parar.", "Fonoaudiólogo treina e trata a voz."], fala: "Não dê diagnóstico: oriente a procurar o profissional." },
        { id: "v2-ministro", titulo: "Técnicas para ministros de louvor", fig: "v2_ministro", pontos: ["Objetivo: **a igreja cantar junto**, não assistir.", "Preparo completo: oração, letra, tom e ordem combinados.", "Olhar para o povo, falas curtas e melodia simples."] },
        { id: "v2-tom", titulo: "O tom certo para a congregação", fig: "v2_tom", vocal: "afinacao", pontos: ["Melodia confortável: mais ou menos do **Lá grave ao Ré agudo** (mulheres).", "Homens cantam uma oitava abaixo.", "Escolha o tom **pela congregação**, não pelo solista."] },
        { id: "v2-backing", titulo: "Backing vocal e harmonia", fig: "v2_backing", vocal: "afinacao", pontos: ["Backing **sustenta**: fica abaixo do líder.", "Abra vozes começando pela **terça acima**.", "Mesma vogal, mesma respiração, mesmo corte."] },
        { id: "v2-ensaio", titulo: "Ensaio do ministério", fig: "v2_ensaio", pontos: ["Oração e aquecimento → afinação → músicas novas → repertório → avaliação.", "Músicas novas **por partes** e vozes separadas.", "Grave o ensaio para cada um treinar em casa."] },
      ],
    });
    CONTEUDO.temas.push({
      id: "etapa3", nome: "Etapa 3 · Técnicas de regência", publico: "Regentes, líderes de louvor e de coral", cor: R,
      resumo: "Papel do regente, estudo da música, postura, ictus, mãos, padrões de 2, 3, 4 e 6 tempos (animados), anacruse, entradas, cortes, fermata, andamento, dinâmica, caráter, sinais, comunicação, naipes, palco e organização do coral e conjunto.",
      slides: [
        { id: "r3-mapa", titulo: "O que vamos aprender", fig: "r3_mapa", pontos: ["Papel do regente, **postura e gestos**, **compassos**, **entradas e cortes**.", "**Andamento**, **dinâmica**, **comunicação** e **organização**.", "Todo mundo vai reger: traga disposição para ficar em pé."] },
        { id: "r3-papel", titulo: "O papel do regente", fig: "r3_papel", pontos: ["Une o grupo em **um só tempo e uma só ideia**.", "Antes: estuda e planeja. No ensaio: ensina. Na apresentação: conduz.", "Também cuida das **pessoas** e combina com banda e técnico."] },
        { id: "r3-estudo", titulo: "Estudar a música antes", fig: "r3_estudo", pontos: ["Cante as vozes, marque a **forma**, as **respirações** e as **entradas**.", "Escreva a dinâmica e separe os **trechos difíceis**.", "Quem não sabe a música só acompanha; não rege."] },
        { id: "r3-postura", titulo: "Postura e plano de regência", fig: "r3_postura", pontos: ["Pés firmes, joelhos soltos, **ombros baixos**.", "Gesto **da cintura à altura dos ombros**, à frente do corpo.", "Olhar no grupo: partitura só de relance."] },
        { id: "r3-ictus", titulo: "O ictus: o ponto do tempo", fig: "r3_ictus", pontos: ["O **ictus** é o ponto exato onde o tempo acontece.", "A mão cai como uma bola, **quica** no ponto e sobe.", "Ictus claro = todos juntos. Gesto sem ponto = grupo inseguro."], fala: "Faça a turma quicar uma bola imaginária no tampo de uma mesa." },
        { id: "r3-maos", titulo: "Mão direita e mão esquerda", fig: "r3_maos", pontos: ["**Direita**: tempo, andamento e compasso, sempre.", "**Esquerda**: entradas, dinâmica e expressão, só quando necessário.", "Evite a esquerda imitando a direita o tempo todo."] },
        { id: "r3-anim2", titulo: "Compasso de 2 tempos", fig: "r3_anim2", metronomo: { tempos: 2, bpm: 80 }, pontos: ["1: **cai firme**; 2: rebote e **sobe**.", "Marchas, músicas rápidas e **6/8 rápido**.", "Reja contando em voz alta: \"um, dois\"."] },
        { id: "r3-anim3", titulo: "Compasso de 3 tempos", fig: "r3_anim3", metronomo: { tempos: 3, bpm: 80 }, pontos: ["1: cai; 2: **abre para a direita**; 3: sobe.", "Valsas e muitos hinos em 3/4.", "O tempo 1 é o mais marcado."] },
        { id: "r3-anim4", titulo: "Compasso de 4 tempos", fig: "r3_anim4", metronomo: { tempos: 4, bpm: 72 }, pontos: ["1: cai; 2: **para dentro**; 3: **cruza para fora**; 4: sobe.", "O compasso mais usado no louvor.", "Treine com metrônomo diante do espelho."] },
        { id: "r3-pad6", titulo: "Compasso 6/8: em 2 ou em 6", fig: "r3_pad6", metronomo: { tempos: 6, bpm: 150 }, pontos: ["**Rápido**: rege em 2 (cada tempo vale 3 colcheias).", "**Lento**: rege em 6 pontos.", "Se contar 6 ficou corrido, passe para 2."] },
        { id: "r3-anacruse", titulo: "Música que começa antes do 1", fig: "r3_anacruse", metronomo: { tempos: 4, bpm: 72 }, pontos: ["**Anacruse**: a música começa num tempo fraco (ex.: no 4).", "A preparação é **um tempo antes** da primeira nota.", "Não faça o compasso inteiro antes de começar."] },
        { id: "r3-entrada", titulo: "Entradas", fig: "r3_entrada", pontos: ["**Olhar → respirar → preparar → entrar**.", "Naipe: mão esquerda com a **palma**, nunca o dedo.", "O preparo já mostra o **andamento** e o **volume**."] },
        { id: "r3-cortes", titulo: "Cortes", fig: "r3_cortes", pontos: ["Circular (suave), em **gancho** (forte) ou **mão que fecha** (nota longa).", "Todo corte tem **preparo**: o grupo vê o corte chegando.", "S, R e T finais vão **no corte**, todos juntos."] },
        { id: "r3-fermata", titulo: "Fermata", fig: "r3_fermata", pontos: ["Chegar, **segurar com energia**, cortar ou seguir.", "A esquerda pode pedir crescendo durante a fermata.", "Ensaie quanto tempo segurar."] },
        { id: "r3-metronomo", titulo: "Controle do andamento", fig: "r3_metronomo", metronomo: { tempos: 4, bpm: 72 }, pontos: ["Comece no **BPM combinado**: ouça e cante por dentro antes.", "Cuidado: o forte tende a **correr**; o suave tende a **arrastar**.", "Com click, o regente segue o click."] },
        { id: "r3-andamento-mud", titulo: "Mudar o andamento", fig: "r3_andamento_mud", pontos: ["**Ritardando**: gesto maior e mais pesado. **Accelerando**: menor e mais leve.", "**A tempo**: um tempo de preparo no andamento antigo.", "Mudança de andamento sempre **ensaiada**."], avancado: true },
        { id: "r3-dinamica", titulo: "Dinâmica no gesto", fig: "r3_dinamica", pontos: ["Gesto **pequeno** = suave; gesto **grande** = forte.", "Palma para cima pede mais; **para baixo**, menos.", "Crescendo: o desenho cresce aos poucos, sem acelerar."] },
        { id: "r3-articulacao", titulo: "Caráter da música no gesto", fig: "r3_articulacao", metronomo: { tempos: 4, bpm: 80 }, pontos: ["**Legato**: redondo. **Staccato**: seco. **Marcato**: firme.", "Acento: um ictus mais forte só naquele tempo.", "Rosto e energia mudam junto com a música."] },
        { id: "r3-sinais", titulo: "Comunicar sem parar a música", fig: "r3_sinais", pontos: ["Sinais para **repetir**, **refrão**, **final**, **volume** e **só voz**.", "Combinados no ensaio, sempre os mesmos.", "O olhar chega antes do gesto."] },
        { id: "r3-falar", titulo: "Comunicação no ensaio", fig: "r3_falar", pontos: ["**Uma correção por vez**, objetiva: quem, onde, o quê.", "Mostre cantando em vez de explicar muito.", "Elogie o que melhorou."] },
        { id: "r3-naipes", titulo: "Naipes e classificação de vozes", fig: "r3_naipes", pontos: ["Soprano, contralto, tenor e baixo (**SATB**).", "Classifique pela região **confortável**, não pela nota mais alta.", "Faltou tenor? Barítonos agudos ajudam."] },
        { id: "r3-palco", titulo: "Coral com banda", fig: "r3_palco", pontos: ["Coral nos degraus, banda nos lados, **regente visível para todos**.", "Retornos para coral e banda.", "Técnico de som sabe a ordem e os microfones antes."] },
        { id: "r3-coral", titulo: "Disposição do coral", fig: "coral", pontos: ["**Em blocos**: cada naipe se escuta melhor (bom para aprender).", "**Misturado**: som mais unido (para grupos seguros).", "Teste no local e escolha o que soa melhor."] },
        { id: "r3-ensaio-plano", titulo: "Planejar o ensaio", fig: "r3_ensaio_plano", pontos: ["Aquecimento → afinação → música nova → intervalo → acabamento → música inteira.", "Plano escrito e chegada **15 minutos antes**.", "Termine com algo que o grupo faz bem."] },
        { id: "r3-organizacao", titulo: "Organização do coral e conjunto", fig: "r3_organizacao", pontos: ["Lista de presença, **líderes de naipe**, pasta e repertório.", "**Áudio-guia por naipe** para treinar em casa.", "Calendário e combinado com o técnico."] },
      ],
    });
  }

  // ================================================================ ROTEIRO DO PROFESSOR (só aparece no painel do professor)
  if (typeof EXPLICACOES_INICIANTES !== "undefined") Object.assign(EXPLICACOES_INICIANTES, {
    "v2-mapa": "Apresente a Etapa 2 como a parte prática do curso: na Etapa 1 a turma entendeu o som; agora vai usar o próprio corpo como instrumento. Combine que todos vão fazer os exercícios em pé, sem vergonha de errar. Peça que tragam água em todas as aulas.",
    "v2-aparelho": "A voz funciona como um instrumento de sopro com cordas: o ar dos pulmões (motor) passa pelas pregas vocais (vibrador), que vibram centenas de vezes por segundo; essa vibração ganha corpo na garganta, boca e nariz (ressoadores) e vira palavra com a língua, os lábios e os dentes (articuladores). Exemplo: ao sussurrar as pregas não vibram; ao falar normal, vibram. Peça que encostem a mão na garganta e alternem sussurro e fala para sentir a diferença.",
    "v2-diafragma": "O diafragma é um músculo em forma de cúpula logo abaixo dos pulmões. Quando ele desce, os pulmões ganham espaço e o ar entra; por isso a barriga vai para fora: os órgãos são empurrados para a frente. Exercício: mão na barriga e outra no peito; inspirar pelo nariz em 4 tempos fazendo só a mão da barriga se mexer. Erro comum: subir os ombros e estufar o peito, o que dá pouco ar e tensão no pescoço.",
    "v2-apoio": "Apoio (os italianos chamam de appoggio) é controlar a saída do ar: manter as costelas abertas por mais tempo e soltar o ar de forma constante, em vez de deixar tudo escapar no começo. Não é apertar a barriga nem empurrar. Exercício: inspirar e soltar em \"sssss\" contando os segundos; a meta inicial é 20 segundos com o som igual. Depois, cantar uma frase inteira de um louvor num só fôlego, sem a voz cair no fim.",
    "v2-exerc-resp": "Faça os seis exercícios com a turma, um minuto cada. Deitado com um livro na barriga é o mais fácil para quem nunca sentiu a respiração baixa. No \"f-f-f\" em pulsos a barriga deve dar pequenos impulsos, como uma risada curta. Termine pegando a letra de um louvor e marcando com um tracinho onde se respira: entre ideias, nunca no meio de uma palavra.",
    "v2-aquec": "Conduza o aquecimento completo com a turma: 10 minutos é o suficiente. Explique a ordem: primeiro soltar o corpo, depois o ar, depois a voz com pouco esforço (vibração e canudo), e só então vogais e música. Compare com um atleta: ninguém corre sem aquecer. Alerta: aquecimento não é cantar alto; se doer ou arranhar, pare e faça só respiração e vibração.",
    "v2-sovt": "Esses exercícios têm um nome técnico: exercícios de trato vocal semiocluído (boca quase fechada). A pequena contrapressão do ar ajuda as pregas vocais a vibrar com menos esforço; são usados por fonoaudiólogos no mundo todo, e as pesquisas mostram melhora imediata da voz, comparável a um bom aquecimento tradicional. Exercício: cantar \"Parabéns\" inteiro dentro do canudo; depois, sem canudo, notar como a voz sai mais fácil. Com o copo d'água, as bolhas devem ser pequenas e constantes.",
    "v2-afinacao": "Afinar é ouvir a nota, imaginar a nota antes de cantar e corrigir ouvindo o resultado. Por isso quem não se ouve (retorno ruim, banda alta) desafina mais. Muita gente acha que desafina por falta de dom, mas quase sempre é falta de treino de escuta ou de apoio: a voz cai no fim da frase quando o ar acaba. Demonstre cantando a mesma frase afinada e depois um pouco abaixo, e pergunte qual soou certo.",
    "v2-afin-treino": "Faça \"nota e eco\" no teclado: você toca, a turma canta; depois grupos de três notas. No acorde parado, a banda segura um acorde e cada naipe procura a sua nota até o som \"encaixar\" (o batimento some). Abra Ferramentas › Teste vocal e projete: a turma vê na hora se a nota está acima ou abaixo. Recomende gravar no celular e ouvir; de fora a pessoa percebe o que não percebe cantando.",
    "v2-projecao": "Projetar é fazer a voz chegar longe e clara usando ar com apoio, garganta aberta (sensação de bocejo) e ressonância na frente do rosto. Gritar é usar força da garganta: dá rouquidão e a voz fica dura. Exercício: chamar \"ei!\" como quem chama alguém do outro lado da rua, sentindo a barriga e não o pescoço. No templo com sistema de som, lembre: o microfone dá o volume; o cantor cuida da qualidade e da clareza.",
    "v2-ressoadores": "Ressoadores são os espaços onde a vibração das pregas vocais ganha corpo: peito, boca, nariz/maçãs do rosto (a \"máscara\") e cabeça. Exercício: \"hummm\" de boca fechada até sentir cócegas nos lábios e no nariz; depois abrir para \"mmmá\" mantendo a sensação na frente. Para os graves, a mão no peito sente a vibração; nos agudos, a vibração sobe para a cabeça.",
    "v2-articuladores": "Mostre cada articulador: lábios (P, B, M), ponta da língua (T, D, L, N), mandíbula (abre as vogais), palato mole (sobe no bocejo) e dentes (S, F). Exercício: mexer a mandíbula de lado a lado para soltar; língua para fora e para dentro; bocejar sentindo o céu da boca subir. Erro comum: cantar com o queixo travado e a boca quase fechada, o que abafa a voz e a letra.",
    "v2-vogais": "A vogal é a parte que segura a nota; a consoante é rápida. Mostre o formato de cada vogal e peça que a turma cante uma frase só com as vogais (\"Grande é o Senhor\" vira \"a-e-é-o-e-ô\"): a voz fica ligada e a afinação melhora. Vogal pura significa não mudar o formato no meio da nota longa. No coro e no backing, combinar a mesma vogal é o que faz várias vozes soarem como uma.",
    "v2-trava": "Deixe a frase de cima acender: primeiro devagar (a turma fala junto, exagerando a boca), depois rápido. Em seguida, cada um escolhe um dos quatro quadros e fala três vezes seguidas sem errar. Cada trava-língua treina um som: TR, R e NH, S e B, P. Se errar, volte a falar devagar. No canto, consoante rápida e clara, e o S, R e T do fim da palavra todos juntos no corte do regente.",
    "v2-consoantes": "Mostre a animação: 1) caneta atravessada entre os dentes, só apoiada, sem apertar; 2) ler a letra em voz alta por 1 minuto, exagerando o movimento da boca; 3) tirar a caneta e ler de novo, e a turma percebe que a fala ficou mais clara. Consoante bem feita é rápida, clara e não rouba o tempo da vogal. Exercício da caneta: ler a letra com uma caneta mordida de lado por 1 minuto e depois sem ela; a fala fica mais articulada. Use os trava-línguas devagar e depois rápido. Em grupo, combinar onde vai o S final (no corte do regente) evita aquele \"sssss\" espalhado.",
    "v2-interpretacao": "Interpretar é cantar o sentido, não só as notas. Leia a letra em voz alta como um texto e pergunte: quem está falando? Para quem? O que pede? Marque as palavras-chave; elas recebem mais apoio e um pouco mais de intensidade, nunca grito. Enfeites (melismas) em excesso escondem a letra e confundem a congregação que tenta cantar junto.",
    "v2-frase": "Toda frase musical caminha para um ponto principal (o ápice) e depois relaxa. Cante a frase do exemplo de três jeitos: reta, sem dinâmica; gritando tudo; e crescendo até a palavra principal e diminuindo. Pergunte qual comunicou melhor. Respirar no meio de uma palavra ou de uma ideia quebra o sentido: marque as respirações antes.",
    "v2-registros": "Aprofundamento. A voz tem regiões com sensações diferentes: a voz de peito (parecida com a fala), a voz de cabeça (leve, nos agudos) e a voz mista, que liga as duas. Na passagem a voz pode \"quebrar\"; isso é normal e se treina com sirenes suaves de canudo ou de lábios, do grave ao agudo, sem forçar. O erro mais comum é empurrar a voz de peito para o agudo com força, causa frequente de rouquidão em cantores de igreja.",
    "v2-higiene": "Percorra a tabela com exemplos do dia a dia. Água: goles pequenos ao longo do dia; a hidratação chega às pregas vocais com algumas horas de antecedência, por isso beber só na hora não basta. Descanso: dez minutos de silêncio a cada hora de uso intenso. Pigarrear machuca: troque por engolir saliva ou um gole de água. Cochichar forçado também cansa a voz. Refluxo e alergia sem tratamento causam pigarro e rouquidão.",
    "v2-alerta": "Seja claro: o professor não diagnostica. Rouquidão que dura mais de duas semanas precisa de avaliação de um otorrinolaringologista, principalmente se houver dor, dificuldade para engolir ou histórico de cigarro. O fonoaudiólogo trata e treina a voz. Voz não deve doer: dor é sinal para parar, não para \"aquecer mais\".",
    "v2-ministro": "O ministro de louvor tem uma função diferente do cantor de apresentação: o objetivo é que a igreja cante junto. Por isso: melodia simples e conhecida, tom confortável, olhar para o povo e falas curtas entre as músicas. Técnica e espiritualidade andam juntas: preparo espiritual não substitui ensaio, e ensaio não substitui preparo espiritual. Peça a cada aluno para conduzir um refrão olhando para a turma.",
    "v2-tom": "Mostre no teclado: para a congregação, a melodia fica confortável mais ou menos entre o Lá grave e o Ré agudo, na voz feminina; os homens cantam uma oitava abaixo. É uma referência usada por ministérios de louvor, não uma lei. Se a melodia passa muito do Ré agudo, a igreja para de cantar ou começa a gritar. O solista pode fazer uma voz diferente por cima, mas o tom é escolhido pela congregação.",
    "v2-backing": "O backing vocal sustenta o líder: fica um pouco abaixo no volume e não disputa a melodia. Para abrir vozes, comece pela terça acima da melodia e ensaie separado antes de juntar. Combinem a mesma vogal, a mesma respiração e o mesmo corte. Erro comum: três backings cantando a melodia igual ao solista; isso embola o som e não acrescenta nada.",
    "v2-ensaio": "Mostre que um ensaio de uma hora rende muito com plano. Músicas novas por partes, com cada voz separada, e só depois juntas. Repertório do culto inteiro, com as transições entre as músicas e com o técnico de som presente. Termine avaliando o que melhorou. Grave o ensaio e envie ao grupo para cada um treinar em casa.",
    "r3-mapa": "Apresente a Etapa 3: todo aluno vai reger, mesmo quem não pretende ser regente, porque entender o gesto ajuda o cantor e o músico a seguir o líder. Os padrões de compasso são animados no telão: a bolinha mostra o caminho da mão e o número acende no tempo certo.",
    "r3-papel": "O regente é o ponto de encontro do grupo: um só tempo, uma só ideia de música. O trabalho começa antes do ensaio (estudar, escolher tom, planejar), continua no ensaio (ensinar e corrigir) e termina na apresentação (conduzir). Também é líder de pessoas: motiva, resolve conflitos e forma novos líderes. Pergunte à turma qual regente marcou a vida deles e por quê.",
    "r3-estudo": "Mostre uma partitura ou letra marcada: forma (introdução, estrofe, refrão), respirações com apóstrofo, entradas circuladas, dinâmica escrita. Explique que o regente precisa saber cantar todas as vozes, pelo menos os trechos difíceis, para ensinar e corrigir. Exercício: dê uma letra de louvor e peça que cada aluno marque forma e respirações em 5 minutos.",
    "r3-postura": "Coloque a turma em pé: pés na largura dos ombros, joelhos soltos, ombros baixos, cotovelos um pouco afastados do corpo. O gesto acontece numa caixa imaginária à frente do corpo, entre a cintura e a altura dos ombros: o plano de regência. Gesto muito alto cansa e tira o grupo do controle; muito baixo, ninguém vê. Tensão no regente passa para o grupo.",
    "r3-ictus": "Ictus é o ponto exato do tempo no gesto. Imagine uma bola quicando numa mesa: ela acelera ao cair, toca a mesa (o ictus) e sobe mais devagar. A mão do regente faz o mesmo. Exercício: todos quicam uma bola imaginária em 60 BPM com o metrônomo; depois em 90. Gesto sem ponto, com a mão \"boiando\", deixa o grupo sem saber onde o tempo está.",
    "r3-maos": "A mão direita marca o tempo do começo ao fim. A esquerda é a mão da expressão: entrada de naipe, dinâmica, fermata, corte. Ela só entra quando tem algo a dizer; se ficar copiando a direita o tempo todo, perde a força. Exercício: direita marcando 4/4 e esquerda subindo devagar com a palma para cima (crescendo) e descendo com a palma para baixo.",
    "r3-anim2": "Deixe a animação rodando e peça à turma para acompanhar a bolinha com a mão direita, contando \"um, dois\". O tempo 1 cai firme; o 2 é o rebote que sobe e prepara o próximo 1. Lembre que o 6/8 rápido, muito comum no louvor, é regido em 2.",
    "r3-anim3": "Acompanhe a animação: 1 desce, 2 abre para a direita do regente, 3 sobe e volta ao topo. Use um hino em 3/4 conhecido da igreja e reja com a turma cantando. Atenção: o tempo 3 é o preparo do próximo 1, então ele precisa subir com clareza.",
    "r3-anim4": "É o padrão mais usado. Acompanhe a bolinha: 1 desce, 2 vai para dentro (para a esquerda do regente), 3 cruza para fora (para a direita), 4 sobe e prepara. Exercício em dupla: um rege, o outro canta um louvor em 4/4; depois trocam. Treinem em casa diante do espelho, com o metrônomo do celular.",
    "r3-pad6": "No 6/8 cada grupo de três colcheias forma um tempo: 1-2-3 | 4-5-6. Se a música é rápida (a maioria dos louvores com balanço), reja em 2: um gesto para cada grupo de três. Se é lenta e solene, reja os 6 pontos. Regra prática: se contar até 6 ficou corrido, passe para 2. O mesmo raciocínio vale para 4/4 muito rápido, que pode ser regido em 2. Toque o metrônomo: os dois desenhos andam juntos com o som, e os números 1 a 6 acendem em cada colcheia (no gesto em 2, a mão marca só o 1 e o 4).",
    "r3-anacruse": "Toque o metrônomo e deixe a animação rodar: no 1 e 2 a turma conta em silêncio, no 3 a mão prepara e todos respiram, no 4 cantam \"A-\" e o \"LE\" cai no tempo 1 (o clique forte). Faça a turma cantar junto várias vezes. Muitas músicas começam antes do tempo 1: é a anacruse. Exemplo: a primeira palavra cai no tempo 4. Nesse caso, a preparação é dada no tempo 3, só um tempo antes da primeira nota. Exercício: escolha um louvor que começa em anacruse e faça cada aluno dar a entrada. Erro comum: fazer o compasso inteiro antes, e metade do grupo entra cedo.",
    "r3-entrada": "Ensine a entrada em quatro passos: olhar para quem vai entrar um pouco antes; respirar junto, no andamento; fazer o gesto preparatório um tempo antes; e dar o ictus claro. Para um naipe, use a mão esquerda aberta, com a palma voltada para ele; apontar o dedo parece bronca. Para solista, o olhar e um aceno de cabeça bastam. Exercício: cada aluno dá a entrada do grupo em andamentos diferentes.",
    "r3-cortes": "Mostre os três cortes. Circular: um pequeno laço que fecha no ponto, para finais suaves. Em gancho: a mão sobe e cai num ponto seco, para finais fortes. Mão que fecha: devagar, para notas longas e fermatas. Todo corte tem preparo. Combine no ensaio em que tempo a nota acaba e que o S ou R final vai exatamente no corte. Depois do corte, mãos paradas: o silêncio também é regido.",
    "r3-fermata": "A fermata (o olho sobre a nota) significa segurar mais que o valor escrito. O regente chega marcando o tempo, para a mão no alto sem perder a energia e decide quanto tempo segurar. A esquerda pode pedir crescendo durante a nota. Para sair, ou corta, ou, se a música continua, o corte já funciona como preparação da próxima entrada. Ensaie as fermatas: elas são do regente.",
    "r3-metronomo": "Antes de começar, ouça o andamento (metrônomo ou o pensamento da música) e cante a primeira frase por dentro; só então prepare. O grupo tende a correr no forte e no refrão animado, e a arrastar nas partes suaves: o regente segura o pulso. Se a banda usa click, o regente segue o click. Exercício: rejam 2 minutos com o metrônomo; depois desliguem e confiram se o andamento se manteve.",
    "r3-andamento-mud": "Aprofundamento. Ritardando: os gestos ficam um pouco maiores e mais pesados, aos poucos. Accelerando: menores e mais leves. Para voltar ao andamento (a tempo), faça um tempo de preparo já no andamento antigo. Rubato só com grupo bem ensaiado e muito contato visual. Regra: mudança de andamento é sempre ensaiada; improvisar no culto quebra o grupo.",
    "r3-dinamica": "O tamanho do gesto é o volume: pequeno e perto do corpo pede suave; grande e aberto pede forte. A mão esquerda reforça: palma para cima pede mais; palma para baixo, menos. Exercício: a turma canta uma nota longa enquanto você cresce e diminui o gesto; eles devem seguir só o que veem. Atenção: crescendo não é acelerar; o desenho cresce, o andamento continua.",
    "r3-articulacao": "Toque o metrônomo: em cada quadro a bolinha é a mão batendo na linha amarela (o ictus), e embaixo acende como o som sai. Legato desliza sem parar (som ligado); staccato bate e para no ar (notas curtas); marcato bate firme em todos; acento bate mais forte só no 3. Peça para a turma imitar cada um com a mão. O jeito do gesto muda o jeito do som. Legato: gesto redondo e contínuo. Staccato: pequeno e seco. Marcato: todos os tempos firmes. Acento: um ictus mais forte só naquele tempo. Peça a um grupo que cante a mesma frase enquanto você rege de jeitos diferentes; eles vão perceber que mudam o som sem você dizer nada.",
    "r3-sinais": "Mostre cada desenho e faça o gesto junto com a turma: indicador girando (repetir), mão em C (refrão), punho no alto (final), palma para cima ou para baixo (volume), mão espalmada para a banda (só voz) e olhar firme com a mão parada (atenção). Combine sinais simples para usar sem parar a música: repetir, voltar ao refrão, última vez, mais ou menos volume, só voz. O importante é que sejam sempre os mesmos e combinados no ensaio, com o coral e com a banda. O olhar chega antes do gesto: olhe para quem precisa receber o sinal.",
    "r3-falar": "Mostre a tabela e dramatize os dois jeitos. Correção boa diz quem, onde e o quê: \"contraltos, compasso 12, a nota é mais alta\". Uma correção por vez; repita até melhorar. Sempre que puder, mostre cantando em vez de explicar. Elogie o que melhorou: o grupo aprende mais e volta motivado. Regra: o grupo deve passar mais tempo cantando do que ouvindo o regente falar.",
    "r3-naipes": "Explique os quatro naipes (SATB) e as extensões aproximadas. Para classificar, faça escalas no teclado sem forçar e observe onde a voz fica confortável e bonita (tessitura), não a nota mais alta que a pessoa alcança. Respeite: ninguém deve ser obrigado a cantar fora da sua região. Se faltar tenor, barítonos com agudo fácil ajudam; contraltos graves também podem reforçar em casos especiais.",
    "r3-palco": "Organize o palco a partir de uma pergunta: todos veem o regente? O coral nos degraus, a banda nos lados e o regente no centro, à frente. Retornos para coral e banda. Combine antes com o técnico a ordem das músicas, os microfones do coral e os retornos. Desenhe com a turma a planta do palco da igreja deles.",
    "r3-coral": "Mostre as duas formas. Em blocos (sopranos juntos, contraltos juntos...) cada naipe se escuta e aprende melhor; é a melhor para grupos em formação. Misturado (vozes intercaladas) dá um som mais unido, mas exige cantores seguros. Teste as duas no local da apresentação e escolha pelo som.",
    "r3-ensaio-plano": "Monte com a turma o plano de 90 minutos. Começar com aquecimento e afinação; música nova na hora em que o grupo está mais atento; intervalo curto com água; depois acabamento de dinâmica, entradas e cortes; e terminar cantando algo inteiro, de preferência algo que o grupo faz bem. Plano escrito e chegada 15 minutos antes evitam improviso.",
    "r3-organizacao": "Organização libera o ensaio para fazer música. Lista de presença ajuda a saber quais vozes estarão; líderes de naipe ajudam a ensinar e avisar; todos com a mesma letra, partitura e cifra; áudio-guia de cada voz gravado separado para treinar em casa; calendário com antecedência; e tudo combinado com o técnico de som. Termine pedindo que cada aluno escreva três melhorias para o grupo da sua igreja.",
  });
})(FIG);
