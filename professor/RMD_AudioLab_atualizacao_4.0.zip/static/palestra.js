/* RMD AudioLab — desenha um slide do conteúdo (usado na prévia do professor e no telão). */
"use strict";
const Palestra = (function () {
  const h = AL.h;
  const achar = (id) => CONTEUDO.temas.find((t) => t.id === id) || null;
  function textoRico(el, s) {   // **negrito** vira <b>; todo o resto entra como texto
    String(s).split(/(\*\*[^*]+\*\*)/).forEach((p) => { if (!p) return; if (p.startsWith("**")) el.append(h("b", {}, p.slice(2, -2))); else el.append(p); });
    return el;
  }
  function slide(tema, sl) {
    const fig = h("div", { class: "fig" });
    if (sl.img) fig.append(h("img", { src: sl.img, alt: sl.imgAlt || sl.titulo }));  // 21/11/2026: imagem pronta do sistema (boletim e certificado modelo)
    else fig.innerHTML = FIG.desenhar(sl.fig);   // desenhos do próprio sistema (figuras.js), nunca texto de usuário
    return h("div", { class: "slide" + (sl.img ? " doc" : ""), style: { "--cor": tema.cor } }, fig,
      h("div", { class: "txt" }, h("div", { class: "tema" }, tema.nome + (sl.avancado ? "  ·  ★ aprofundamento" : "")), h("h2", {}, sl.titulo), h("ul", {}, sl.pontos.map((p) => textoRico(h("li"), p)))));
  }
  const total = () => CONTEUDO.temas.reduce((s, t) => s + t.slides.length, 0);
  return { achar, slide, total, temas: () => CONTEUDO.temas };
})();
