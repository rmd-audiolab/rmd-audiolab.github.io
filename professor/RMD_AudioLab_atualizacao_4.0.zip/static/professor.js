/* RMD AudioLab — painel do professor */
"use strict";
(function () {
  const h = AL.h;
  let louvorEscolhido = ""; try { louvorEscolhido = sessionStorage.getItem("al_louvor") || ""; } catch (e) { /* ok */ }
  let E = null, info = {}, limites = null, exercicios = [], niveis = {}, secao = "aula", atual = null, falhasRede = 0;
  let ipQrSelecionado = "";
  // 22/11/2026: conta do professor deste computador (assuntos liberados pelo gestor; o gestor vê a Gestão de professores)
  let conta = { ligado: false, modulos: ["som", "voz", "regencia", "bateria", "musico"], todos: true, gestor: false };
  const pode = (assunto) => !conta.modulos || conta.modulos.includes(assunto);
  const ASSUNTOS = [["voz", "🎤 Canto (vozes)"], ["regencia", "🎼 Regência"], ["som", "🎚️ Operação de som"], ["bateria", "🥁 Bateria"], ["musico", "🎸 Músicos (violão, teclado, baixo)"]];
  // cada curso / tema de slides pertence a um ou mais assuntos (22/11/2026: o professor só vê os dele)
  const CURSO_ASSUNTO = { louvor: "voz", regencia: "regencia", som: "som", bateria: "bateria", musico: "musico" };
  const TEMA_ASSUNTOS = { tecnica: ["som", "voz", "musico"], canto: ["voz"], musica: ["voz", "musico"], musicos: ["musico", "bateria"], regencia: ["regencia"], etapa2: ["voz"], etapa3: ["regencia"] };
  const podeTema = (id) => !TEMA_ASSUNTOS[id] || TEMA_ASSUNTOS[id].some(pode);
  const nomeAssuntos = (ms) => ASSUNTOS.filter(([id]) => (ms || []).includes(id)).map(([, t]) => t).join(", ");
  const motor = new MotorAL();
  const audioArquivo = h("audio", { controls: true, style: { width: "100%" } });
  const cabeca = document.getElementById("cabeca"), app = document.getElementById("app"), avisos = document.getElementById("avisos");
  const selo = h("span", { class: "selo" }, "conectando…");

  // ---- som da aula no computador do professor (vale em QUALQUER tela; não muda ao trocar de menu)
  let demo = null;
  const somBtn = h("button", { class: "primario", onclick: () => alternarSom() }, "🔊 Ligar o som da aula");
  const normal = () => (limites ? Object.fromEntries(Object.entries(limites).map(([k, v]) => [k, v[2]])) : {});
  function alunoOuvido() { if (!E || !E.aula) return null; return E.alunos.find((x) => x.id === E.aula.selecionado) || E.alunos.find((x) => x.papel === "OPERADOR") || E.alunos[0] || null; }
  function mesaDoSom() { if (demo) return demo; const a = alunoOuvido(); return a ? a.controles : normal(); }
  function aplicarSom() { if (motor.ctx && E) motor.aplicar(mesaDoSom(), E.exercicio); rotuloSom(); }
  function rotuloSom() { const on = motor.ligado(); somBtn.textContent = on ? "🔊 Som da aula ligado (tocar para silenciar)" : motor.ctx ? "🔇 Som silenciado (tocar para ligar)" : "🔊 Ligar o som da aula"; somBtn.classList.toggle("ligado", on); }
  function alternarSom(forcar) {
    if (!motor.ctx) { motor.ligar(); motor.silenciar(false); audioArquivo.pause(); }
    else motor.silenciar(forcar === undefined ? !motor.mudo : !forcar);
    if (motor.ctx && motor.ctx.state === "suspended") motor.ctx.resume();
    aplicarSom();
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden && motor.ctx && motor.ctx.state === "suspended") motor.ctx.resume(); });

  async function acao(caminho, corpo, msg) {
    try { const r = await AL.api(caminho, corpo || {}); if (r.estado) E = r.estado; if (msg) AL.toast(msg); if (atual && atual.atualizar) atual.atualizar(E); return r; }
    catch (e) { AL.toast(e.message, true); if (e.status === 401) location.reload(); return null; }
  }
  const urlAluno = () => E && E.aula ? `http://${ipQrSelecionado || E.rede.ip}:${E.rede.porta}/aluno?sessao=${encodeURIComponent(E.aula.codigo)}` : "";

  // ------------------------------------------------------------------ entrada
  function telaLogin() {
    const senha = h("input", { type: "password", autocomplete: "current-password", required: true, "aria-label": "Senha do professor" });
    AL.limpar(app, h("div", { class: "cartao login" }, h("h2", {}, "Acesso do professor"),
      h("p", { class: "mudo" }, "Somente o professor controla a aula, as funções dos alunos e as notas."),
      h("form", { onsubmit: async (e) => { e.preventDefault(); try { await AL.api("/api/prof/entrar", { senha: senha.value }); iniciarPainel(); } catch (er) { AL.toast(er.message, true); senha.select(); } } },
        h("label", {}, "Senha"), senha, h("button", { class: "primario bloco", style: { "margin-top": "1rem" } }, "Entrar"))));
    senha.focus();
  }

  // ------------------------------------------------------------------ ativação e bloqueio (22/11/2026)
  function telaAtivacao() {
    const cod = h("input", { maxlength: 20, placeholder: "XXXX-XXXX-XXXX", "aria-label": "Código de ativação", style: { "text-transform": "uppercase", "letter-spacing": ".12em", "font-size": "1.3rem", "text-align": "center" } });
    const btn = h("button", { class: "primario bloco", style: { "margin-top": "1rem" } }, "Ativar");
    AL.limpar(app, h("div", { class: "cartao login" }, h("h2", {}, "🔑 Ativar o RMD AudioLab"),
      h("p", {}, "Digite o código de ativação que você recebeu do RMD AudioLab. Ele liga este computador à sua conta de professor."),
      h("form", { onsubmit: async (e) => { e.preventDefault(); btn.disabled = true;
        try { const r = await AL.api("/api/prof/ativar", { codigo: cod.value }); AL.toast("Pronto! AudioLab ativado para " + ((r.dados && r.dados.nome) || "o professor") + "."); setTimeout(() => location.reload(), 1200); }
        catch (er) { AL.toast(er.message, true); btn.disabled = false; cod.select(); } } },
        h("label", {}, "Código de ativação"), cod, btn),
      h("p", { class: "mudo", style: { "margin-top": "1rem" } }, "Precisa de internet só para ativar. O código só funciona uma vez e vale 30 dias. Não tem código? Fale com o responsável pelo RMD AudioLab.")));
    cod.focus();
  }
  function telaBloqueado() {
    AL.limpar(app, h("div", { class: "cartao login" }, h("h2", {}, "🔒 AudioLab bloqueado"),
      h("p", {}, "O acesso deste AudioLab está suspenso no momento. Fale com o responsável pelo RMD AudioLab para liberar."),
      h("p", { class: "mudo" }, "Seus alunos, notas e louvores continuam guardados neste computador. Nada foi apagado."),
      h("button", { class: "primario bloco", onclick: async () => { try { await AL.api("/api/prof/conta/atualizar", {}); } catch (e) { /* sem internet */ } location.reload(); } }, "Já liberaram? Conferir de novo")));
  }
  // aviso de versão nova (só no AudioLab instalado no computador de um professor)
  async function verificarAtualizacao() {
    let a; try { a = await AL.api("/api/prof/atualizacao"); } catch (e) { return; }
    if (!a || !a.pode || !a.nova) return;
    const faixa = h("div", { class: "aviso-topo", style: { display: "flex", gap: ".6rem", "align-items": "center", "flex-wrap": "wrap", "justify-content": "center" } },
      h("b", {}, "⬆️ Versão nova do AudioLab: " + a.nova), a.novidades ? h("span", {}, a.novidades) : null,
      h("button", { class: "primario", onclick: async (ev) => {
        if (!confirmar("Atualizar o AudioLab agora para a versão " + a.nova + "?\n\nLeva menos de 1 minuto. A tela fecha e abre de novo sozinha. Os seus alunos, notas e louvores ficam guardados.\n\nNão atualize no meio de uma aula.")) return;
        ev.target.disabled = true; ev.target.textContent = "Atualizando… não feche";
        try { await AL.api("/api/prof/atualizar", {}); AL.toast("Atualizado! O AudioLab vai abrir de novo em instantes."); }
        catch (e) { AL.toast(e.message, true); ev.target.disabled = false; ev.target.textContent = "Atualizar agora"; }
      } }, "Atualizar agora"));
    if (avisos) avisos.after(faixa); else app.prepend(faixa);
  }

  // ------------------------------------------------------------------ seções
  const SECOES = [
    ["AULA"], ["aula", "Aula atual"], ["alunos", "Alunos"], ["louvores", "Louvores da aula"], ["exercicios", "Exercícios"], ["acompanhar", "Acompanhar aluno"], ["turmas", "Aula com turmas (celular)"], ["chat", "Chat das turmas"], ["palestra", "Palestra e telão"],
    ["RESULTADOS"], ["resultados", "Resultados e histórico"], ["avaliacao", "Avaliação e certificados"], ["casa", "Treino em casa (celular)"],
    ["FERRAMENTAS"], ["ferramentas", "Sinais, EQ, analisador"], ["projecao", "Projeção (telão)"],
    ["SISTEMA"], ["config", "Configurações"],
  ];
  const SO_SOM = ["exercicios", "acompanhar", "ferramentas"];  // mesa de som, acompanhar a mesa do aluno, sinais/EQ/analisador
  function secoesVisiveis() {
    const lista = SECOES.filter(([id, nome]) => !nome || !SO_SOM.includes(id) || pode("som"));
    if (conta.gestor) lista.unshift(["GESTÃO"], ["gestao", "Gestão de professores"]);
    return lista.filter((x, i, l) => x[1] || (l[i + 1] && l[i + 1][1]));  // tira título de grupo que ficou vazio
  }

    // ------------------------------------------------------------------ Wi-Fi do próprio computador (Hotspot móvel do Windows)
  function qrWifi(ssid, senha) {
    const esc = (t) => String(t).replace(/([\\;,:"])/g, "\\$1");
    return "WIFI:T:WPA;S:" + esc(ssid) + ";P:" + esc(senha) + ";;";
  }
  function montarHotspot(aoMudar) {
    const estado = h("p", { class: "mudo" }, "Toque em “Verificar” para ver o Wi-Fi do computador."), qr = h("div", { class: "qr" }), dados = h("div");
    let ver = false, ultimo = null;
    const MSG = { sem_rede: "O Windows não deixou ligar o Wi-Fi do computador porque ele não está conectado a nenhuma rede. Conecte o computador a uma rede (mesmo sem internet) ou use o roteador/ponto de acesso Wi-Fi da igreja, ou o hotspot do celular do professor.", so_windows: "Isso só funciona no Windows." };
    function desenhar(r) {
      ultimo = r; AL.limpar(qr); AL.limpar(dados);
      if (!r || !r.ok && !r.ssid) { estado.textContent = (r && (MSG[r.erro] || r.erro)) || "Não consegui consultar o Wi-Fi do computador."; return; }
      if (!r.ligado) { estado.textContent = "Wi-Fi do computador desligado." + (r.erro ? " " + (MSG[r.erro] || r.erro) : ""); return; }
      estado.textContent = "Wi-Fi do computador LIGADO · " + (r.clientes || 0) + " aparelho(s) conectado(s)" + (r.max ? " de " + r.max : "") + ".";
      try {
        const q = qrcode(0, "M"); q.addData(qrWifi(r.ssid, r.senha)); q.make();
        AL.limpar(qr, new DOMParser().parseFromString(q.createSvgTag({ cellSize: 4, margin: 3 }), "image/svg+xml").documentElement);
      } catch (e) { /* sem QR */ }
      const senha = h("b", {}, ver ? r.senha : "••••••••");
      AL.limpar(dados, h("p", {}, "Rede: ", h("b", {}, r.ssid)), h("p", {}, "Senha: ", senha, " ", h("button", { onclick: () => { ver = !ver; desenhar(ultimo); } }, ver ? "Esconder" : "Mostrar")),
        h("p", { class: "mudo" }, "1) Os alunos leem este QR Code para entrar no Wi-Fi do computador. 2) Depois leem o QR Code da aula (ao lado) para abrir o AudioLab."));
    }
    async function chamar(acao, aviso) {
      estado.textContent = acao === "ligar" ? "Aguarde… o Windows vai pedir autorização na tela: toque em Sim." : "Aguarde…";
      const r = await acao_hotspot(acao);
      desenhar(r);
      if (r && r.ligado && acao === "ligar") { if (r.firewall === false) AL.toast("Wi-Fi ligado, mas o Windows não foi autorizado a liberar o AudioLab: os celulares podem não abrir a aula. Toque em Ligar de novo e autorize.", true); else AL.toast(aviso || "Wi-Fi do computador ligado."); aoMudar(); }
    }
    async function acao_hotspot(a) { const r = await acao("/api/prof/hotspot", { acao: a }); return r && r.dados ? r.dados : null; }
    chamar("estado");
    return h("div", { class: "cartao" }, h("h2", {}, "Wi-Fi do computador"),
      h("p", { class: "mudo" }, "Sem rede no local? Toque em Compartilhar: o Windows pede autorização, você toca em Sim e o computador cria o próprio Wi-Fi para os celulares entrarem."),
      estado, qr, dados,
      h("div", { class: "linha" }, h("button", { class: "primario", onclick: () => chamar("ligar") }, "Compartilhar Wi-Fi do computador"), h("button", { onclick: () => chamar("desligar") }, "Desligar"), h("button", { onclick: () => chamar("estado") }, "Verificar")));
  }

function blocoFirewall() {
    const msg = h("p", { class: "mudo" }, "Verificando se o Windows deixa os celulares entrarem…");
    const btn = h("button", { class: "primario", onclick: () => verificar("liberar") }, "Liberar para os celulares");
    btn.hidden = true;
    async function verificar(a) {
      if (a === "liberar") msg.textContent = "Aguarde… o Windows vai pedir autorização na tela do computador: toque em Sim.";
      const r = await acao("/api/prof/firewall", { acao: a });
      const d = r && r.dados;
      if (!d) { msg.textContent = "Não consegui verificar a liberação do Windows."; btn.hidden = false; return; }
      if (d.liberado) { msg.className = "ok"; msg.textContent = "✔ O Windows está liberado: os celulares da mesma rede Wi-Fi conseguem abrir a aula."; btn.hidden = true; }
      else { msg.className = "aviso"; msg.textContent = "⚠ O Windows pode estar bloqueando os celulares (é por isso que o QR Code não abre). Toque em “Liberar para os celulares” e, quando o Windows perguntar, toque em Sim." + (d.erro ? " (" + d.erro + ")" : ""); btn.hidden = false; }
    }
    verificar("estado");
    return h("div", { style: { "margin-top": ".6rem" } }, msg, btn);
  }

function secaoAula() {
    const el = h("div");
    const atualizar = () => {
      if (!E.aula) {
        const nome = h("input", { placeholder: "Ex.: Treinamento de mesa — turma de sábado", "aria-label": "Nome da aula" });
        AL.limpar(el, h("div", { class: "cartao" }, h("h2", {}, "Começar uma aula"), h("p", { class: "mudo" }, "Crie a sessão: o sistema gera o código e o QR Code para os alunos entrarem pelo celular."),
          h("label", {}, "Nome da aula"), nome, h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: () => acao("/api/prof/sessao", { nome: nome.value }, "Sessão criada.") }, "Criar sessão")));
        el._feito = false; return;
      }
      if (!el._feito) {
        const qr = h("div", { class: "qr" }), link = h("p", { style: { "word-break": "break-all" } });
        const ipSelect = h("select", { "aria-label": "Endereço de rede usado no QR Code", style: { width: "100%", "margin-bottom": ".5rem" } });
        const ex = h("div"), kpis = h("div", { class: "kpis" }), vivo = h("div");
        el._qr = qr; el._link = link; el._ipSelect = ipSelect; el._ex = ex; el._kpis = kpis; el._vivo = vivo; el._ipsSig = "";
        const hot = montarHotspot(() => { ipQrSelecionado = ""; el._ipsSig = ""; el._url = ""; setTimeout(() => { const x = E && E.rede && E.rede.ips && E.rede.ips.find((i) => /^192\.168\.137\./.test(i.ip)); if (x) { ipQrSelecionado = x.ip; el._ipsSig = ""; el._url = ""; atualizar(); } }, 6500); });
        ipSelect.onchange = () => { ipQrSelecionado = ipSelect.value; el._url = ""; atualizar(); };
        const nomeNova = h("input", { placeholder: "Ex.: Treinamento de mesa — turma de sábado", "aria-label": "Nome da nova aula" });
        const cartaoNova = h("div", { class: "cartao", style: { "margin-bottom": "1rem" } }, h("h2", {}, "Criar nova aula"),
          h("p", { class: "mudo" }, "Cria uma aula nova, com novo código e QR Code. Quem está na aula atual precisa entrar de novo."),
          h("label", {}, "Nome da aula"), nomeNova,
          h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: () => {
            if (E.alunos.length && !confirmar("Criar uma aula nova? Os " + E.alunos.length + " aluno(s) da aula atual precisarão entrar de novo.")) return;
            acao("/api/prof/sessao", { nome: nomeNova.value || E.aula.nome }, "Aula criada.");
          } }, "Criar nova aula"));
        AL.limpar(el, kpis, vivo, ex, cartaoNova,
          h("div", { class: "grade" },
            h("div", { class: "cartao" }, h("h2", {}, "Entrada dos alunos"),
              h("p", { class: "mudo" }, "Selecione a rede Wi-Fi à qual os celulares estarão conectados. O QR Code precisa usar o endereço dessa mesma rede."),
              ipSelect, qr, link, blocoFirewall(),
              h("div", { class: "linha" }, h("button", { onclick: async () => { try { await navigator.clipboard.writeText(urlAluno()); AL.toast("Endereço copiado."); } catch (e) { AL.toast("Selecione o endereço acima e copie.", true); } } }, "Copiar endereço"),
                h("button", { onclick: () => { if (confirmar("Começar uma sessão nova? Os alunos atuais precisarão entrar de novo.")) acao("/api/prof/sessao", { nome: E.aula.nome }, "Nova sessão criada."); } }, "Nova sessão"))),
            hot,
            h("div", { class: "cartao" }, h("h2", {}, "Atalhos"), h("div", { class: "linha" },
              h("button", { onclick: () => ir("exercicios") }, "Escolher exercício"), h("button", { onclick: () => ir("alunos") }, "Funções dos alunos"),
              h("button", { onclick: () => window.open("/projecao", "al_projecao", "width=1200,height=720") }, "Abrir projeção"),
              el._placar = h("button", { onclick: () => acao("/api/prof/placar", { ligado: !E.aula.placar }, E.aula.placar ? "Placar escondido do telão." : "Placar ligado no telão (só apelidos e notas).") }, "")))));
        el._feito = true; el._url = "";
      }
      const ips = E.rede.ips && E.rede.ips.length ? E.rede.ips : [{ ip: E.rede.ip, interface: "Endereço detectado" }];
      const ipsSig = JSON.stringify(ips);
      if (ipsSig !== el._ipsSig) {
        const anterior = ipQrSelecionado || E.rede.ip;
        AL.limpar(el._ipSelect, ips.map((x) => h("option", { value: x.ip }, x.ip + " — " + x.interface)));
        el._ipSelect.value = ips.some((x) => x.ip === anterior) ? anterior : (ips.some((x) => x.ip === E.rede.ip) ? E.rede.ip : ips[0].ip);
        ipQrSelecionado = el._ipSelect.value;
        el._ipsSig = ipsSig;
        el._url = "";
      }
      const url = urlAluno();
      if (url !== el._url) {
        const q = qrcode(0, "M"); q.addData(url); q.make();
        const svg = new DOMParser().parseFromString(q.createSvgTag({ cellSize: 5, margin: 3 }), "image/svg+xml").documentElement;
        AL.limpar(el._qr, svg); AL.limpar(el._link, h("b", {}, "Código: " + E.aula.codigo), h("br"), url); el._url = url;
      }
      el._placar.textContent = E.aula.placar ? "🏆 Esconder placar do telão" : "🏆 Mostrar placar no telão";
      el._placar.classList.toggle("ligado", !!E.aula.placar);
      const x = E.exercicio, on = E.alunos.filter((a) => a.online).length, ops = E.alunos.filter((a) => a.papel === "OPERADOR").length;
      AL.limpar(el._kpis,
        h("div", { class: "kpi" }, h("small", {}, "Aula"), h("b", {}, E.aula.nome)),
        h("div", { class: "kpi" }, h("small", {}, "Alunos conectados"), h("b", {}, on + " de " + E.alunos.length)),
        h("div", { class: "kpi" }, h("small", {}, "Operadores liberados"), h("b", {}, String(ops))),
        h("div", { class: "kpi" }, h("small", {}, "Tempo restante"), h("b", {}, x && x.status !== "FINALIZADO" ? AL.tempo(x.restante) : "—")));
      AL.limpar(el._vivo, h("div", { class: "cartao" }, h("h2", {}, "Ao vivo — o que cada aluno está fazendo"),
        E.alunos.length ? E.alunos.map((a) => {
          const c = a.controles || {}, v = a.vu || {};
          const barra = (rot, val) => h("div", { class: "ctl" }, h("div", { class: "rot" }, h("span", {}, rot)), h("div", { class: "vu", "aria-hidden": "true" }, h("i", { style: { width: Math.round(Math.min(1, Math.max(0, val || 0)) * 100) + "%" } })));
          return h("div", { class: "aluno" },
            h("div", {}, h("b", {}, a.apelido || a.nome), " ", h("span", { class: "selo " + (a.online ? "ok" : "") }, a.online ? "● online" : "○ fora"), " ", h("span", { class: "selo" }, a.papel),
              a.terminou ? h("span", { class: "ok" }, " ✔ entregou") : null,
              h("div", { class: "mudo" }, a.som ? "🔊 ouvindo a mesa no celular" : "🔇 sem som no celular",
                " · VOZ fader " + c.voz_fader + " dB · MÚSICA fader " + c.mus_fader + " dB · MASTER " + c.master + " dB"),
              barra("VOZ", v.voz), barra("MÚSICA", v.mus), barra("SAÍDA", v.master)),
            h("div", { class: "acoes" }, h("button", { onclick: () => { acao("/api/prof/selecionar", { aluno: a.id }); ir("acompanhar"); } }, "Acompanhar e ouvir")));
        }) : h("p", { class: "mudo" }, "Nenhum aluno entrou ainda.")));
      if (el._audio && document.activeElement === el._audio) return; // não fecha a lista enquanto o professor escolhe
      AL.limpar(el._ex, h("div", { class: "cartao" }, h("h2", {}, "Exercício"),
        x ? [h("p", {}, h("b", {}, x.nome), " · ", h("span", { class: "selo" }, "Nível " + x.nivel_nome), " · ", h("span", { class: x.status === "ATIVO" ? "ok" : "aviso" }, x.status),
            x.tipo === "microfonia" && x.nivel === "dificil" ? h("span", { class: "mudo" }, " · apito em " + x.apito_hz + " Hz (só você vê)") : null), h("p", { class: "mudo" }, x.publico), !x.louvor && x.status !== "FINALIZADO" ? h("p", { class: "aviso" }, "⚠ Nenhuma música escolhida: os alunos só ouvem o defeito do exercício. Escolha abaixo a música (envie em Louvores da aula).") : null, (() => {
            const sel = el._audio || (el._audio = seletorAudio("Áudio do exercício em andamento", async (v) => { guardarEscolha(v); await acao("/api/prof/audio", { louvor: v || null, modo: modoEscolhido }, v ? "Música trocada para a turma." : "Turma sem música (só o defeito)."); }));
            const bm = el._modo || (el._modo = blocoModo(async (m) => { await acao("/api/prof/audio", { louvor: sel.value || null, modo: m }, "Modo trocado para a turma."); }));
            bm.mostrar(!!(x.louvor && x.louvor.separado), x.louvor && x.louvor.modo);
            if (document.activeElement !== sel) sel.preencher(x.louvor ? x.louvor.id : "");
            return x.status === "FINALIZADO" ? (x.louvor ? h("p", {}, "🎵 Louvor: ", h("b", {}, x.louvor.nome), x.louvor.separado ? " · " + ROTULO_MODO[x.louvor.modo] : "") : h("p", { class: "mudo" }, "Áudio: sem música"))
              : h("div", { style: { "max-width": "460px" } }, h("label", {}, "Áudio que a turma está ouvindo (pode trocar agora)"), sel, bm);
          })(),
          h("div", { class: "linha" },
            x.status === "ATIVO" ? h("button", { onclick: () => acao("/api/prof/pausar", {}, "Exercício pausado.") }, "⏸ Pausar") : null,
            x.status === "PAUSADO" ? h("button", { onclick: () => acao("/api/prof/continuar", {}, "Exercício continuando.") }, "▶ Continuar") : null,
            x.status !== "FINALIZADO" ? h("button", { class: "primario", onclick: () => acao("/api/prof/finalizar", {}, "Exercício finalizado. Notas calculadas.") }, "■ Finalizar e dar as notas") : h("button", { onclick: () => ir("exercicios") }, "Escolher outro exercício"))]
          : [h("p", { class: "mudo" }, "Nenhum exercício iniciado."), h("button", { class: "primario", onclick: () => ir("exercicios") }, "Escolher exercício")]));
    };
    return { el, atualizar };
  }

  function confirmar(t) { return window.confirm(t); }

  function secaoAlunos() {
    const el = h("div");
    const atualizar = () => {
      if (!E.aula) { AL.limpar(el, h("div", { class: "cartao" }, h("p", {}, "Crie a sessão da aula primeiro."), h("button", { onclick: () => ir("aula") }, "Ir para Aula atual"))); return; }
      if (document.activeElement && el.contains(document.activeElement) && document.activeElement.tagName === "SELECT") return;
      AL.limpar(el, h("div", { class: "cartao" }, h("h2", {}, `Alunos (${E.alunos.length})`),
        h("p", { class: "mudo" }, "Na mesa de som: OPERADOR mexe na mesa; OBSERVADOR só acompanha a mesa do aluno que você selecionar. Só quem é da categoria “Operador de som” pode ser OPERADOR — cantores, regentes, bateristas e músicos entram sempre como OBSERVADOR."),
        h("p", { class: "mudo" }, "A categoria vem do tipo de acesso marcado em Treino em casa (pelo nome que o aluno digitou). Quem não tem cadastro aparece “sem categoria”: escolha a categoria ao lado do nome. Os exercícios de cada categoria ficam em Aula com turmas (celular)."),
        E.alunos.length ? E.alunos.map((a) => h("div", { class: "aluno" },
          h("div", {}, h("b", {}, a.nome), a.apelido && a.apelido !== a.nome ? h("span", { class: "mudo" }, " (telão: " + a.apelido + ")") : null, " ", h("span", { class: "selo " + (a.online ? "ok" : "") }, a.online ? "online" : "fora"),
            E.aula.selecionado === a.id ? h("span", { class: "selo aviso", style: { "margin-left": ".3rem" } }, "em destaque") : null,
            a.resultado ? h("div", { class: "mudo" }, `Última nota: ${a.resultado.nota}% (${a.resultado.retorno})`) : a.terminou ? null : null),
          h("div", { class: "acoes" },
            (a.turmas && a.turmas.length) ? h("span", { class: "selo", title: "Categoria (tipo de acesso)" }, a.turmas.map((t) => TreinosAL.TURMAS[t] || t).join(" · "))
              : h("select", { "aria-label": "Categoria de " + a.nome, onchange: (e) => { if (e.target.value) acao("/api/prof/categoria", { aluno: a.id, turma: e.target.value }, "Categoria marcada."); } },
                h("option", { value: "" }, "Sem categoria — escolha"), Object.entries(TreinosAL.TURMAS).map(([k, n]) => h("option", { value: k }, n))),
            (a.turmas || []).includes("som")
              ? h("select", { "aria-label": "Na mesa de som: função de " + a.nome, onchange: (e) => acao("/api/prof/papel", { aluno: a.id, papel: e.target.value }, "Função alterada.") },
                ["OPERADOR", "OBSERVADOR"].map((p) => h("option", { value: p, selected: a.papel === p }, "Na mesa: " + p)))
              : h("span", { class: "selo", title: "Só operador de som mexe na mesa" }, "Na mesa: OBSERVADOR"),
            h("button", { onclick: () => { acao("/api/prof/selecionar", { aluno: a.id }); ir("acompanhar"); } }, "Acompanhar"),
            h("button", { class: "perigo", onclick: () => { if (confirmar("Remover " + a.nome + " da aula?")) acao("/api/prof/remover", { aluno: a.id }, "Aluno removido."); } }, "Remover"))))
          : h("p", { class: "mudo" }, "Ninguém entrou ainda. Mostre o QR Code da tela Aula atual.")));
    };
    return { el, atualizar };
  }

  // Áudio do exercício: louvor da biblioteca (padrão, quando existe) ou o som do sistema
  const padraoAudio = () => {
    const lista = E.louvores || [];
    if (louvorEscolhido === "sistema") return "";
    if (lista.some((x) => x.id === louvorEscolhido)) return louvorEscolhido;
    return lista.length ? lista[lista.length - 1].id : ""; // o último louvor enviado
  };
  const ROTULO_MODO = { junto: "🎤🎸 Voz + instrumental juntos", voz: "🎤 Só a voz", instrumental: "🎸 Só o instrumental", original: "💿 Gravação original (inteira)" };
  let modoEscolhido = "junto"; try { modoEscolhido = sessionStorage.getItem("al_modo") || "junto"; } catch (e) { /* ok */ }
  // "Como tocar": só aparece quando o louvor já foi separado em voz e instrumental
  function blocoModo(aoMudar) {
    const sel = h("select", { "aria-label": "Como tocar a música", onchange: () => { modoEscolhido = sel.value; try { sessionStorage.setItem("al_modo", modoEscolhido); } catch (e) { /* ok */ } aoMudar(sel.value); } },
      Object.entries(ROTULO_MODO).map(([v, t]) => h("option", { value: v }, t)));
    sel.value = modoEscolhido;
    const el = h("div", { class: "oculto" }, h("label", {}, "Como tocar a música (separada pela IA)"), sel);
    el.mostrar = (separado, modo) => { el.classList.toggle("oculto", !separado); if (separado && document.activeElement !== sel) sel.value = modo || modoEscolhido; };
    el.valor = () => sel.value;
    return el;
  }
  const guardarEscolha = (v) => { louvorEscolhido = v || "sistema"; try { sessionStorage.setItem("al_louvor", louvorEscolhido); } catch (e) { /* ok */ } };
  function seletorAudio(rotulo, aoMudar) {
    const sel = h("select", { "aria-label": rotulo, onchange: () => aoMudar(sel.value) });
    let sig = null;
    sel.preencher = (valor) => {
      const lista = E.louvores || [], nova = lista.map((x) => x.id + x.nome + x.playback + x.separado).join("|");
      if (nova === sig && valor === undefined) return; sig = nova;
      const atual = valor !== undefined ? valor : sel.value;
      AL.limpar(sel, lista.map((x) => h("option", { value: x.id }, "🎵 " + x.nome + (x.separado ? " (voz e instrumental separados)" : x.playback ? " (+ playback)" : ""))), h("option", { value: "" }, "🔇 Sem música (só o defeito do exercício)"));
      sel.value = lista.some((x) => x.id === atual) ? atual : atual === "" ? "" : padraoAudio();
    };
    return sel;
  }

  function secaoExercicios() {
    const el = h("div"), seletores = [], modos = [];
    const atualizar = () => {
      seletores.forEach((s) => s.preencher());
      modos.forEach((f) => f());
      const motivo = !E.aula ? "Para iniciar um exercício, primeiro crie a aula (menu → Aula atual → Criar sessão)." : !E.alunos.length ? "Para iniciar um exercício, pelo menos um aluno precisa entrar na aula (pelo QR code ou código da aula)." : "";
      const rotulo = !E.aula ? "Crie a aula primeiro" : !E.alunos.length ? "Aguardando um aluno entrar" : "Iniciar exercício";
      if (el._feito) {
        el.querySelectorAll("[data-iniciar]").forEach((b) => { b.disabled = !!motivo; b.textContent = rotulo; });
        if (el._motivo) { el._motivo.textContent = motivo; el._motivo.hidden = !motivo; el._irAula.hidden = !!E.aula; }
        return;
      }
      el._feito = true;
      const qtd = (E.louvores || []).length;
      el._motivo = h("p", { class: "aviso" }, motivo); el._motivo.hidden = !motivo;
      el._irAula = h("button", { onclick: () => ir("aula") }, "Ir para Aula atual"); el._irAula.hidden = !!E.aula;
      AL.limpar(el, el._motivo, el._irAula, h("p", { class: "mudo" }, "Em cada exercício escolha o nível, a duração e o áudio: um louvor da biblioteca (o problema entra por cima dele) ou sem música (só o defeito). Ao finalizar, cada aluno recebe a nota com o que acertou e o que faltou."),
        h("div", { class: "linha", style: { "margin-bottom": ".8rem" } }, h("button", { onclick: () => ir("louvores") }, qtd ? "🎵 Louvores da aula (" + qtd + ")" : "🎵 Enviar louvores (ainda não tem nenhum)")),
        h("div", { class: "grade" }, exercicios.map((x, i) => { x.ordem = i;
          const dur = h("select", { "aria-label": "Duração" }, [60, 120, 180, 300, 600].map((s) => h("option", { value: s, selected: s === x.duracao }, AL.tempo(s) + " min")));
          const niv = h("select", { "aria-label": "Nível" }, Object.entries(niveis).map(([v, t]) => h("option", { value: v, selected: v === "medio" }, t + (v === "facil" ? " — com dica" : v === "dificil" ? " — só o sintoma" : ""))));
          const aud = seletorAudio("Áudio", (v) => { guardarEscolha(v); seletores.forEach((s) => { if (s !== aud) s.preencher(padraoAudio()); }); });
          aud.dataset.tipo = x.tipo; aud.preencher(padraoAudio()); seletores.push(aud);
          const modo = blocoModo(() => {}); const ver = () => { const lv = (E.louvores || []).find((l) => l.id === aud.value); modo.mostrar(!!(lv && lv.separado)); }; modos.push(ver); aud.addEventListener("change", ver); ver();
          return h("div", { class: "cartao" }, h("h3", {}, (x.ordem + 1) + ". " + x.nome), h("p", { class: "mudo" }, x.publico),
            h("details", {}, h("summary", {}, "📘 Teoria para explicar antes"), h("p", {}, x.teoria)),
            h("label", {}, "Nível"), niv, h("label", {}, "Duração"), dur, h("label", {}, "Áudio"), aud, modo,
            x.tipo === "equilibrio" ? h("p", { class: "mudo", style: { "font-size": ".8rem" } }, "Neste exercício o ideal é um louvor com playback (o canal MÚSICA precisa tocar).") : null,
            h("button", { class: "primario bloco", style: { "margin-top": ".7rem" }, "data-iniciar": x.tipo, disabled: !!motivo,
              onclick: async () => { const r = await acao("/api/prof/iniciar", { tipo: x.tipo, duracao: Number(dur.value), nivel: niv.value, louvor: aud.value || null, modo: modo.valor() }, "Exercício iniciado."); if (r) ir("aula"); } }, rotulo));
        })));
    };
    return { el, atualizar };
  }

  function secaoAcompanhar() {
    const el = h("div"), titulo = h("h2", {}, ""), res = h("div"), canvas = h("canvas", { class: "espectro" }), area = h("div");
    const ouvir = h("button", { class: "primario", onclick: () => { if (!motor.ligado()) alternarSom(true); } }, "▶ Ouvir esta mesa no computador");
    const vivo = h("p", { class: "mudo" }, "");
    let alunoAtual = null;
    // Demonstração: o professor mexe na mesa no computador dele para mostrar à turma (não muda a mesa nem a nota do aluno)
    const mesa = AL.mesa(area, limites, (nome, v) => { if (demo) { demo[nome] = v; aplicarSom(); } }); mesa.editavel(false);
    const avisoDemo = h("p", { class: "aviso oculto" }, "🎚 Modo demonstração: você está mexendo na mesa só aqui no computador (para a turma ouvir nas caixas). A mesa e a nota do aluno não mudam.");
    const btDemo = h("button", { onclick: () => {
      if (demo) { demo = null; mesa.editavel(false); btDemo.textContent = "🎚 Mexer na mesa (demonstração)"; btDemo.classList.remove("ligado"); avisoDemo.classList.add("oculto"); atualizar(); return; }
      const a = E.aula && E.alunos.find((x) => x.id === E.aula.selecionado);
      demo = { ...(a ? a.controles : Object.fromEntries(Object.entries(limites).map(([k, v]) => [k, v[2]]))) };
      mesa.editavel(true); mesa.atualizar(demo); btDemo.textContent = "↩ Voltar a acompanhar o aluno"; btDemo.classList.add("ligado"); avisoDemo.classList.remove("oculto");
      if (!motor.ligado()) alternarSom(true); aplicarSom();
    } }, "🎚 Mexer na mesa (demonstração)");
    AL.limpar(el, h("div", { class: "cartao" }, titulo, h("p", { class: "mudo" }, "Você vê e ouve exatamente o que o aluno está fazendo. Use nas caixas da sala para a turma inteira ouvir. Para mostrar um ajuste, toque em Mexer na mesa."),
      h("div", { class: "linha" }, ouvir, h("button", { onclick: () => alternarSom(false) }, "Silenciar"), btDemo), vivo, avisoDemo, canvas), area, h("div", { class: "cartao" }, h("h2", {}, "Resultado privado"), res));
    let raf = null;
    const desenhar = () => {
      if (motor.ctx) desenharEspectro(canvas, motor.analisador, motor.ctx.sampleRate);
      // sem demonstração: o medidor mostra o que o ALUNO está ouvindo agora (vem do celular dele); com demonstração, o da mesa do professor
      if (!demo && alunoAtual && alunoAtual.som && alunoAtual.vu) mesa.vu(alunoAtual.vu); else if (motor.ctx) mesa.vu(motor.niveis());
      raf = requestAnimationFrame(desenhar);
    };
    desenhar();
    const atualizar = () => {
      const a = E.aula && E.alunos.find((x) => x.id === E.aula.selecionado);
      alunoAtual = a || null; rotuloSom();
      ouvir.textContent = motor.ligado() ? "🔊 Ouvindo esta mesa" : "▶ Ouvir esta mesa no computador";
      vivo.textContent = a ? (a.online ? "● " + (a.apelido || a.nome) + " conectado" : "○ " + (a.apelido || a.nome) + " sem conexão") + (a.som ? " · ouvindo a mesa no celular" : " · ainda não ligou o som no celular") : "";
      if (!a) { titulo.textContent = demo ? "Mesa de demonstração do professor" : "Nenhum aluno selecionado — escolha em Alunos › Acompanhar"; if (!demo) { const normal = {}; for (const [k, v] of Object.entries(limites)) normal[k] = v[2]; mesa.atualizar(normal); } AL.limpar(res, h("p", { class: "mudo" }, "—")); return; }
      titulo.textContent = demo ? "Demonstração (partindo da mesa de " + a.nome + ")" : "Mesa de " + a.nome + " (" + a.papel + ")";
      if (!demo) mesa.atualizar(a.controles);
      AL.limpar(res, a.resultado ? [h("div", { class: "nota" }, a.resultado.nota + "%"), h("p", {}, a.resultado.retorno + " · " + AL.tempo(a.resultado.tempo)),
        h("h3", {}, "Acertou"), h("ul", { class: "lista-itens ok" }, a.resultado.acertos.map((t) => h("li", {}, t))),
        a.resultado.erros.length ? [h("h3", {}, "Faltou"), h("ul", { class: "lista-itens erro" }, a.resultado.erros.map((t) => h("li", {}, t)))] : null] : h("p", { class: "mudo" }, "Ainda sem nota neste exercício."));
    };
    return { el, atualizar, sair: () => { cancelAnimationFrame(raf); } };
  }

  // ------------------------------------------------------------------ boletim e certificado (os três cursos básicos) — desenho em documentos.js
  const NOTA_MIN = DocsAL.NOTA_MIN, NOTA_CERT = DocsAL.NOTA_CERT, situacao = DocsAL.situacao;
  const bloqueado = () => AL.toast("O navegador bloqueou a janela. Permita pop-ups para este endereço.", true);
  function imprimirBoletim(doc) { if (!DocsAL.abrir(DocsAL.boletimHTML(doc, info))) bloqueado(); }
  function imprimirCertificado(doc) { if (!DocsAL.abrir(DocsAL.certificadoHTML(doc, info))) bloqueado(); }

  // Operação de Som: monta o documento a partir da trilha dos exercícios da mesa
  function docSom(al, ordem) {
    return { tipo: "som", aluno: al.aluno, curso: "Operação de Som", icone: "🎚️", total: ordem.length, aprovadas: al.aprovados, media: al.media, tentativas: (al.historico || []).length,
      aulas: [...new Set((al.historico || []).map((x) => x.aula).filter(Boolean))], datas: (al.historico || []).map((x) => x.data), certificado: al.certificado,
      linhas: ordem.map((o) => { const m = al.melhores[o.tipo]; return { nome: o.nome, nota: m ? m.nota : null, data: m ? m.data : "", nivel: m ? m.nivel || "Médio" : "—" }; }) };
  }
  function imprimirDocumento(al, ordem) { const doc = docSom(al, ordem); if (doc.certificado) imprimirCertificado(doc); else imprimirBoletim(doc); }
  // Louvor e Regência: a partir das notas lançadas pelo professor
  const ICONE_CURSO = { louvor: "🎤", regencia: "🎼", bateria: "🥁", musico: "🎸" };
  function docCurso(cid, c, a) {
    const ms = c.materias.map((m) => ({ m, n: a.materias[m.id] }));
    return { tipo: cid, aluno: a.aluno, curso: c.nome, icone: ICONE_CURSO[cid] || "🎵", total: c.materias.length, aprovadas: a.aprovadas, media: a.media, certificado: a.certificado,
      datas: ms.filter((x) => x.n).map((x) => x.n.data), linhas: ms.map(({ m, n }) => ({ nome: m.nome, nota: n ? n.nota : null, data: n ? n.data : "" })) };
  }

  // Recuperação com treinos (16/11/2026): matéria abaixo de 50% + 3 dias de treino com 80% ou mais -> o professor aprova.
  function cartaoRecuperacao(aoMudar) {
    const el = h("div", { class: "cartao", style: { "border-left": "4px solid #f2c94c" } });
    async function carregar() {
      let d; try { d = await AL.api("/api/prof/recuperacoes"); } catch (e) { AL.toast(e.message, true); return; }
      const prontas = d.itens.filter((x) => x.pronta).length;
      AL.limpar(el, h("h2", {}, "🔁 Recuperação com treinos" + (prontas ? " — " + prontas + " para aprovar" : "")),
        h("p", { class: "mudo" }, "Matéria abaixo de 50% fica em recuperação. O aluno treina (em casa ou na aula) e precisa de " + d.dias + " dias diferentes com treino de " + d.nota_boa + "% ou mais no assunto daquela matéria. Aí aparece aqui para você aprovar: a matéria fica com a média dos treinos (de 50% a 79%) e o certificado pode sair."),
        d.itens.length ? h("div", { class: "rolar" }, h("table", {}, h("thead", {}, h("tr", {}, ["Aluno", "Curso › matéria", "Nota", "Treino que recupera", "Andamento", ""].map((t) => h("th", {}, t)))),
          h("tbody", {}, d.itens.map((x) => h("tr", {},
            h("td", {}, h("b", {}, x.aluno)), h("td", {}, x.curso_nome + " › " + x.materia_nome), h("td", {}, h("span", { class: "erro" }, x.nota + "%")), h("td", {}, x.treino),
            h("td", {}, h("div", { class: "barra-prog" }, h("span", { style: { width: Math.round(x.feitos / x.precisa * 100) + "%" } })), x.feitos + " de " + x.precisa + " dias" + (x.treinos ? " · " + x.treinos + " treino(s)" : "")),
            h("td", {}, x.pronta ? h("button", { class: "primario", onclick: async () => {
              if (!confirmar("Aprovar a recuperação de " + x.aluno + " em " + x.materia_nome + "?\n\nA nota passa de " + x.nota + "% para " + x.nota_recuperada + "% (média dos treinos).")) return;
              const r = await acao("/api/prof/recuperacao/aprovar", { curso: x.curso, aluno: x.aluno, materia: x.materia }, "Recuperação aprovada."); if (r) { carregar(); if (aoMudar) aoMudar(); } } }, "✅ Aprovar (fica " + x.nota_recuperada + "%)") : h("span", { class: "mudo" }, "treinando…")))))))
          : h("p", { class: "ok" }, "Ninguém em recuperação agora."));
    }
    carregar();
    return { el, carregar };
  }

  function secaoAvaliacao() {
    const el = h("div"), corpo = h("div");
    const CURSOS = [["louvor", "🎤 Louvor (Levitas)"], ["regencia", "🎼 Regência"], ["som", "🎚️ Operação de Som"], ["bateria", "🥁 Bateria"], ["musico", "🎸 Músicos"]].filter(([id]) => pode(CURSO_ASSUNTO[id]));
    let dados = null, cursoAtual = (CURSOS[0] || ["louvor"])[0], alunoAberto = null;
    const carregar = async () => { try { dados = await AL.api("/api/prof/avaliacoes"); desenhar(); recup.carregar(); } catch (e) { AL.toast(e.message, true); } };
    const recup = cartaoRecuperacao(() => carregar());
    const abas = h("div", { class: "linha" });
    const desenharAbas = () => AL.limpar(abas, CURSOS.map(([id, t]) =>
      h("button", { class: cursoAtual === id ? "primario" : "", onclick: () => { cursoAtual = id; alunoAberto = null; desenhar(); } }, t)));
    async function desenharSom() {
      let t; try { t = await AL.api("/api/prof/trilha"); } catch (e) { AL.toast(e.message, true); return; }
      AL.limpar(corpo, recup.el, h("div", { class: "cartao" }, h("h2", {}, "🎚️ Curso Básico de Operação de Som"),
        h("p", { class: "mudo" }, "Aqui a nota vem sozinha dos exercícios da mesa (melhor nota de cada um). O certificado sai quando o aluno fez todos e não ficou abaixo de " + NOTA_CERT + "% em nenhum."),
        t.alunos.length ? h("div", { class: "rolar" }, h("table", {}, h("thead", {}, h("tr", {}, ["Aluno", "Aprovado em", "Média", "Documento"].map((x) => h("th", {}, x)))),
          h("tbody", {}, t.alunos.map((a) => h("tr", {}, h("td", {}, a.aluno), h("td", {}, a.aprovados + " de " + t.ordem.length), h("td", {}, a.media + "%"),
            h("td", {}, h("button", { onclick: () => imprimirBoletim(docSom(a, t.ordem)) }, "📄 Boletim"), " ", a.certificado ? h("button", { class: "primario", onclick: () => imprimirCertificado(docSom(a, t.ordem)) }, "🎓 Certificado") : null)))))) : h("p", { class: "mudo" }, "Ainda sem notas dos exercícios.")));
    }
    function cartaoMateria(c, a, m) {
      const n = (a && a.materias[m.id]) || null;
      const caixas = m.criterios.map((t, i) => h("input", { type: "checkbox", checked: !!(n && n.itens && n.itens[i]), style: { width: "1.35rem", height: "1.35rem", flex: "none", margin: "0" } }));
      const notaAuto = () => Math.round(100 * caixas.filter((x) => x.checked).length / caixas.length);
      const campoNota = h("input", { type: "number", min: 0, max: 100, value: n ? n.nota : "", placeholder: "auto", style: { width: "5.5rem" }, "aria-label": "Nota da matéria" });
      const obs = h("input", { value: n ? n.obs || "" : "", maxlength: 200, placeholder: "Observação (opcional)", "aria-label": "Observação" });
      const mostrador = h("b", { style: { "font-size": "1.3rem" } }, "");
      const situ = h("span", {}, "");
      const atual = () => { const v = campoNota.value === "" ? notaAuto() : Number(campoNota.value); mostrador.textContent = v + "%"; situ.textContent = v >= NOTA_MIN ? " ✅ aprovado" : v >= NOTA_CERT ? " ◐ na média (estudar mais)" : " ↺ refazer"; situ.style.color = v >= NOTA_MIN ? "var(--ok, #7fd18b)" : v >= NOTA_CERT ? "#f2c94c" : "var(--erro, #ef6b6b)"; };
      caixas.forEach((x) => (x.onchange = () => { campoNota.value = ""; atual(); })); campoNota.oninput = atual; atual();
      return h("div", { class: "cartao", style: { margin: ".5rem 0" } },
        h("div", { class: "linha", style: { "justify-content": "space-between" } }, h("h3", { style: { margin: 0 } }, m.nome), h("span", {}, mostrador, situ, n ? h("small", { class: "mudo" }, " · lançada em " + n.data + (n.recuperada ? " · ♻️ recuperada com treinos (antes " + n.nota_original + "%)" : "")) : h("small", { class: "mudo" }, " · ainda não avaliada"))),
        h("p", { class: "mudo", style: { margin: ".3rem 0" } }, "Marque o que o aluno já faz bem (cada item vale 20%):"),
        ...m.criterios.map((t, i) => h("label", { style: { display: "flex", gap: ".6rem", "align-items": "center", "justify-content": "flex-start", margin: ".35rem 0", cursor: "pointer", "text-align": "left", "font-size": "1rem" } }, caixas[i], h("span", {}, t))),
        h("div", { class: "linha", style: { "margin-top": ".5rem" } }, h("span", { class: "mudo" }, "Nota (deixe vazio para calcular):"), campoNota, obs),
        h("div", { class: "linha", style: { "margin-top": ".5rem" } },
          h("button", { class: "primario", onclick: async () => { const r = await acao("/api/prof/avaliacao/salvar", { curso: cursoAtual, aluno: alunoAberto, materia: m.id, itens: caixas.map((x) => x.checked), nota: campoNota.value === "" ? null : Number(campoNota.value), obs: obs.value }, "Nota de " + m.nome + " salva."); if (r) carregar(); } }, "💾 Salvar " + m.nome),
          n ? h("button", { class: "perigo", onclick: async () => { if (!confirmar("Apagar a nota de " + m.nome + " de " + alunoAberto + "?")) return; const r = await acao("/api/prof/avaliacao/apagar", { curso: cursoAtual, aluno: alunoAberto, materia: m.id }, "Nota apagada."); if (r) carregar(); } }, "🗑 Apagar esta nota") : null));
    }
    function desenhar() {
      desenharAbas();
      if (cursoAtual === "som") { desenharSom(); return; }
      if (!dados) return;
      const c = dados.cursos[cursoAtual], lista = c.alunos;
      const nomeNovo = h("input", { list: "al-conhecidos", maxlength: 60, placeholder: "Nome do aluno", "aria-label": "Nome do aluno" });
      const dl = h("datalist", { id: "al-conhecidos" }, dados.alunos_conhecidos.map((n) => h("option", { value: n })));
      const abrir = (n) => { alunoAberto = n; desenhar(); };
      const topo = h("div", { class: "cartao" }, h("h2", {}, ICONE_CURSO[cursoAtual] + " Curso Básico de " + c.nome),
        h("p", { class: "mudo" }, c.materias.length + " matérias: " + c.materias.map((m) => m.nome).join(" · ") + ". Aprovado: " + NOTA_MIN + "% ou mais · na média: " + NOTA_CERT + "% a " + (NOTA_MIN - 1) + "% · refazer: abaixo de " + NOTA_CERT + "%. O certificado sai com todas as matérias avaliadas e nenhuma abaixo de " + NOTA_CERT + "% (a nota não aparece no certificado)."),
        h("div", { class: "linha" }, nomeNovo, dl, h("button", { class: "primario", onclick: () => { const n = nomeNovo.value.trim(); if (!n) { AL.toast("Escreva o nome do aluno.", true); return; } abrir(n); } }, "➕ Avaliar este aluno")),
        lista.length ? h("div", { class: "rolar" }, h("table", {}, h("thead", {}, h("tr", {}, ["Aluno", "Aprovado em", "Média", ""].map((x) => h("th", {}, x)))),
          h("tbody", {}, lista.map((a) => h("tr", {}, h("td", {}, h("b", {}, a.aluno)), h("td", {}, h("div", { class: "barra-prog" }, h("span", { style: { width: Math.round(a.aprovadas / c.materias.length * 100) + "%" } })), a.aprovadas + " de " + c.materias.length), h("td", {}, a.media + "%"),
            h("td", {}, h("button", { onclick: () => abrir(a.aluno) }, "✏️ Avaliar"), " ", h("button", { onclick: () => imprimirBoletim(docCurso(cursoAtual, c, a)) }, "📄 Boletim"), " ",
              a.certificado ? h("button", { class: "primario", onclick: () => imprimirCertificado(docCurso(cursoAtual, c, a)) }, "🎓 Certificado") : null, " ",
              h("button", { class: "perigo", title: "Excluir todas as notas deste aluno neste curso", onclick: async () => { if (!confirmar("Excluir TODAS as notas de " + a.aluno + " em " + c.nome + "?")) return; const r = await acao("/api/prof/avaliacao/apagar", { curso: cursoAtual, aluno: a.aluno }, "Notas excluídas."); if (r) { alunoAberto = null; carregar(); } } }, "🗑"))))))) : h("p", { class: "mudo" }, "Nenhum aluno avaliado ainda neste curso."));
      if (!alunoAberto) { AL.limpar(corpo, recup.el, topo); return; }
      const a = lista.find((x) => x.aluno === alunoAberto) || null;
      AL.limpar(corpo, topo, h("div", { class: "cartao" }, h("div", { class: "linha", style: { "justify-content": "space-between" } }, h("h2", { style: { margin: 0 } }, "✏️ Avaliando: " + alunoAberto), h("button", { onclick: () => { alunoAberto = null; desenhar(); } }, "✕ Fechar")),
        h("p", { class: "mudo" }, a ? "Média " + a.media + "% · aprovado em " + a.aprovadas + " de " + c.materias.length + " matérias." : "Aluno novo neste curso: avalie as matérias e salve cada uma."),
        ...c.materias.map((m) => cartaoMateria(c, a, m))));
    }
    AL.limpar(el, h("div", { class: "cartao" }, h("h2", {}, "Avaliação e certificados"),
      h("p", { class: "mudo" }, "Escolha o curso. No louvor, na regência, na bateria e nos músicos, você avalia cada matéria marcando o que o aluno já faz (observe no ensaio ou no exercício do slide). Na operação de som, a nota vem dos exercícios da mesa."), abas), corpo);
    carregar();
    return { el };
  }

  function secaoResultados() {
    const el = h("div"), pastas = h("div"), trilhaEl = h("div", { class: "rolar" }), treinosEl = h("div");
    let trilha = { ordem: [], alunos: [] };
    const AREA_ICONE = { voz: "🎤", ouvido: "👂", regencia: "🎼", bateria: "🥁", musico: "🎸" };
    const excluirTreino = async (corpo, pergunta) => {
      if (!confirmar(pergunta)) return;
      const r = await acao("/api/prof/treinos/apagar", corpo);
      if (r) { AL.toast(((r.dados && r.dados.excluidos) || 0) + " treino(s) excluído(s)."); carregarTreinos(); }
    };
    // treinos do Laboratório da voz, segunda voz, treino de ouvido e regência com câmera (16/11/2026)
    const carregarTreinos = async () => {
      let d; try { d = await AL.api("/api/prof/treinos"); } catch (e) { AL.toast(e.message, true); return; }
      const porAluno = {};
      d.itens.forEach((x) => { (porAluno[x.aluno] = porAluno[x.aluno] || []).push(x); });
      const nomes = Object.keys(porAluno).sort((a, b) => a.localeCompare(b, "pt-BR"));
      AL.limpar(treinosEl, nomes.length ? nomes.map((n) => {
        const it = porAluno[n];
        const resumo = Object.keys(d.areas).map((a) => { const xs = it.filter((x) => x.area === a); return xs.length ? AREA_ICONE[a] + " " + xs.length + " (melhor " + Math.max(...xs.map((x) => x.nota)) + "%)" : null; }).filter(Boolean).join(" · ");
        return h("details", { class: "cartao", style: { margin: ".5rem 0", padding: ".6rem .9rem" } },
          h("summary", { style: { cursor: "pointer", "font-size": "1.05rem" } }, h("b", {}, "📁 " + n), h("span", { class: "mudo" }, " — " + resumo + " · último em " + it[0].data)),
          h("div", { class: "linha", style: { margin: ".7rem 0" } },
            h("button", { class: "perigo", onclick: () => excluirTreino({ aluno: n }, "Excluir TODOS os " + it.length + " treino(s) de " + n + "?") }, "🗑 Excluir os treinos de " + n)),
          h("div", { class: "rolar" }, h("table", {}, h("thead", {}, h("tr", {}, ["Data", "Tipo", "Treino", "Nota", "Detalhe", "Onde", ""].map((t) => h("th", {}, t)))),
            h("tbody", {}, it.map((x) => h("tr", {}, h("td", {}, x.data), h("td", {}, AREA_ICONE[x.area] + " " + (d.areas[x.area] || x.area)), h("td", {}, x.treino),
              h("td", {}, h("b", { class: x.nota >= 80 ? "ok" : x.nota >= 50 ? "aviso" : "erro" }, x.nota + "%")), h("td", {}, x.detalhe || "—"), h("td", {}, x.origem === "casa" ? "🏠 em casa" : x.origem === "celular" ? "📱 na aula" : "💻 computador"),
              h("td", {}, h("button", { title: "Excluir este treino", "aria-label": "Excluir este treino", onclick: () => excluirTreino({ ids: [x.id] }, "Excluir este treino de " + n + "?\n\n" + x.treino + " · " + x.nota + "% · " + x.data) }, "🗑"))))))));
      }) : h("p", { class: "mudo" }, "Nenhum treino guardado ainda. No fim de cada treino aparece “Guardar na pasta do aluno”; no celular do aluno ele guarda sozinho."));
    };
    const excluir = async (corpo, pergunta) => {
      if (!confirmar(pergunta)) return;
      const r = await acao("/api/prof/resultados/apagar", corpo);
      if (r) { AL.toast(((r.dados && r.dados.excluidos) || 0) + " resultado(s) excluído(s)."); carregar(); }
    };
    const docBotao = (nome) => { const a = trilha.alunos.find((x) => x.aluno === nome); return a ? h("span", {}, h("button", { onclick: () => imprimirBoletim(docSom(a, trilha.ordem)) }, "📄 Boletim"), " ", a.certificado ? h("button", { class: "primario", onclick: () => imprimirCertificado(docSom(a, trilha.ordem)) }, "🎓 Certificado") : null) : null; };
    const carregar = async () => {
      try {
        trilha = await AL.api("/api/prof/trilha");
        const t = trilha;
        AL.limpar(trilhaEl, t.alunos.length ? h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "Aluno"), h("th", {}, "Progresso"), h("th", {}, "Média"), h("th", {}, "Documento"))),
          h("tbody", {}, t.alunos.map((a) => h("tr", {}, h("td", {}, a.aluno),
            h("td", {}, h("div", { class: "barra-prog", title: a.aprovados + " de " + t.ordem.length }, h("span", { style: { width: Math.round((a.aprovados / t.ordem.length) * 100) + "%" } })), a.aprovados + " de " + t.ordem.length + " aprovados"),
            h("td", {}, a.media + "%"),
            h("td", {}, docBotao(a.aluno))))))
          : h("p", { class: "mudo" }, "A trilha aparece quando os alunos tiverem notas."));
      } catch (e) { AL.toast(e.message, true); }
      let d; try { d = await AL.api("/api/prof/historico"); } catch (e) { AL.toast(e.message, true); return; }
      const porAluno = {};
      d.itens.forEach((x) => { (porAluno[x.aluno] = porAluno[x.aluno] || []).push(x); });
      const nomes = Object.keys(porAluno).sort((a, b) => a.localeCompare(b, "pt-BR"));
      AL.limpar(pastas, nomes.length ? nomes.map((n) => {
        const it = porAluno[n], media = Math.round(it.reduce((a, b) => a + b.nota, 0) / it.length);
        return h("details", { class: "cartao", style: { margin: ".5rem 0", padding: ".6rem .9rem" } },
          h("summary", { style: { cursor: "pointer", "font-size": "1.05rem" } }, h("b", {}, "📁 " + n), h("span", { class: "mudo" }, " — " + it.length + " tentativa(s) · média " + media + "% · última em " + it[0].data)),
          h("div", { class: "linha", style: { margin: ".7rem 0" } }, docBotao(n),
            h("button", { class: "perigo", onclick: () => excluir({ aluno: n }, "Excluir TODOS os " + it.length + " resultado(s) de " + n + "?\n\nO boletim deste aluno também some.") }, "🗑 Excluir tudo de " + n)),
          h("div", { class: "rolar" }, h("table", {}, h("thead", {}, h("tr", {}, ["Data", "Aula", "Exercício", "Nota", "Tempo", "O que faltou", ""].map((t) => h("th", {}, t)))),
            h("tbody", {}, it.map((x) => h("tr", {}, h("td", {}, x.data), h("td", {}, x.aula || "—"), h("td", {}, x.exercicio), h("td", {}, x.nota + "%"), h("td", {}, AL.tempo(x.tempo_s)), h("td", {}, x.detalhe),
              h("td", {}, h("button", { title: "Excluir esta tentativa", "aria-label": "Excluir esta tentativa", onclick: () => excluir({ ids: [x.id] }, "Excluir esta tentativa de " + n + "?\n\n" + x.exercicio + " · " + x.nota + "% · " + x.data) }, "🗑"))))))));
      }) : h("p", { class: "mudo" }, "Nenhum resultado ainda."));
    };
    AL.limpar(el, h("div", { class: "cartao" }, h("h2", {}, "Resultados (privados: só o professor vê todos)"),
      h("div", { class: "linha" }, h("button", { onclick: () => { carregar(); carregarTreinos(); } }, "↻ Atualizar"), h("a", { class: "btn primario", href: "/api/prof/historico.csv" }, "Baixar para Excel"))),
      h("div", { class: "cartao" }, h("h2", {}, "Pasta de cada aluno"),
        h("p", { class: "mudo" }, "Clique no nome para abrir a pasta e ver os exercícios feitos. Dali dá para imprimir o boletim, excluir uma tentativa (🗑) ou excluir tudo do aluno (por exemplo, os seus testes)."), pastas),
      h("div", { class: "cartao" }, h("h2", {}, "Treinos de voz, ouvido e regência"),
        h("p", { class: "mudo" }, "🎤 Laboratório da voz e segunda voz · 👂 treino de ouvido · 🎼 regência com câmera. São treinos para acompanhar a evolução: não entram na trilha da mesa nem no certificado."), treinosEl),
      h("div", { class: "cartao" }, h("h2", {}, "Trilha do aluno (evolução ao longo das semanas)"),
        h("p", { class: "mudo" }, "Conta a melhor nota de cada exercício. Aprovado com 80% ou mais; de 50% a 79% fica na média; abaixo de 50% refaz. O certificado sai quando o aluno fez todos e não ficou abaixo de 50% em nenhum."), trilhaEl));
    carregar(); carregarTreinos();
    return { el };
  }

  // ------------------------------------------------------------------ treino em casa (16/11/2026)
  // O professor cria o acesso de cada aluno (código + link). O aluno abre o site no celular, instala o ícone e treina em casa.
  // As notas chegam pela nuvem e aparecem em Resultados › Treinos (🏠 em casa). Este computador busca sozinho a cada 5 minutos.
  function secaoCasa() {
    const el = h("div"), lista = h("div"), novoEl = h("div"), info = h("p", { class: "mudo" });
    let est = null;
    const qrDe = (url) => { const q = qrcode(0, "M"); q.addData(url); q.make(); return new DOMParser().parseFromString(q.createSvgTag({ cellSize: 4, margin: 2 }), "image/svg+xml").documentElement; };
    // tipo de acesso (20/11/2026, pedido do Rinaldo): o app de casa mostra só as ferramentas do tipo escolhido.
    // É o mesmo campo das turmas (Aula com turmas): mudar aqui muda lá, e vice-versa. Sem nenhum tipo: o aluno vê tudo.
    const TIPOS = [["voz", "🎤 Cantor / levita"], ["regencia", "🎼 Regente"], ["som", "🎚️ Operador de som"], ["bateria", "🥁 Baterista"], ["musico", "🎸 Músico (violão, teclado, baixo)"]].filter(([id]) => pode(id));
    const nomeTipos = (ts) => (ts && ts.length ? TIPOS.filter(([id]) => ts.includes(id)).map(([, t]) => t).join(", ") : "todos os treinos");
    const mensagem = (a) => "Olá, " + a.nome + "! Este é o seu treino do RMD AudioLab para fazer em casa (" + nomeTipos(a.turmas) + ").\n\n"
      + "1) Abra no celular: " + a.link + "\n2) Toque em \"Instalar o ícone\" para ele ficar na tela do celular.\n3) Se pedir o código, é: " + a.codigo
      + "\n\nAs notas dos treinos chegam para o professor.";
    const copiar = async (t) => {
      try { await navigator.clipboard.writeText(t); AL.toast("Mensagem copiada. Cole no WhatsApp do aluno."); }
      catch (e) { window.prompt("Copie a mensagem abaixo:", t); }
    };
    const cartaoAcesso = (a) => h("div", { class: "cartao", style: { "border-left": "4px solid var(--destaque)" } },
      h("h3", {}, "🔑 Acesso de " + a.nome),
      h("div", { class: "linha", style: { gap: "1.2rem", "flex-wrap": "wrap", "align-items": "center" } },
        h("div", { class: "qr" }, qrDe(a.link)),
        h("div", { style: { flex: "1 1 260px" } }, h("small", { class: "mudo" }, "Código do aluno"), h("div", { class: "nota" }, a.codigo),
          h("p", { class: "mudo", style: { "word-break": "break-all" } }, a.link),
          h("button", { class: "primario", onclick: () => copiar(mensagem(a)) }, "📋 Copiar mensagem para mandar no WhatsApp"))),
      h("p", { class: "mudo" }, "O aluno pode ler o QR Code com a câmera do celular, ou você manda a mensagem. O código é como uma senha: é só daquele aluno."));
    async function carregar() {
      try { est = await AL.api("/api/prof/casa"); } catch (e) { AL.toast(e.message, true); return; }
      info.textContent = !est.ligado ? "⚠️ O treino em casa não está configurado neste computador." : "Última busca de notas: " + (est.ultima_busca || "ainda não buscou") + (est.erro ? " · ⚠️ " + est.erro : " · busca sozinho a cada 5 minutos");
      const parados = est.alunos.filter((a) => a.ativo && !a.treinos_semana);
      AL.limpar(lista, est.alunos.length ? h("div", {},
        est.alunos.some((a) => a.ativo) ? h("div", { class: "cartao", style: { "border-left": "4px solid " + (parados.length ? "#f2c94c" : "var(--ok, #3fb950)") } },
          h("h3", {}, parados.length ? "⚠️ Não treinaram em casa nos últimos 7 dias (" + parados.length + ")" : "✅ Todos treinaram em casa nos últimos 7 dias"),
          parados.length ? h("ul", {}, parados.map((a) => h("li", {}, h("b", {}, a.nome), h("span", { class: "mudo" }, " — " + (a.ultimo_treino ? "último treino em " + a.ultimo_treino : a.ultimo_acesso ? "entrou, mas ainda não treinou" : "ainda não entrou no app")))))
            : null,
          h("p", { class: "mudo", style: { margin: ".3rem 0 0" } }, "Conta pelas notas já buscadas da nuvem (" + (est.ultima_busca || "ainda não buscou") + ").")) : null,
        h("div", { class: "rolar" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Aluno", "Tipo de acesso", "Código", "Último acesso", "Treinos (7 dias)", "Situação", ""].map((t) => h("th", {}, t)))),
        h("tbody", {}, est.alunos.map((a) => h("tr", { style: { opacity: a.ativo ? "1" : ".55" } },
          h("td", {}, a.nome, a.tem_aula ? null : h("small", { class: "aviso", style: { display: "block" } }, "⚠️ sem notas da aula com este nome: use o mesmo nome do boletim")),
          // tocar no ícone liga/desliga aquele tipo para o aluno
          h("td", {}, h("div", { class: "linha", style: { gap: ".2rem", "flex-wrap": "wrap" } }, TIPOS.map(([id, t]) => {
            const tem = (a.turmas || []).includes(id);
            return h("button", { title: t + (tem ? " (tocar para tirar)" : " (tocar para dar)"), "aria-label": t + (tem ? " ligado" : " desligado"), disabled: !a.ativo, style: { padding: ".2rem .4rem", opacity: tem ? "1" : ".3", border: tem ? "2px solid var(--destaque)" : "" },
              onclick: async () => { const novo = new Set(a.turmas || []); if (tem) novo.delete(id); else novo.add(id);
                const r = await acao("/api/prof/turmas/aluno", { id: a.id, turmas: [...novo] }, a.nome + ": " + nomeTipos([...novo]) + "."); if (r) carregar(); } }, t.split(" ")[0]);
          })), h("small", { class: "mudo" }, nomeTipos(a.turmas))),
          h("td", {}, h("code", {}, a.codigo)), h("td", {}, a.ultimo_acesso || "ainda não entrou"),
          h("td", {}, h("b", { class: a.treinos_semana ? "ok" : "aviso" }, String(a.treinos_semana || 0))),
          h("td", {}, a.ativo ? h("span", { class: "ok" }, "ativo") : h("span", { class: "erro" }, "desativado")),
          h("td", {}, h("div", { class: "linha", style: { gap: ".3rem", "flex-wrap": "wrap" } },
            a.ativo ? h("button", { onclick: () => { AL.limpar(novoEl, cartaoAcesso(a)); novoEl.scrollIntoView({ behavior: "smooth" }); } }, "🔑 Mostrar acesso") : null,
            a.ativo ? h("button", { onclick: async () => {
              if (!confirmar("Gerar um código novo para " + a.nome + "?\n\nUse quando o aluno perdeu o código ou trocou de celular. O código antigo para de funcionar na hora. As notas dele continuam guardadas.")) return;
              const r = await acao("/api/prof/casa/codigo", { id: a.id }, "Código novo criado. Mande a mensagem nova para o aluno.");
              if (r && r.dados) { AL.limpar(novoEl, cartaoAcesso(r.dados)); novoEl.scrollIntoView({ behavior: "smooth" }); carregar(); } } }, "🔄 Código novo") : null,
            h("button", { class: a.ativo ? "perigo" : "", onclick: async () => {
              if (a.ativo && !confirmar("Desativar o acesso de " + a.nome + "?\n\nO código para de funcionar. As notas que já chegaram continuam guardadas.")) return;
              const r = await acao("/api/prof/casa/ativo", { id: a.id, ativo: !a.ativo }, a.ativo ? "Acesso desativado." : "Acesso reativado."); if (r) carregar(); } }, a.ativo ? "Desativar" : "Reativar")))))))))
        : h("p", { class: "mudo" }, "Nenhum aluno com acesso ainda. Crie o primeiro acima."));
    }
    const nome = h("input", { maxlength: 60, placeholder: "Nome e sobrenome do aluno", "aria-label": "Nome do aluno", style: { flex: "1 1 240px", width: "auto" } });
    const criar = h("button", { class: "primario", onclick: async () => {
      if (!nome.value.trim()) { AL.toast("Escreva o nome do aluno.", true); nome.focus(); return; }
      criar.disabled = true;
      const turmas = caixasTipo.filter((c) => c.checked).map((c) => c.value);
      if (!turmas.length && !confirmar("Nenhum tipo marcado: o aluno vai ver TODOS os treinos. Criar assim mesmo?")) { criar.disabled = false; return; }
      const r = await acao("/api/prof/casa/aluno", { nome: nome.value, turmas }, "Acesso criado.");
      criar.disabled = false;
      if (r && r.dados) { nome.value = ""; caixasTipo.forEach((c) => (c.checked = false)); AL.limpar(novoEl, cartaoAcesso(r.dados)); carregar(); }
    } }, "➕ Criar acesso");
    const caixasTipo = TIPOS.map(([id]) => h("input", { type: "checkbox", value: id, style: { width: "1.2rem", height: "1.2rem" } }));
    const escolhaTipo = h("div", { style: { margin: ".6rem 0" } }, h("b", {}, "Tipo de acesso (pode marcar mais de um):"),
      h("div", { class: "linha", style: { gap: ".4rem 1rem", "flex-wrap": "wrap", margin: ".3rem 0" } }, TIPOS.map(([, t], i) => h("label", { class: "linha", style: { gap: ".35rem", "align-items": "center" } }, caixasTipo[i], t))),
      h("small", { class: "mudo" }, "O app do aluno mostra só os treinos do tipo marcado. Dá para mudar depois na lista abaixo (tocando nos ícones) ou em Aula com turmas."));
    const buscar = h("button", { onclick: async () => {
      buscar.disabled = true; const r = await acao("/api/prof/casa/buscar", {}); buscar.disabled = false;
      if (r && r.dados) AL.toast(r.dados.novos ? r.dados.novos + " treino(s) novo(s) de casa. Veja em Resultados." : "Nenhum treino novo.");
      carregar();
    } }, "↻ Buscar notas agora");
    AL.limpar(el,
      h("div", { class: "cartao" }, h("h2", {}, "🏠 Treino em casa (celular do aluno)"),
        h("p", {}, "O aluno treina em casa pelo celular: Laboratório da voz, Segunda voz, Treino de ouvido, Regência com câmera, Metrônomo, Bateria e Músicos (só os do tipo de acesso marcado). A nota de cada treino chega aqui e fica na pasta dele em Resultados (marcada com 🏠)."),
        h("p", { class: "mudo" }, "Precisa de internet neste computador e no celular do aluno. A voz e a câmera do aluno nunca saem do celular dele: só a nota é enviada."),
        h("div", { class: "linha", style: { gap: ".5rem", "flex-wrap": "wrap" } }, nome, criar), escolhaTipo, novoEl),
      h("div", { class: "cartao" }, h("h2", {}, "Alunos com acesso"), h("div", { class: "linha", style: { gap: ".5rem", "align-items": "center", "flex-wrap": "wrap" } }, buscar, info), lista));
    carregar();
    return { el };
  }

  // ------------------------------------------------------------------ aula com turmas (16/11/2026)
  // Voz e Regência (e o treino de ouvido) vão pelo app do aluno, na internet do celular dele.
  // A mesa dos operadores de som continua pelo Wi-Fi deste computador (Aula atual › Exercícios).
  function secaoTurmas() {
    const el = h("div"), T = TreinosAL.TAREFAS, NOMES_T = Object.fromEntries(Object.entries(TreinosAL.TURMAS).filter(([t]) => pode(t)));
    const colunas = {}, alunosEl = h("div"), estadoEl = h("p", { class: "mudo" }, "Carregando…");
    let est = null, casa = null, timer = 0, vivo = true;
    const hora = (iso) => { try { return new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } };
    function formulario(turma) {
      const opcoes = Object.entries(T).filter(([, x]) => x.turmas.includes(turma));
      const tipo = h("select", { "aria-label": "Exercício" }, opcoes.map(([k, x]) => h("option", { value: k }, x.nome)));
      const nivel = h("select", { "aria-label": "Nível", style: { width: "auto" } }, TreinosAL.NIVEIS.map((n, i) => h("option", { value: i }, n)));
      const comp = h("select", { "aria-label": "Compasso", style: { width: "auto" } }, [2, 3, 4].map((n) => h("option", { value: n, selected: n === 4 }, n + "/4")));
      const bpm = h("input", { type: "number", min: 50, max: 140, value: 72, style: { width: "5.5rem" }, "aria-label": "Andamento (BPM)" });
      const extra = h("div", { class: "linha", style: { gap: ".4rem", "align-items": "center", "flex-wrap": "wrap" } }, "Compasso:", comp, "BPM:", bpm);
      const ajustar = () => { const x = T[tipo.value]; extra.style.display = x.regencia ? "" : "none"; nivel.disabled = !!x.semNivel; };
      tipo.onchange = ajustar; ajustar();
      const mandar = h("button", { class: "primario", onclick: async () => {
        const x = T[tipo.value], n = x.semNivel ? 0 : Number(nivel.value);
        const tarefa = { tipo: tipo.value, nivel: n, titulo: x.nome + (x.semNivel ? "" : " · " + TreinosAL.NIVEIS[n]) + (x.regencia ? " · " + comp.value + "/4 a " + bpm.value + " BPM" : ""),
          opcoes: x.regencia ? { compasso: Number(comp.value), bpm: Number(bpm.value) } : {} };
        mandar.disabled = true;
        const r = await acao("/api/prof/turmas/tarefa", { turma, tarefa }, "Exercício mandado para " + NOMES_T[turma] + ".");
        mandar.disabled = false; if (r) atualizar();
      } }, "📢 Mandar para a turma");
      return h("div", {}, h("label", {}, "Exercício"), tipo, h("div", { class: "linha", style: { gap: ".4rem", "align-items": "center", margin: ".4rem 0" } }, "Nível:", nivel), extra, mandar);
    }
    function coluna(turma) {
      const noAr = h("div"), lista = h("div");
      colunas[turma] = { noAr, lista };
      return h("div", { class: "cartao", style: { flex: "1 1 280px", "min-width": "260px" } },
        h("h2", {}, NOMES_T[turma]),
        turma === "som" ? h("p", { class: "aviso" }, "A mesa (exercícios com louvor) continua em Aula atual › Exercícios, pelo Wi-Fi deste computador. Aqui dá para mandar o treino de ouvido pelo app.") : null,
        noAr, formulario(turma), h("h3", { style: { "margin-top": ".8rem" } }, "Alunos da turma"), lista);
    }
    function desenhar() {
      if (!est) return;
      for (const turma of Object.keys(NOMES_T)) {
        const t = (est.tarefas || {})[turma], ativa = t && t.ativa, membros = est.alunos.filter((a) => a.turmas.includes(turma));
        const entregues = membros.filter((a) => a.notas[turma] != null);
        AL.limpar(colunas[turma].noAr, t ? h("div", { class: ativa ? "aviso" : "mudo", style: { margin: ".3rem 0 .6rem" } },
          (ativa ? "📢 No ar: " : "Último: ") + t.titulo + (t.criada ? " (" + hora(t.criada) + ")" : ""),
          h("div", {}, entregues.length + " de " + membros.length + " entregaram" + (entregues.length ? " · média " + Math.round(entregues.reduce((s, a) => s + a.notas[turma], 0) / entregues.length) + "%" : "")),
          ativa ? h("button", { class: "perigo", style: { "margin-top": ".3rem" }, onclick: async () => { const r = await acao("/api/prof/turmas/tarefa", { turma, tarefa: null }, "Exercício encerrado."); if (r) atualizar(); } }, "■ Encerrar") : null) : null);
        AL.limpar(colunas[turma].lista, membros.length ? h("ul", { class: "lista-itens", style: { "list-style": "none", padding: 0 } }, membros.map((a) => {
          const n = a.notas[turma];
          return h("li", {}, (a.online ? "🟢 " : "⚪ ") + a.nome + " — ",
            n != null ? h("b", { class: n >= 80 ? "ok" : n >= 50 ? "aviso" : "erro" }, "✅ " + n + "%") : h("span", { class: "mudo" }, ativa ? (a.online ? "⏳ fazendo" : "⏳ esperando (app fechado)") : "—"));
        })) : h("p", { class: "mudo" }, "Ninguém nesta turma. Marque abaixo, em “Alunos e turmas”."));
      }
      estadoEl.textContent = "🟢 = app aberto agora · atualiza sozinho a cada 5 segundos · " + new Date().toLocaleTimeString("pt-BR");
    }
    function desenharAlunos() {
      if (!casa) return;
      const turmasDe = (id) => ((est && est.alunos.find((a) => a.id === id)) || {}).turmas || [];
      AL.limpar(alunosEl, casa.alunos.filter((a) => a.ativo).length ? h("div", { class: "rolar" }, h("table", {},
        h("thead", {}, h("tr", {}, h("th", {}, "Aluno"), Object.values(NOMES_T).map((n) => h("th", {}, n)))),
        h("tbody", {}, casa.alunos.filter((a) => a.ativo).map((a) => h("tr", {}, h("td", {}, a.nome),
          Object.keys(NOMES_T).map((turma) => { const c = h("input", { type: "checkbox", checked: turmasDe(a.id).includes(turma), style: { width: "1.3rem", height: "1.3rem" }, "aria-label": a.nome + " na turma " + turma,
            onchange: async () => { const atual = new Set(turmasDe(a.id)); if (c.checked) atual.add(turma); else atual.delete(turma);
              const r = await acao("/api/prof/turmas/aluno", { id: a.id, turmas: [...atual] }); if (r) atualizar(); else c.checked = !c.checked; } });
            return h("td", { style: { "text-align": "center" } }, c); }))))))
        : h("p", { class: "mudo" }, "Nenhum aluno com acesso ao app ainda. Crie em Treino em casa (celular)."));
    }
    async function atualizar() {
      try { est = await AL.api("/api/prof/turmas"); desenhar(); }
      catch (e) { estadoEl.textContent = "⚠️ " + e.message; }
    }
    async function laco() { if (!vivo) return; await atualizar(); timer = setTimeout(laco, 5000); }
    AL.limpar(el,
      h("div", { class: "cartao" }, h("h2", {}, "👥 Aula com turmas"),
        h("p", {}, "Mande um exercício para cada turma ao mesmo tempo. No celular do aluno aparece “📢 Exercício do professor” e o treino abre no nível escolhido. As notas aparecem aqui na hora e também vão para a pasta de cada aluno."),
        h("p", { class: "mudo" }, "Os alunos usam o app (o mesmo do treino em casa), com a internet do próprio celular. Precisa de internet neste computador também."), estadoEl),
      h("div", { style: { display: "flex", gap: "1rem", "flex-wrap": "wrap", "align-items": "flex-start" } }, ["voz", "regencia", "som", "bateria", "musico"].filter(pode).map(coluna)),
      h("div", { class: "cartao" }, h("h2", {}, "Alunos e turmas"), h("p", { class: "mudo" }, "Marque a turma de cada aluno (pode estar em mais de uma)."), alunosEl));
    (async () => { try { casa = await AL.api("/api/prof/casa"); } catch (e) { casa = { alunos: [] }; } await atualizar(); desenharAlunos(); laco(); })();
    const antigo = atualizar;
    return { el, sair: () => { vivo = false; clearTimeout(timer); } };
  }

  // ------------------------------------------------------------------ chat das turmas (21/11/2026, pedido do Rinaldo)
  // Cada turma (departamento) tem a sua conversa: os alunos dela + o professor. Cada aluno tem também uma conversa particular com o professor.
  // Os alunos usam o app (treino em casa). O professor pode apagar qualquer mensagem.
  function secaoChat() {
    const el = h("div"), listaEl = h("div"), cabEl = h("div"), msgsEl = h("div", { class: "chat-msgs" }), estadoEl = h("p", { class: "mudo", style: { margin: ".3rem 0" } });
    const caixa = h("textarea", { rows: 2, maxlength: 500, placeholder: "Escreva para a conversa…", "aria-label": "Mensagem", style: { flex: "1", "min-width": "0" } });
    const enviar = h("button", { class: "primario" }, "Enviar");
    let dados = { canais: [], ultimas: {} }, canal = "", msgs = [], timer = 0, vivo = true;
    const lidos = () => { try { return JSON.parse(localStorage.getItem("al_prof_chat_lidos") || "{}"); } catch (e) { return {}; } };
    const marcarLido = (c, quando) => { const l = lidos(); if (!l[c] || l[c] < quando) { l[c] = quando; try { localStorage.setItem("al_prof_chat_lidos", JSON.stringify(l)); } catch (e) { /* ok */ } } };
    const novo = (c) => { const u = dados.ultimas[c]; return u && u.de !== "prof" && (!lidos()[c] || lidos()[c] < u.criado); };
    const hora = (iso) => { try { const d = new Date(iso); return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }) + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } };
    function desenharLista() {
      const turmas = dados.canais.filter((c) => c.id.startsWith("turma:")), part = dados.canais.filter((c) => c.id.startsWith("prof:"));
      const item = (c, sub) => h("button", { class: c.id === canal ? "ligado" : "", style: { display: "block", width: "100%", "text-align": "left", "margin-bottom": ".3rem" }, onclick: () => abrir(c.id) },
        (novo(c.id) ? "🔴 " : "") + c.nome, sub ? h("small", { class: "mudo", style: { display: "block" } }, sub) : null);
      AL.limpar(listaEl, h("h3", {}, "Turmas"), turmas.map((c) => item(c, c.membros + " aluno(s)")),
        h("h3", { style: { "margin-top": ".8rem" } }, "Particular com o aluno"), part.length ? part.map((c) => item(c)) : h("p", { class: "mudo" }, "Nenhum aluno com acesso ao app."));
    }
    function desenharMsgs() {
      const c = dados.canais.find((x) => x.id === canal);
      AL.limpar(cabEl, c ? h("h3", { style: { margin: "0 0 .4rem" } }, (canal.startsWith("prof:") ? "🔒 Particular: " : "👥 ") + c.nome) : h("p", { class: "mudo" }, "Escolha uma conversa ao lado."));
      AL.limpar(msgsEl, !canal ? null : msgs.length ? msgs.map((m) => {
        const meu = !m.aluno_id;
        return h("div", { class: "chat-msg" + (meu ? " meu" : "") },
          h("div", { class: "chat-quem" }, (meu ? "👨‍🏫 " : "") + m.nome + " · " + hora(m.criado),
            h("button", { class: "chat-apagar", title: "Apagar esta mensagem", onclick: async () => {
              if (!confirm("Apagar esta mensagem da conversa?")) return;
              const r = await acao("/api/prof/chat/apagar", { id: m.id }, "Mensagem apagada."); if (r) { msgs = msgs.filter((x) => x.id !== m.id); desenharMsgs(); } } }, "🗑")),
          h("div", { class: "chat-texto" }, m.texto));
      }) : h("p", { class: "mudo" }, "Nenhuma mensagem ainda. Escreva a primeira!"));
      msgsEl.scrollTop = msgsEl.scrollHeight;
      caixa.disabled = enviar.disabled = !canal;
    }
    async function buscar(soNovas) {
      try {
        const depois = soNovas && msgs.length ? msgs[msgs.length - 1].criado : "";
        const pedido = canal, r = await AL.api("/api/prof/chat", { canal, depois });
        if (pedido !== canal) return;  // trocou de conversa enquanto buscava
        dados = r.dados || dados; chatDados = { canais: dados.canais, ultimas: dados.ultimas };
        const vieram = (dados.mensagens || []).filter((m) => !msgs.some((x) => x.id === m.id));
        if (!soNovas) msgs = dados.mensagens || []; else if (vieram.length) msgs = msgs.concat(vieram);
        if (canal && msgs.length) marcarLido(canal, msgs[msgs.length - 1].criado);
        desenharLista(); if (!soNovas || vieram.length) desenharMsgs();
        estadoEl.textContent = "Atualiza sozinho a cada 5 segundos · " + new Date().toLocaleTimeString("pt-BR");
      } catch (e) { estadoEl.textContent = "⚠️ " + e.message; }
    }
    function abrir(c) { canal = c; msgs = []; desenharMsgs(); buscar(false); }
    enviar.onclick = async () => {
      const t = caixa.value.trim(); if (!t || !canal) return;
      enviar.disabled = true;
      const r = await acao("/api/prof/chat/enviar", { canal, texto: t });
      enviar.disabled = false;
      if (r && r.dados && r.dados.mensagem) { caixa.value = ""; msgs.push(r.dados.mensagem); marcarLido(canal, r.dados.mensagem.criado); desenharMsgs(); caixa.focus(); }
    };
    caixa.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar.click(); } });
    async function laco() { if (!vivo) return; await buscar(true); timer = setTimeout(laco, 5000); }
    AL.limpar(el,
      h("style", {}, ".chat-msgs{height:55vh;overflow:auto;background:var(--fundo2,rgba(0,0,0,.15));border-radius:8px;padding:.5rem}" +
        ".chat-msg{max-width:85%;margin:.35rem 0;padding:.4rem .6rem;border-radius:10px;background:rgba(127,127,127,.18)}" +
        ".chat-msg.meu{margin-left:auto;background:rgba(80,160,255,.22)}.chat-quem{font-size:.8rem;opacity:.8;display:flex;gap:.4rem;align-items:center}" +
        ".chat-texto{white-space:pre-wrap;word-break:break-word}.chat-apagar{margin-left:auto;padding:0 .3rem;font-size:.8rem;background:none;border:0;cursor:pointer}"),
      h("div", { class: "cartao" }, h("h2", {}, "💬 Chat das turmas"),
        h("p", {}, "Cada turma conversa com você e entre si, no app do aluno (aba “💬 Chat”). Cada aluno também tem uma conversa particular só com você."),
        h("p", { class: "mudo" }, "Você pode apagar qualquer mensagem (🗑). Aluno desativado em “Treino em casa” sai do chat na hora. Precisa de internet neste computador."), estadoEl),
      h("div", { style: { display: "flex", gap: "1rem", "flex-wrap": "wrap", "align-items": "flex-start" } },
        h("div", { class: "cartao", style: { flex: "1 1 220px", "max-width": "320px" } }, listaEl),
        h("div", { class: "cartao", style: { flex: "3 1 340px", "min-width": "0" } }, cabEl, msgsEl,
          h("div", { class: "linha", style: { gap: ".5rem", "margin-top": ".5rem", "align-items": "flex-end" } }, caixa, enviar))));
    desenharMsgs();
    buscar(false).then(() => { if (!canal && dados.canais.length) { const comNovo = dados.canais.find((c) => novo(c.id)); abrir((comNovo || dados.canais[0]).id); } laco(); });
    return { el, sair: () => { vivo = false; clearTimeout(timer); } };
  }

  // 21/11/2026: cartão para escolher o microfone (notebook ou interface de áudio USB) — vale para todas as ferramentas
  function cartaoMicrofone() {
    const nome = h("b", {}, "…");
    const atualizar = async () => { nome.textContent = await AL.nomeMicrofoneEscolhido(); };
    atualizar();
    return h("div", { class: "cartao" }, h("h2", {}, "🎤 Microfone do computador"),
      h("p", {}, "Usando agora: ", nome),
      h("p", { class: "mudo" }, "Ligou uma interface de áudio USB? Escolha ela aqui. Vale para afinador, voz, bateria e músicos."),
      h("button", { class: "primario", onclick: () => AL.escolherMicrofone(atualizar) }, "Escolher microfone"));
  }
  function secaoFerramentas() { const el = h("div"); const mic = cartaoMicrofone(); const corpo = h("div"); el.append(mic, corpo); FerramentasAL.montar(corpo, { arquivoAudio: () => (audioArquivo.src ? audioArquivo : null) }); return { el, sair: () => FerramentasAL.parar() }; }

  // Ensaio (16/11/2026): tocar o louvor mais devagar SEM mudar o tom e repetir um trecho (A–B).
  // Vale só para o player da Biblioteca neste computador; a mesa dos alunos continua na velocidade normal.
  function painelEnsaio() {
    const a = audioArquivo, info = h("span", { class: "mudo" }, "Velocidade normal.");
    let ini = null, fim = null;
    const fmt = (t) => Math.floor(t / 60) + ":" + String(Math.floor(t % 60)).padStart(2, "0");
    const velocidade = (v) => {
      a.preservesPitch = true; a.mozPreservesPitch = true; a.webkitPreservesPitch = true;
      a.defaultPlaybackRate = v; a.playbackRate = v;
      botoes.forEach((b) => b.classList.toggle("ligado", Number(b.dataset.v) === v));
      info.textContent = v === 1 ? "Velocidade normal." : "Tocando a " + Math.round(v * 100) + "% da velocidade, no mesmo tom.";
    };
    const botoes = [0.5, 0.75, 0.9, 1].map((v) => h("button", { "data-v": v, onclick: () => velocidade(v) }, v === 1 ? "100% (normal)" : Math.round(v * 100) + "%"));
    const trecho = h("span", { class: "mudo" }, "Sem trecho marcado.");
    const mostrarTrecho = () => { trecho.textContent = ini == null ? "Sem trecho marcado." : fim == null ? "Início em " + fmt(ini) + ". Toque em “Marcar fim” no ponto final." : "🔁 Repetindo de " + fmt(ini) + " até " + fmt(fim) + "."; };
    a.ontimeupdate = () => { if (ini != null && fim != null && a.currentTime >= fim) { a.currentTime = ini; a.play().catch(() => {}); } };
    a.onloadedmetadata = () => { a.playbackRate = a.defaultPlaybackRate || 1; ini = fim = null; mostrarTrecho(); };
    velocidade(1);
    return h("div", { style: { "margin-top": ".8rem" } },
      h("b", {}, "🐢 Ensaiar: mais devagar e repetir trecho"),
      h("p", { class: "mudo", style: { margin: ".2rem 0 .4rem" } }, "Para ensinar a música: toca mais devagar sem mudar o tom. Vale só para o player acima, neste computador (a mesa dos alunos não muda)."),
      h("div", { class: "linha", style: { gap: ".4rem", "flex-wrap": "wrap" } }, botoes), info,
      h("div", { class: "linha", style: { gap: ".4rem", "flex-wrap": "wrap", "margin-top": ".5rem" } },
        h("button", { onclick: () => { if (!a.src) return AL.toast("Toque um louvor primeiro (▶ Ouvir).", true); ini = a.currentTime; fim = null; mostrarTrecho(); } }, "⏮ Marcar início"),
        h("button", { onclick: () => { if (ini == null) return AL.toast("Marque o início primeiro.", true); if (a.currentTime <= ini + 0.5) return AL.toast("O fim precisa ser depois do início.", true); fim = a.currentTime; mostrarTrecho(); a.currentTime = ini; a.play().catch(() => {}); } }, "⏭ Marcar fim e repetir"),
        h("button", { onclick: () => { ini = fim = null; mostrarTrecho(); } }, "✕ Tirar trecho")), trecho);
  }

  function secaoLouvores() {
    const el = h("div"), lista = h("div");
    const arq = h("input", { type: "file", accept: "audio/*,.mp3,.m4a,.wav,.ogg,.opus,.aac,.flac", "aria-label": "Arquivo do louvor" });
    const nome = h("input", { maxlength: 80, placeholder: "Ex.: Grande é o Senhor — ao vivo", "aria-label": "Nome do louvor" });
    const pb = h("input", { type: "file", accept: "audio/*,.mp3,.m4a,.wav,.ogg,.opus,.aac,.flac", "aria-label": "Playback do louvor (opcional)" });
    const estado = h("p", { class: "mudo" });
    arq.onchange = () => { const f = arq.files[0]; if (f && !nome.value) nome.value = f.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "); };
    const enviarArquivo = async (f, q) => {
      const ext = (f.name.match(/\.[^.]+$/) || [""])[0].toLowerCase();
      const r = await fetch("/api/prof/louvor?" + new URLSearchParams({ ...q, ext }), { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/octet-stream", "X-AudioLab": "1" }, body: f });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.erro || "Não foi possível enviar o arquivo.");
      if (d.estado) E = d.estado; return d;
    };
    const enviar = h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: async () => {
      const f = arq.files[0]; if (!f) { AL.toast("Escolha o arquivo do louvor.", true); return; }
      enviar.disabled = true; estado.textContent = "Enviando " + f.name + "…";
      try {
        const d = await enviarArquivo(f, { nome: nome.value || f.name, tipo: "louvor" });
        if (pb.files[0]) { estado.textContent = "Enviando o playback…"; await enviarArquivo(pb.files[0], { tipo: "playback", de: d.dados.id }); }
        AL.toast("Louvor guardado na biblioteca."); louvorEscolhido = d.dados.id; try { sessionStorage.setItem("al_louvor", d.dados.id); } catch (e) { /* ok */ }
        arq.value = ""; pb.value = ""; nome.value = ""; estado.textContent = "Pronto. Ele já está escolhido em Exercícios › Áudio dos exercícios.";
        desenhar();
      } catch (e) { AL.toast(e.message, true); estado.textContent = ""; }
      enviar.disabled = false;
    } }, "⬆ Guardar louvor");
    const desenhar = () => {
      const itens = E.louvores || [];
      AL.limpar(lista, itens.length ? itens.map((x) => {
        const novoPb = h("input", { type: "file", accept: "audio/*", class: "oculto", onchange: async () => {
          if (!novoPb.files[0]) return; AL.toast("Enviando o playback…");
          try { await enviarArquivo(novoPb.files[0], { tipo: "playback", de: x.id }); AL.toast("Playback guardado."); desenhar(); } catch (e) { AL.toast(e.message, true); } } });
        const sp = x.sep || {}, ocupado = sp.estado === "instalando" || sp.estado === "separando";
        const ouvirParte = (parte) => () => { audioArquivo.src = "/api/louvor/" + x.id + "/" + parte; audioArquivo.play().catch(() => {}); };
        return h("div", { class: "aluno" },
          h("div", {}, h("b", {}, "🎵 " + x.nome), h("div", { class: "mudo" }, (x.separado ? "✔ voz e instrumental separados" : x.playback ? "com playback (instrumental)" : "sem playback") + " · " + Math.round(x.tamanho / 104857.6) / 10 + " MB · " + x.criado),
            ocupado ? [h("div", { class: "aviso" }, "⏳ " + sp.msg + " (" + sp.pct + "%) — pode continuar usando o sistema; não feche o AudioLab."), h("div", { class: "vu", "aria-hidden": "true" }, h("i", { style: { width: sp.pct + "%" } }))] : null,
            sp.estado === "erro" ? h("div", { class: "erro" }, sp.msg) : null),
          h("div", { class: "acoes" },
            h("button", { onclick: ouvirParte("louvor") }, "▶ Ouvir"),
            x.separado ? [h("button", { onclick: ouvirParte("voz") }, "▶ Só voz"), h("button", { onclick: ouvirParte("inst") }, "▶ Só instrumental")] : null,
            h("button", { disabled: ocupado, onclick: async () => {
              if (!confirmar((x.separado ? "Separar de novo? " : "") + "A inteligência separa a voz do instrumental neste computador (grátis, sem enviar nada para a internet depois de instalada). Na 1ª vez ela é baixada (cerca de 10 a 20 minutos); depois cada música leva alguns minutos. Pode continuar usando o sistema enquanto isso. Começar?")) return;
              const r = await acao("/api/prof/separar", { id: x.id }, "Separação iniciada."); if (r) desenhar(); } }, x.separado ? "✂ Separar de novo" : "✂ Separar voz e instrumental"),
            h("button", { onclick: () => novoPb.click() }, x.playback ? "Trocar playback" : "+ Playback"), novoPb,
            h("button", { class: "perigo", onclick: async () => { if (!confirmar("Apagar o louvor " + x.nome + " da biblioteca?")) return; const r = await acao("/api/prof/louvor/apagar", { id: x.id }, "Louvor apagado."); if (r) desenhar(); } }, "Apagar")));
      }) : h("p", { class: "mudo" }, "Nenhum louvor ainda. Envie o primeiro acima."));
    };
    AL.limpar(el,
      h("div", { class: "cartao" }, h("h2", {}, "Louvores da aula"),
        h("p", { class: "mudo" }, "Envie louvores gravados (MP3, M4A, WAV…). No exercício, o aluno ouve o louvor de verdade passando pela mesa, com o problema que você escolher por cima (microfonia, voz abafada, zumbido…). Os arquivos ficam só neste computador."),
        h("label", {}, "Arquivo do louvor (com voz)"), arq, h("label", {}, "Nome"), nome,
        h("label", {}, "Playback / instrumental do mesmo louvor (opcional — vai para o canal MÚSICA)"), pb, enviar, estado),
      h("div", { class: "cartao" }, h("h2", {}, "Biblioteca"), lista, h("div", { style: { "margin-top": ".6rem" } }, audioArquivo), painelEnsaio()));
    desenhar();
    let sigL = JSON.stringify(E.louvores);
    const atualizar = () => { const n = JSON.stringify(E.louvores); if (n !== sigL) { sigL = n; desenhar(); } };
    return { el, atualizar };
  }

  // Demonstrações sonoras locais para a aula: não usa internet nem envia áudio para o telão.
  function criarLaboratorioAudio() {
    const el = h("div", { class: "cartao laboratorio-audio" });
    let ctx = null, ativos = [];
    const status = h("p", { class: "mudo audio-status", "aria-live": "polite" }, "Escolha um exemplo. O som sai pelas caixas ou fones deste computador.");
    function parar() {
      ativos.slice().forEach((o) => { try { o.stop(); } catch (e) { /* já terminou */ } });
      ativos = [];
      status.textContent = "Demonstração interrompida.";
    }
    function tocar(freqs, rotulo, forma, harmonicos) {
      parar();
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) { status.textContent = "Este navegador não oferece áudio de demonstração."; return; }
      try { if (!ctx) ctx = new C(); } catch (e) { status.textContent = "Não foi possível iniciar o áudio neste navegador."; return; }
      const executar = async () => {
        if (ctx.state === "suspended") await ctx.resume();
        status.textContent = "Tocando: " + rotulo + ". Use o botão Parar se quiser interromper.";
        const inicio = ctx.currentTime + 0.06;
        freqs.forEach((freq, i) => {
          const t0 = inicio + i * 0.46, dur = freqs.length === 1 ? 0.78 : 0.38;
          const partes = harmonicos ? [[1, 0.62], [2, 0.22], [3, 0.10]] : [[1, 0.82]];
          partes.forEach(([mult, volume]) => {
            const osc = ctx.createOscillator(), ganho = ctx.createGain();
            osc.type = forma || "sine"; osc.frequency.setValueAtTime(freq * mult, t0);
            ganho.gain.setValueAtTime(0.0001, t0);
            ganho.gain.linearRampToValueAtTime(0.105 * volume, t0 + 0.025);
            ganho.gain.setValueAtTime(0.105 * volume, t0 + dur - 0.045);
            ganho.gain.linearRampToValueAtTime(0.0001, t0 + dur);
            osc.connect(ganho).connect(ctx.destination);
            osc.onended = () => { ativos = ativos.filter((x) => x !== osc); try { osc.disconnect(); ganho.disconnect(); } catch (e) { /* já desconectado */ } };
            ativos.push(osc); osc.start(t0); osc.stop(t0 + dur + 0.01);
          });
        });
        window.setTimeout(() => { if (!ativos.length) status.textContent = "Demonstração concluída: " + rotulo + "."; }, freqs.length * 460 + 450);
      };
      executar().catch(() => { status.textContent = "O navegador bloqueou o áudio. Clique novamente no exemplo para liberar o som."; });
    }
    const botao = (texto, fn, dica) => h("button", { type: "button", title: dica || texto, onclick: fn }, texto);
    const tipos = [
      ["Contralto", "faixa ilustrativa F3–F5", [174.6, 196, 220, 261.6, 349.2]],
      ["Mezzo-soprano", "faixa ilustrativa A3–A5", [220, 261.6, 329.6, 392, 440]],
      ["Soprano", "faixa ilustrativa C4–C6", [261.6, 329.6, 392, 523.3, 659.3]],
      ["Baixo", "faixa ilustrativa E2–E4", [82.4, 98, 130.8, 164.8, 196]],
      ["Barítono", "faixa ilustrativa A2–A4", [110, 130.8, 164.8, 196, 220]],
      ["Tenor", "faixa ilustrativa C3–C5", [130.8, 164.8, 196, 261.6, 329.6]]
    ];
    AL.limpar(el,
      h("h2", {}, "Laboratório de escuta — ouvir para compreender"),
      h("p", { class: "mudo" }, "Demonstrações geradas no próprio navegador, sem internet. Comece com volume baixo. Os sons de voz são referências eletrônicas de altura, não gravações de cantores nem um teste para classificar a voz de alguém."),
      h("h3", {}, "1. Compare grave, médio e agudo"),
      h("div", { class: "audio-botoes" },
        botao("🔉 Grave · 110 Hz", () => tocar([110], "som grave de 110 Hz", "sine", false)),
        botao("🎵 Médio · 440 Hz (Lá)", () => tocar([440], "nota de referência Lá 440 Hz", "sine", false)),
        botao("🔔 Agudo · 880 Hz", () => tocar([880], "som agudo de 880 Hz", "sine", false))),
      h("h3", {}, "2. Compare o timbre da mesma altura"),
      h("div", { class: "audio-botoes" },
        botao("Onda suave (senoidal)", () => tocar([220], "onda senoidal em 220 Hz", "sine", false)),
        botao("Onda triangular", () => tocar([220], "onda triangular em 220 Hz", "triangle", false)),
        botao("Onda quadrada (mais áspera)", () => tocar([220], "onda quadrada em 220 Hz", "square", false))),
      h("h3", {}, "3. Mapa de vozes — sequência de notas"),
      h("p", { class: "mudo" }, "Cada botão toca notas subindo de uma região mais baixa para outra mais alta. As extensões variam conforme a pessoa, a técnica e a classificação musical."),
      h("div", { class: "audio-botoes" }, tipos.map(([nome, faixa, notas]) => botao("▶ " + nome, () => tocar(notas, nome + " — " + faixa, "sine", true), faixa))),
      h("div", { class: "linha audio-acoes" }, botao("■ Parar áudio", parar)),
      status);
    return el;
  }

  // ------------------------------------------------------------------ palestra: conteúdo + controle do telão
  function secaoPalestra() {
    const el = h("div"), lembrar = (k) => { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, guardar = (k, v) => { try { sessionStorage.setItem(k, v); } catch (e) { /* ok */ } };
    let temaId = lembrar("al_p_tema"), idx = Number(lembrar("al_p_idx")) || 0, seguir = lembrar("al_p_seguir") === "1";
    const temasMeus = () => Palestra.temas().filter((t) => podeTema(t.id));
    if (!Palestra.achar(temaId) || !podeTema(temaId)) temaId = temasMeus()[0].id;
    const tema = () => Palestra.achar(temaId), slideAtual = () => tema().slides[Math.min(idx, tema().slides.length - 1)];
    const status = h("p", { class: "ok", style: { "font-weight": "700" } }, ""), selAluno = h("select", { "aria-label": "Aluno do teste ao vivo", style: { width: "auto", "min-width": "15rem" } });
    const chk = h("input", { type: "checkbox", style: { width: "auto" }, onchange: () => { seguir = chk.checked; guardar("al_p_seguir", seguir ? "1" : "0"); if (seguir) projetar(); } });
    chk.checked = seguir;
    const telao = (modo, extra) => acao("/api/prof/projetar", Object.assign({ modo }, extra || {}));
    function projetar() { telao("slide", { tema: temaId, slide: idx }); }
    const botoesTelao = h("div", { class: "linha" },
      h("button", { onclick: () => telao("painel") }, "Painel da aula"),
      h("button", { onclick: () => telao("preto") }, "Tela preta"),
      selAluno,
      h("button", { class: "primario", onclick: () => telao("teste", { aluno: selAluno.value || null }) }, "Teste ao vivo no telão"),
      h("button", { onclick: () => window.open("/projecao", "al_projecao", "width=1280,height=720") }, "Abrir a tela do telão"));
    const chips = h("div", { class: "temas-chips" }), lista = h("div", { class: "pal-lista" }), moldura = h("div", { class: "moldura" }), barraMetro = h("div"), fala = h("div", { class: "pal-fala oculto" }), laboratorio = criarLaboratorioAudio();
    let gradeSlides, alternarLista;
    const nav = h("div", { class: "pal-nav" },
      h("button", { onclick: () => ir(idx - 1) }, "◀ Anterior"), h("button", { onclick: () => ir(idx + 1) }, "Próximo ▶"),
      h("button", { class: "primario", onclick: projetar }, "📽 Projetar este slide"),
      alternarLista = h("button", { onclick: () => { const escondida = gradeSlides.classList.toggle("lista-oculta"); alternarLista.textContent = escondida ? "☷ Mostrar lista de slides" : "⤢ Ampliar prévia"; } }, "⤢ Ampliar prévia"));
    gradeSlides = h("div", { class: "pal-grade" }, lista, h("div", {}, moldura, nav, barraMetro, fala, laboratorio));
    function desenharChips() {
      AL.limpar(chips, temasMeus().map((t) => h("button", { style: { "border-color": t.cor }, class: t.id === temaId ? "ligado" : "", title: t.resumo, onclick: () => { temaId = t.id; idx = 0; guardar("al_p_tema", temaId); guardar("al_p_idx", 0); redesenhar(); if (seguir) projetar(); } }, t.nome)));
    }
    function desenharLista() {
      const pr = E && E.projecao, noAr = pr && pr.modo === "slide" && pr.tema === temaId ? pr.slide : -1;
      AL.limpar(lista, tema().slides.map((s, i) => h("button", { class: i === idx ? "ligado" : "", onclick: () => ir(i) }, (i + 1) + ". " + s.titulo + (s.avancado ? " ★" : ""), i === noAr ? h("span", { class: "no-ar" }, "  ● no telão") : null)));
    }
    function desenharPrevia() {
      const t = tema(), sl = slideAtual();
      AL.limpar(moldura, Palestra.slide(t, sl));
      AL.limpar(barraMetro, typeof Metronomo !== "undefined" ? Metronomo.barraSlide(t, sl, Math.min(idx, t.slides.length - 1), moldura) : null,
        typeof LabVoz !== "undefined" ? LabVoz.barraSlide(sl) : null);
      const guia = EXPLICACOES_INICIANTES[sl.id] || "";
      fala.classList.toggle("oculto", !guia && !sl.fala);
      AL.limpar(fala,
        h("b", {}, "Guia do professor — explicação para iniciantes (só você vê): "),
        h("p", {}, guia),
        sl.fala ? h("p", {}, h("b", {}, "Dica já existente: "), sl.fala) : null);
    }
    function redesenhar() { desenharChips(); desenharLista(); desenharPrevia(); }
    function ir(i) {
      const n = tema().slides.length;
      if (i < 0) { const ti = Palestra.temas().findIndex((t) => t.id === temaId); if (ti > 0) { temaId = Palestra.temas()[ti - 1].id; idx = tema().slides.length - 1; } else idx = 0; }
      else if (i >= n) { const ti = Palestra.temas().findIndex((t) => t.id === temaId); if (ti < Palestra.temas().length - 1) { temaId = Palestra.temas()[ti + 1].id; idx = 0; } else idx = n - 1; }
      else idx = i;
      guardar("al_p_tema", temaId); guardar("al_p_idx", idx); redesenhar(); if (seguir) projetar();
    }
    const tecla = (e) => {
      if (/^(INPUT|SELECT|TEXTAREA)$/.test((e.target || {}).tagName || "") && e.target.type !== "checkbox") return;
      if (e.key === "ArrowRight" || e.key === "PageDown") { e.preventDefault(); ir(idx + 1); }
      else if (e.key === "ArrowLeft" || e.key === "PageUp") { e.preventDefault(); ir(idx - 1); }
      else if (e.key === "Enter") { e.preventDefault(); projetar(); }
    };
    document.addEventListener("keydown", tecla);
    AL.limpar(el,
      h("div", { class: "cartao" }, h("h2", {}, "Telão"), status, botoesTelao,
        h("label", { style: { display: "flex", gap: ".5rem", "align-items": "center" } }, chk, "Projetar automaticamente ao trocar de slide (modo ao vivo)"),
        h("p", { class: "mudo", style: { "margin-bottom": 0 } }, "No teste ao vivo o telão mostra o nome do aluno e o que ele mexe na mesa — nunca nota, acerto ou erro. Isso aparece só no celular do aluno e na sua tela.")),
      h("div", { class: "cartao" }, h("h2", {}, "Conteúdo da aula"), h("p", { class: "mudo" }, "Escolha o tema, veja a prévia e projete. Setas ← → trocam de slide; Enter projeta."), chips,
        gradeSlides));
    redesenhar();
    let sigAlunos = "", sigTelao = "";
    function atualizar(estado) {
      const alunos = (estado.alunos || []).map((a) => a.id + ":" + (a.apelido || a.nome)).join("|");
      if (alunos !== sigAlunos) {
        sigAlunos = alunos; const v = selAluno.value;
        AL.limpar(selAluno, h("option", { value: "" }, "Aluno em acompanhamento"), (estado.alunos || []).map((a) => h("option", { value: a.id }, a.apelido || a.nome.split(" ")[0])));
        selAluno.value = v;
      }
      const p = estado.projecao || { modo: "painel" };
      let txt = "No telão agora: ";
      if (p.modo === "painel") txt += "painel da aula (exercício, tempo e mensagem)";
      else if (p.modo === "preto") txt += "tela preta";
      else if (p.modo === "slide") { const t = Palestra.achar(p.tema), s = t && t.slides[p.slide]; txt += "slide “" + (s ? s.titulo : "—") + "”" + (t ? " — " + t.nome : ""); }
      else { const a = p.aluno ? (estado.alunos || []).find((x) => x.id === p.aluno) : (estado.alunos || []).find((x) => x.id === (estado.aula && estado.aula.selecionado)); txt += "teste ao vivo" + (a ? " de " + (a.apelido || a.nome.split(" ")[0]) : " (aguardando aluno)") + " — sem notas na tela"; }
      status.textContent = txt;
      const sg = JSON.stringify(p); if (sg !== sigTelao) { sigTelao = sg; desenharLista(); }
    }
    return { el, atualizar, sair: () => { document.removeEventListener("keydown", tecla); if (typeof Metronomo !== "undefined") Metronomo.pararSlide(); if (typeof LabVoz !== "undefined") LabVoz.desligar(); } };
  }

  function secaoProjecao() {
    const el = h("div"), msg = h("input", { maxlength: 160, placeholder: "Ex.: Observem o que acontece com o grave quando o filtro é ligado", "aria-label": "Mensagem para o telão" });
    const atualizar = () => { if (document.activeElement !== msg) msg.value = (E.aula && E.aula.mensagem) || ""; };
    AL.limpar(el, h("div", { class: "cartao" }, h("h2", {}, "Projeção no telão"),
      h("p", { class: "mudo" }, "A tela pública mostra o exercício, o nível, o tempo e a sua mensagem. Se você ligar o placar (em Aula atual), mostra só os apelidos com nota e tempo — nunca nomes completos nem os erros."),
      h("button", { class: "primario", onclick: () => window.open("/projecao", "al_projecao", "width=1200,height=720") }, "Abrir projeção (arraste para o telão/HDMI)"),
      h("label", {}, "Mensagem para o telão"), msg, h("button", { style: { "margin-top": ".6rem" }, disabled: false, onclick: () => acao("/api/prof/mensagem", { texto: msg.value }, "Mensagem enviada ao telão.") }, "Enviar mensagem")));
    return { el, atualizar };
  }

  function secaoConfig() {
    const el = h("div");
    const nome = h("input", { value: info.nome_empresa || "", maxlength: 60, "aria-label": "Nome da igreja ou empresa" });
    const curso = h("input", { value: info.nome_curso || "", maxlength: 80, placeholder: "Conhecendo o Som", "aria-label": "Nome do curso" });
    const tema = h("select", { "aria-label": "Tema" }, [["escuro", "Escuro (padrão)"], ["medio", "Médio"], ["claro", "Claro"]].map(([v, t]) => h("option", { value: v, selected: info.tema === v }, t)));
    tema.onchange = () => AL.tema(tema.value);
    const atual = h("input", { type: "password", autocomplete: "current-password", "aria-label": "Senha atual" }), nova = h("input", { type: "password", autocomplete: "new-password", "aria-label": "Nova senha" });
    const codAtivar = h("input", { maxlength: 20, placeholder: "XXXX-XXXX-XXXX", "aria-label": "Código de ativação", style: { "text-transform": "uppercase", "letter-spacing": ".1em" } });
    const cartaoAtivar = conta.ligado ? h("div", { class: "cartao" }, h("h2", {}, "👤 Este AudioLab"),
        h("p", {}, "Professor: ", h("b", {}, conta.nome || "—"), conta.gestor ? " (gestor)" : ""),
        h("p", { class: "mudo" }, "Assuntos liberados: " + (conta.todos ? "todos" : nomeAssuntos(conta.modulos))))
      : h("div", { class: "cartao", style: { "border-left": "4px solid var(--destaque)" } }, h("h2", {}, "🔑 Ativar este AudioLab"),
        h("p", {}, "Digite o código de ativação que o RMD AudioLab mandou para você. Ele liga este computador à sua conta de professor (treino em casa, chat e boletim dos seus alunos)."),
        h("label", {}, "Código de ativação"), codAtivar,
        h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: async () => {
          const r = await acao("/api/prof/ativar", { codigo: codAtivar.value });
          if (r && r.dados) { AL.toast("AudioLab ativado para " + (r.dados.nome || "o professor") + "."); setTimeout(() => location.reload(), 1200); }
        } }, "Ativar"),
        h("p", { class: "mudo" }, "O código só funciona uma vez e vale 30 dias."));
    AL.limpar(el, cartaoAtivar, cartaoMicrofone(),
      h("div", { class: "cartao" }, h("h2", {}, "Aparência"), h("label", {}, "Nome da igreja / empresa (aparece no cabeçalho)"), nome, h("label", {}, "Nome do programa / curso geral (aparece no boletim e no certificado; ex.: Conhecendo o Som)"), curso, h("label", {}, "Tema"), tema,
        h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: async () => { const r = await acao("/api/prof/config", { nome_empresa: nome.value, nome_curso: curso.value, tema: tema.value }, "Configuração salva."); if (r) { info = r.dados; montarCabecalho(); } } }, "Salvar")),
      h("div", { class: "cartao" }, h("h2", {}, "Senha do professor"), h("label", {}, "Senha atual"), atual, h("label", {}, "Nova senha"), nova,
        h("button", { style: { "margin-top": ".8rem" }, onclick: async () => { const r = await acao("/api/prof/senha", { atual: atual.value, nova: nova.value }, "Senha trocada."); if (r) { atual.value = nova.value = ""; } } }, "Trocar senha")),
      h("div", { class: "cartao" }, h("h2", {}, "Rede local e celulares"),
        h("p", {}, "Endereço de rede detectado: ", h("b", {}, E.rede.ip + ":" + E.rede.porta)),
        h("p", { class: "mudo" }, "Os celulares precisam estar na mesma rede local que o computador. O acesso ao AudioLab não exige internet; o servidor roda neste computador na porta " + E.rede.porta + "."),
        h("h3", {}, "Opção A — usar o Wi-Fi do local"),
        h("p", { class: "mudo" }, "Conecte o computador e todos os celulares à mesma rede Wi-Fi. Na seção Aula atual, escolha no campo de endereço a interface correspondente a essa rede e só então mostre o QR Code."),
        h("h3", {}, "Opção B — compartilhar uma rede pelo Windows"),
        h("p", { class: "mudo" }, "Mais fácil: em Aula atual, use o cartão “Wi-Fi do computador” (botão Ligar). Ele liga a rede do computador e mostra o QR Code para os celulares entrarem. Manualmente: abra Configurações do Windows → Rede e Internet → Hotspot móvel. Configure o nome e a senha da rede e ative o hotspot. Conecte os celulares a esse nome de Wi-Fi e, em Aula atual, selecione o endereço IPv4 da interface do hotspot. A partilha Wi-Fi para Wi-Fi depende do suporte do adaptador e do Windows."),
        h("h3", {}, "Se não houver internet"),
        h("p", { class: "mudo" }, "Teste se o Windows permite manter o hotspot ativo sem uma conexão de internet. Se não permitir ou ficar instável, use um roteador/ponto de acesso Wi-Fi local sem cabo WAN: ele cria a rede mesmo sem internet. O computador e os celulares entram nesse mesmo Wi-Fi."),
        h("p", { class: "mudo" }, "Não desative o Firewall inteiro. Se o Windows pedir autorização, permita o AudioLab em redes privadas. Se o QR abrir uma página que não carrega, confira a rede selecionada no QR, o endereço IPv4 e a permissão do Firewall."),
        h("button", { class: "perigo", onclick: async () => { await AL.api("/api/prof/sair", {}); location.reload(); } }, "Sair do painel")));
    return { el };
  }

  // ------------------------------------------------------------------ gestão de professores (22/11/2026, só o gestor)
  // Cadastra professores, escolhe os assuntos de cada um, bloqueia/libera e gera o código de ativação do AudioLab dele.
  // suporte (22/11/2026): o professor diz o nome do aluno com problema; aqui aparecem SÓ dados técnicos
  // (acesso, tipo, último acesso, se os envios chegam). Notas, treinos e conversas são privados do professor.
  function cartaoSuporte() {
    const nome = h("input", { maxlength: 60, placeholder: "Nome do aluno (o professor informa)", "aria-label": "Nome do aluno para suporte", style: { flex: "1 1 240px", width: "auto" } });
    const res = h("div");
    const NOME_T = { voz: "🎤 Cantor", regencia: "🎼 Regente", som: "🎚️ Operador", bateria: "🥁 Baterista", musico: "🎸 Músico" };
    const quando = (iso) => { if (!iso) return "nunca"; try { const d = new Date(iso); return d.toLocaleDateString("pt-BR") + " " + d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }); } catch (e) { return "—"; } };
    const buscar = h("button", { class: "primario", onclick: async () => {
      if (nome.value.trim().length < 3) { AL.toast("Digite pelo menos 3 letras do nome.", true); nome.focus(); return; }
      buscar.disabled = true;
      const r = await acao("/api/prof/gestao/suporte", { nome: nome.value });
      buscar.disabled = false;
      if (!r || !r.dados) return;
      const als = r.dados.alunos;
      AL.limpar(res, als.length ? als.map((a) => h("div", { class: "cartao", style: { margin: ".5rem 0", "border-left": "4px solid " + (a.problemas.length ? "#f2c94c" : "var(--ok, #3fb950)") } },
        h("h3", { style: { margin: "0 0 .3rem" } }, a.nome, h("small", { class: "mudo" }, " · professor: " + a.professor + (a.professor_ativo ? "" : " (bloqueado)"))),
        h("p", { style: { margin: ".2rem 0" } }, "Acesso: ", a.ativo ? h("b", { class: "ok" }, "ativo") : h("b", { class: "erro" }, "desativado"),
          " · Tipo: " + (a.tipos.length ? a.tipos.map((t) => NOME_T[t] || t).join(", ") : "todos os treinos")),
        h("p", { class: "mudo", style: { margin: ".2rem 0" } }, "Último acesso ao app: " + quando(a.ultimo_acesso) + " · Último envio de nota: " + quando(a.ultimo_envio) + " · Envios nas últimas 24 h: " + a.envios_24h),
        a.problemas.length ? h("ul", { style: { margin: ".3rem 0 0" } }, a.problemas.map((p) => h("li", {}, "⚠️ " + p))) : h("p", { class: "ok", style: { margin: ".3rem 0 0" } }, "✅ Nenhum problema de acesso encontrado. Se o aluno ainda tem dificuldade, pode ser no aparelho dele (microfone, som, navegador).")))
        : h("p", { class: "mudo" }, "Nenhum aluno com esse nome. Confira a grafia com o professor."));
    } }, "🔎 Procurar");
    nome.addEventListener("keydown", (e) => { if (e.key === "Enter") buscar.click(); });
    return h("div", { class: "cartao" }, h("h2", {}, "🛠️ Suporte: achar aluno pelo nome"),
      h("p", {}, "Quando um professor avisar que um aluno está com problema, digite o nome do aluno. Aparece só o que precisa para a manutenção: se o acesso está ativo, o tipo de acesso, o último acesso e se as notas estão chegando."),
      h("p", { class: "mudo" }, "Privacidade: notas, treinos feitos e conversas dos alunos de outros professores não aparecem aqui."),
      h("div", { class: "linha", style: { gap: ".5rem", "flex-wrap": "wrap" } }, nome, buscar), res);
  }

  function secaoGestao() {
    const el = h("div"), lista = h("div"), resumo = h("div"), novoEl = h("div");
    const dataBR = (iso) => { if (!iso) return "—"; try { return new Date(iso).toLocaleDateString("pt-BR"); } catch (e) { return "—"; } };
    const copiar = async (t) => {
      try { await navigator.clipboard.writeText(t); AL.toast("Mensagem copiada. Cole no WhatsApp do professor."); }
      catch (e) { window.prompt("Copie a mensagem abaixo:", t); }
    };
    const mensagem = (nome, mods, codigo) => "Olá, " + nome + "! Você recebeu acesso ao RMD AudioLab como professor.\n\n"
      + "Assuntos liberados: " + nomeAssuntos(mods) + ".\n\n"
      + "1) Abra o RMD AudioLab no seu computador.\n2) Vá em Configurações › Ativar este AudioLab.\n3) Digite o código: " + codigo
      + "\n\nO código só funciona uma vez e vale 30 dias. Não passe para outras pessoas.";
    const cartaoCodigo = (nome, mods, codigo) => h("div", { class: "cartao", style: { "border-left": "4px solid var(--destaque)" } },
      h("h3", {}, "🔑 Código de ativação de " + nome), h("div", { class: "nota" }, codigo),
      h("p", { class: "mudo" }, "Assuntos: " + nomeAssuntos(mods) + ". O código só funciona uma vez e vale 30 dias. Ele não aparece de novo: copie agora."),
      h("button", { class: "primario", onclick: () => copiar(mensagem(nome, mods, codigo)) }, "📋 Copiar mensagem para mandar ao professor"));
    async function carregar() {
      let g; try { g = await AL.api("/api/prof/gestao"); } catch (e) { AL.limpar(lista, h("p", { class: "erro" }, e.message)); return; }
      const ps = g.professores, outros = ps.filter((p) => p.id !== g.eu);
      AL.limpar(resumo, h("div", { class: "linha", style: { gap: "1rem", "flex-wrap": "wrap" } },
        [["Professores ativos", outros.filter((p) => p.ativo && !p.pendente).length], ["Aguardando ativação", outros.filter((p) => p.pendente).length], ["Bloqueados", outros.filter((p) => !p.ativo).length],
          ["Alunos (todos)", ps.reduce((n, p) => n + p.alunos_ativos, 0)], ["Treinos em casa (30 dias)", ps.reduce((n, p) => n + p.treinos_30d, 0)]]
          .map(([t, n]) => h("div", { class: "cartao", style: { flex: "1 1 150px", margin: "0", "text-align": "center" } }, h("div", { class: "nota" }, String(n)), h("small", { class: "mudo" }, t)))));
      AL.limpar(lista, h("div", { class: "rolar" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Professor", "Assuntos (tocar liga/desliga)", "Alunos", "Usaram na semana", "Treinos 30 dias", "Último acesso", "Situação", ""].map((t) => h("th", {}, t)))),
        h("tbody", {}, ps.map((p) => {
          const eu = p.id === g.eu;
          const situacao = !p.ativo ? h("span", { class: "erro" }, "🔒 bloqueado") : p.pendente ? h("span", { class: "aviso" }, "⏳ aguardando ativação") : h("span", { class: "ok" }, "ativo");
          return h("tr", { style: { opacity: p.ativo ? "1" : ".6" } },
            h("td", {}, h("b", {}, p.nome), eu ? h("small", { class: "mudo" }, " (você)") : null, p.contato ? h("small", { class: "mudo", style: { display: "block" } }, p.contato) : null,
              p.obs ? h("small", { class: "mudo", style: { display: "block" } }, "📝 " + p.obs) : null),
            h("td", {}, eu ? h("span", { class: "mudo" }, "todos") : h("div", { class: "linha", style: { gap: ".2rem", "flex-wrap": "wrap" } }, ASSUNTOS.map(([id, t]) => {
              const tem = p.modulos.includes(id);
              return h("button", { title: t + (tem ? " (tocar para tirar)" : " (tocar para liberar)"), "aria-label": t + (tem ? " liberado" : " não liberado"),
                style: { padding: ".2rem .4rem", opacity: tem ? "1" : ".3", border: tem ? "2px solid var(--destaque)" : "" },
                onclick: async () => {
                  const novo = new Set(p.modulos); if (tem) novo.delete(id); else novo.add(id);
                  if (!novo.size) { AL.toast("Deixe pelo menos um assunto (ou bloqueie o professor).", true); return; }
                  const r = await acao("/api/prof/gestao/editar", { id: p.id, modulos: [...novo] }, p.nome + ": " + nomeAssuntos([...novo]) + "."); if (r) carregar();
                } }, t.split(" ")[0]);
            }))),
            h("td", {}, String(p.alunos_ativos) + (p.alunos > p.alunos_ativos ? " (+" + (p.alunos - p.alunos_ativos) + " desativados)" : "")),
            h("td", {}, String(p.alunos_semana)), h("td", {}, h("b", {}, String(p.treinos_30d))), h("td", {}, dataBR(p.ultimo_acesso)), h("td", {}, situacao),
            h("td", {}, eu ? null : h("div", { class: "linha", style: { gap: ".3rem", "flex-wrap": "wrap" } },
              h("button", { onclick: async () => {
                const nome = window.prompt("Nome do professor:", p.nome); if (nome === null) return;
                const contato = window.prompt("Igreja / cidade / telefone:", p.contato || ""); if (contato === null) return;
                const obs = window.prompt("Anotação (ex.: mensalidade, dia de pagamento):", p.obs || ""); if (obs === null) return;
                const r = await acao("/api/prof/gestao/editar", { id: p.id, nome, contato, obs }, "Cadastro atualizado."); if (r) carregar();
              } }, "✏️ Editar"),
              h("button", { onclick: async () => {
                if (!confirmar("Gerar um código de ativação novo para " + p.nome + "?\n\nUse quando ele trocou de computador ou perdeu o código. O AudioLab que ele usa agora para de funcionar até ele digitar o código novo. Os alunos e as notas dele continuam guardados.")) return;
                const r = await acao("/api/prof/gestao/codigo", { id: p.id });
                if (r && r.dados && r.dados.codigo) { AL.limpar(novoEl, cartaoCodigo(p.nome, p.modulos, r.dados.codigo)); novoEl.scrollIntoView({ behavior: "smooth" }); carregar(); }
              } }, "🔄 Código novo"),
              h("button", { class: p.ativo ? "perigo" : "primario", onclick: async () => {
                if (p.ativo && !confirmar("Bloquear " + p.nome + "?\n\nO AudioLab dele para de acessar a nuvem e os alunos dele não conseguem entrar no treino em casa até você liberar de novo. Nada é apagado.")) return;
                const r = await acao("/api/prof/gestao/editar", { id: p.id, ativo: !p.ativo }, p.ativo ? p.nome + " bloqueado." : p.nome + " liberado."); if (r) carregar();
              } }, p.ativo ? "🔒 Bloquear" : "🔓 Liberar"))));
        })))));
    }
    const nome = h("input", { maxlength: 60, placeholder: "Nome do professor", "aria-label": "Nome do professor" });
    const contato = h("input", { maxlength: 80, placeholder: "Igreja, cidade e telefone", "aria-label": "Igreja, cidade e telefone" });
    const obs = h("input", { maxlength: 300, placeholder: "Anotação (opcional): mensalidade, dia de pagamento…", "aria-label": "Anotação" });
    const caixas = ASSUNTOS.map(([id]) => h("input", { type: "checkbox", value: id, style: { width: "1.2rem", height: "1.2rem" } }));
    const criar = h("button", { class: "primario", style: { "margin-top": ".8rem" }, onclick: async () => {
      const mods = caixas.filter((c) => c.checked).map((c) => c.value);
      if (!nome.value.trim()) { AL.toast("Escreva o nome do professor.", true); nome.focus(); return; }
      if (!mods.length) { AL.toast("Marque pelo menos um assunto.", true); return; }
      criar.disabled = true;
      const r = await acao("/api/prof/gestao/criar", { nome: nome.value, contato: contato.value, obs: obs.value, modulos: mods }, "Professor cadastrado.");
      criar.disabled = false;
      if (r && r.dados && r.dados.codigo) { AL.limpar(novoEl, cartaoCodigo(r.dados.nome, r.dados.modulos, r.dados.codigo)); nome.value = contato.value = obs.value = ""; caixas.forEach((c) => (c.checked = false)); carregar(); }
    } }, "➕ Cadastrar professor e gerar código");
    AL.limpar(el,
      h("div", { class: "cartao" }, h("h2", {}, "🏛️ Gestão de professores"),
        h("p", {}, "Aqui você cadastra outros professores, escolhe quais assuntos cada um pode usar e bloqueia ou libera o acesso (por exemplo, pela mensalidade). Cada professor só vê os próprios alunos."),
        h("p", { class: "mudo" }, "Só aparece no seu AudioLab (gestor). Precisa de internet."), resumo),
      h("div", { class: "cartao" }, h("h2", {}, "➕ Novo professor"),
        h("label", {}, "Nome"), nome, h("label", {}, "Igreja / cidade / telefone"), contato, h("label", {}, "Anotação"), obs,
        h("div", { style: { margin: ".6rem 0" } }, h("b", {}, "Assuntos que ele vai usar (o resto não aparece para ele nem para os alunos dele):"),
          h("div", { class: "linha", style: { gap: ".4rem 1rem", "flex-wrap": "wrap", margin: ".3rem 0" } }, ASSUNTOS.map(([, t], i) => h("label", { class: "linha", style: { gap: ".35rem", "align-items": "center" } }, caixas[i], t)))),
        criar, novoEl),
      h("div", { class: "cartao" }, h("h2", {}, "Professores"), lista),
      cartaoSuporte());
    carregar();
    return { el };
  }

  const FABRICAS = { gestao: secaoGestao, palestra: secaoPalestra, aula: secaoAula, alunos: secaoAlunos, exercicios: secaoExercicios, acompanhar: secaoAcompanhar, resultados: secaoResultados, avaliacao: secaoAvaliacao, casa: secaoCasa, turmas: secaoTurmas, chat: secaoChat, ferramentas: secaoFerramentas, louvores: secaoLouvores, projecao: secaoProjecao, config: secaoConfig };
  let menuEl = null, main = null;

  function ir(id) {
    if (atual && atual.sair) atual.sair();
    secao = id; atual = FABRICAS[id]();
    AL.limpar(main, atual.el);
    if (atual.atualizar) atual.atualizar(E);
    menuEl.querySelectorAll("[data-sec]").forEach((b) => { const sim = b.dataset.sec === id; b.classList.toggle("ligado", sim); b.classList.toggle("ativo-menu", sim); });
    menuEl.classList.add("fechado");
    const botaoMenu = document.querySelector(".menu-flutuante");
    if (botaoMenu) { botaoMenu.setAttribute("aria-expanded", "false"); botaoMenu.title = "Abrir menu"; }
    try { sessionStorage.setItem("al_secao", id); } catch (e) { /* sem armazenamento */ }
    if (typeof desenharAvisoChat === "function") desenharAvisoChat();
  }

  function montarCabecalho() {
    AL.tema(info.tema);
    AL.cabecalho(cabeca, info, "Painel do professor", [somBtn, selo]);
  }

  async function iniciarPainel() {
    try { E = await AL.api("/api/prof/estado"); } catch (e) { if (e.status === 401) return telaLogin(); AL.toast(e.message, true); return; }
    const ex = await AL.api("/api/exercicios"); exercicios = ex.itens; limites = ex.controles; niveis = ex.niveis || {};
    try { conta = await AL.api("/api/prof/conta"); } catch (e) { /* sem conta: mostra tudo, como antes */ }
    // 22/11/2026: AudioLab sem professor ativado ou bloqueado pelo gestor não abre o painel
    if (!conta.ligado) return telaAtivacao();
    if (conta.bloqueado) return telaBloqueado();
    const menuToggle = h("button", { class: "menu-flutuante", type: "button", title: "Abrir menu", "aria-label": "Abrir menu de navegação", "aria-expanded": "false", onclick: () => {
      const aberto = menuEl.classList.toggle("fechado") === false;
      menuToggle.setAttribute("aria-expanded", aberto ? "true" : "false");
      menuToggle.title = aberto ? "Fechar menu" : "Abrir menu";
    } }, "⋮");
    menuEl = h("nav", { class: "menu fechado", "aria-label": "Menu de navegação" },
      h("button", { onclick: () => { menuEl.classList.add("fechado"); menuToggle.setAttribute("aria-expanded", "false"); menuToggle.title = "Abrir menu"; }, title: "Fechar menu" }, "✕ Fechar menu"),
      secoesVisiveis().map(([id, nome]) => nome ? h("button", { "data-sec": id, onclick: () => ir(id) }, nome) : h("div", { class: "grupo" }, id)));
    main = h("main");
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && menuEl && !menuEl.classList.contains("fechado")) { menuEl.classList.add("fechado"); menuToggle.setAttribute("aria-expanded", "false"); } });
    AL.limpar(app, h("div", { class: "corpo" }, menuEl, main, menuToggle));
    let inicial = "aula"; try { inicial = sessionStorage.getItem("al_secao") || "aula"; } catch (e) { /* ok */ }
    const pode_ir = (id) => FABRICAS[id] && secoesVisiveis().some((x) => x[0] === id && x[1]);
    ir(pode_ir(inicial) ? inicial : "aula");
    if (conta.bloqueado && avisos) avisos.before(h("div", { class: "aviso-topo", style: { background: "#5a1d1d" } }, "🔒 Este AudioLab está bloqueado na nuvem: treino em casa, chat e boletim dos alunos estão parados. Fale com o responsável pelo RMD AudioLab."));
    if (avisos) avisos.after(avisoChatEl); else app.prepend(avisoChatEl);
    verificarChat();
    verificarAtualizacao();
    laco();
  }

  // ------------------------------------------------------------------ aviso de mensagem nova no chat (21/11/2026, pedido do Rinaldo)
  // Ao abrir o painel (e a cada 30 segundos) confere se algum aluno escreveu no chat. Se sim, mostra a faixa no alto,
  // a bolinha 🔴 no botão do menu e no item "Chat das turmas". Sem som.
  let chatDados = null, chatTimerAviso = 0;
  const avisoChatEl = h("div");
  function chatNaoLidas() {
    if (!chatDados) return [];
    let lidos = {}; try { lidos = JSON.parse(localStorage.getItem("al_prof_chat_lidos") || "{}"); } catch (e) { /* ok */ }
    return (chatDados.canais || []).filter((c) => { const u = (chatDados.ultimas || {})[c.id]; return u && u.de !== "prof" && (!lidos[c.id] || lidos[c.id] < u.criado); });
  }
  function desenharAvisoChat() {
    const novas = secao === "chat" ? [] : chatNaoLidas();
    const botaoMenu = document.querySelector(".menu-flutuante"), item = menuEl && menuEl.querySelector('[data-sec="chat"]');
    if (botaoMenu) AL.limpar(botaoMenu, "⋮", novas.length ? h("span", { "aria-label": "mensagem nova no chat", style: { position: "absolute", top: "0", right: "0", width: ".8rem", height: ".8rem", "border-radius": "50%", background: "#e5484d", border: "2px solid #fff" } }) : null);
    if (item) item.textContent = "Chat das turmas" + (novas.length ? " 🔴 " + novas.length : "");
    const nomes = novas.map((c) => (c.id.startsWith("prof:") ? "particular de " : "") + c.nome);
    AL.limpar(avisoChatEl, novas.length ? h("div", { class: "aviso-topo", style: { display: "flex", gap: ".6rem", "align-items": "center", "flex-wrap": "wrap", "justify-content": "center" } },
      h("b", {}, "💬 Mensagem nova no chat"), h("span", {}, nomes.slice(0, 4).join(", ") + (nomes.length > 4 ? " e mais " + (nomes.length - 4) : "")),
      h("button", { class: "primario", onclick: () => ir("chat") }, "Abrir o chat")) : null);
  }
  async function verificarChat() {
    clearTimeout(chatTimerAviso);
    try { const r = await AL.api("/api/prof/chat", {}); chatDados = r.dados || chatDados; } catch (e) { /* sem internet ou sem treino em casa: tenta depois */ }
    desenharAvisoChat();
    chatTimerAviso = setTimeout(verificarChat, 30000);
  }

  async function laco() {
    try {
      E = await AL.api("/api/prof/estado"); falhasRede = 0;
      selo.className = "selo ok"; selo.textContent = "● conectado";
      AL.limpar(avisos, E.senha_padrao ? h("div", { class: "aviso-topo" }, "Senha do professor: a padrão (1234). Se quiser outra, troque em Configurações › Senha do professor.") : null);
      aplicarSom();
      if (atual && atual.atualizar) atual.atualizar(E);
    } catch (e) {
      if (e.status === 401) { location.reload(); return; }
      falhasRede++; selo.className = "selo erro"; selo.textContent = "● sem conexão com o servidor";
    }
    setTimeout(laco, 500);
  }

  (async function () {
    try { info = await AL.api("/api/info"); } catch (e) {
      AL.limpar(app, h("div", { class: "cartao login" }, h("h2", {}, "O servidor do AudioLab não está ligado"), h("p", {}, "Abra o AudioLab pelo ícone “RMD AudioLab” da Área de Trabalho. Ele liga o servidor e abre esta tela.")));
      return;
    }
    montarCabecalho();
    iniciarPainel();
  })();
})();
