@echo off
rem RMD AudioLab - abre a sala de aula de audio (liga o servidor, atualiza se for preciso e abre o painel do professor).
cd /d "%~dp0"
rem Refaz o atalho da Area de Trabalho com o proprio Windows (garante que o icone sempre abre).
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\RMD AudioLab.lnk'); $s.TargetPath='%~dp0RMD AudioLab.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0static\audiolab.ico,0'; $s.WindowStyle=7; $s.Description='RMD AudioLab - sala de aula de audio'; $s.Save()" >nul 2>nul
rem Computador do professor: usa o Python que veio junto no pacote (pasta python).
if exist "%~dp0python\pythonw.exe" (
  start "" "%~dp0python\pythonw.exe" iniciar.py
  exit /b 0
)
where pyw >nul 2>nul && goto PYW
where pythonw >nul 2>nul && goto PYTHONW
where py >nul 2>nul && goto PY
where python >nul 2>nul && goto PYTHON
echo O Python nao foi encontrado neste computador. Instale o Python 3 (python.org) e abra o RMD AudioLab de novo.
pause
exit /b 1
:PYW
start "" pyw -3 iniciar.py
exit /b 0
:PYTHONW
start "" pythonw iniciar.py
exit /b 0
:PY
start "" /min py -3 iniciar.py
exit /b 0
:PYTHON
start "" /min python iniciar.py
exit /b 0
